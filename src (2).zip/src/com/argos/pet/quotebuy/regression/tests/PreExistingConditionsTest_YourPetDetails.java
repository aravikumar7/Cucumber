/**
 * 
 */
package com.argos.pet.quotebuy.regression.tests;

import java.io.IOException;

import com.argos.pet.quotebuy.regression.common.code.dbconnection.DBConnectionRegressionCommonCode;
import com.argos.pet.quotebuy.regression.common.code.pages.PreExistingConditionsPage;
import com.argos.pet.quotebuy.regression.common.code.utilities.TestBase;
import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;
import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Recordset;


/**
 * @author d23747
 *
 */
public class PreExistingConditionsTest_YourPetDetails extends TestBase {

	PreExistingConditionsPage preExistingConditionsPage;
	DBConnectionRegressionCommonCode dbConnection;
	Utilities utilities;
	
	public void testPreExistingConditions() throws FilloException, IOException
	{
		preExistingConditionsPage = new PreExistingConditionsPage(driver);
		dbConnection = new DBConnectionRegressionCommonCode();
		utilities = new Utilities();
		String strQuery = "Select * from PreExistingConditions";
		Recordset recordset = dbConnection.recordset(strQuery);
		recordset.next();
		recordset.moveFirst();
		preExistingConditionsPage.setPreExistingInjuryDetails(recordset.getField("PreExistingInjuryDetails"));
		//preExistingConditionsPage.setVetPostCodeTextField(recordset.getField("VetPostCode"));
		//preExistingConditionsPage.clickVetPostCodeSerchButton();
		preExistingConditionsPage.clickProvideVetDetailsLaterTickBox();
		preExistingConditionsPage.clickSaveCloseButton();
		dbConnection.closeConnection();
	}
}
