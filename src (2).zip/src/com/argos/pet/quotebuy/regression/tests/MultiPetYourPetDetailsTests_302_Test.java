package com.argos.pet.quotebuy.regression.tests;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.asserts.SoftAssert;

import com.argos.pet.quotebuy.regression.common.code.dbconnection.DBConnection;
import com.argos.pet.quotebuy.regression.common.code.utilities.TestBase;
import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;
import com.codoid.products.fillo.Recordset;


public class MultiPetYourPetDetailsTests_302_Test extends TestBase{

	DBConnection dbConnection;
	Utilities utilities;
	Actions actions;
	SoftAssert softAssert = new SoftAssert();
	String[] dobArray;
	String DOB_FromCoverStartDate;
	String dateOfBirth;

	public void initiateMultiPetYourPetDetailsTests_302(String ClassName) throws Exception
	{
		utilities = new Utilities();
		dbConnection = new DBConnection();
		actions = new Actions(driver.get());
	//	utilities.waitElement(driver.get().findElement(By.xpath("//*[@id='yourPetsSubmitButton']")), driver);
	//	Thread.sleep(3000);
		String className = utilities.getClassName(ClassName);
		String strQuery = "Select * from MoreAboutYourPet where TestClassName = '" + className + "'";
		Recordset recordset = dbConnection.recordset(strQuery);
		recordset.next();
		recordset.moveFirst();
		if (recordset.getField("MultiPet").equalsIgnoreCase("Yes"))
		{
			strQuery = "Select * from MultiPet where TestClassName = '" + className + "'";
			dbConnection = new DBConnection();
			recordset = dbConnection.recordset(strQuery);
			recordset.next();
			recordset.moveFirst();
			Thread.sleep(2500);
			((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", 	driver.get().findElement(By.xpath("//button[text()='Add another pet']")));
			((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", 	driver.get().findElement(By.xpath("//button[text()='Add another pet']")));
		
			((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//*[@id='pet2.pet_name']")));
			driver.get().findElement(By.xpath("//*[@id='pet2.pet_name']")).sendKeys(recordset.getField("MultiPetName_1"));

			if (recordset.getField("MultiPetType_1").equalsIgnoreCase("Dog"))
			{
				((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//*[@for='radio_dog_pet2']")));
				((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//*[@for='radio_dog_pet2']")));
				utilities.waitElement(driver.get().findElement(By.xpath("//*[@for='breed_pet2']")), driver);
					if (recordset.getField("MultiPetTypeOfDog_1").equalsIgnoreCase("Breed"))
				{	
						((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//*[@for='breed_pet2']")));
						Actions builder = new Actions(driver.get());
						driver.get().findElement(By.xpath("//div[@id='pet2.pet_breed']/div/div/div/div/input")).sendKeys("African Crested Dog");
						Thread.sleep(1000);
						builder.sendKeys(Keys.ENTER).perform();
				}
				else if (recordset.getField("MultiPetTypeOfDog_1").equalsIgnoreCase("Crossbreed"))
				{
					Actions builder = new Actions(driver.get());
					driver.get().findElement(By.xpath("//div[@id='pet2.pet_breed']/div/div/div/div/input")).sendKeys("African Crested Dog Cross");
					Thread.sleep(1000);
					builder.sendKeys(Keys.ENTER).perform();
				}
				else if (recordset.getField("MultiPetTypeOfDog_1").equalsIgnoreCase("Mongrel"))
				{
					Thread.sleep(1000);
					driver.get().findElement(By.xpath("//*[@for='mongrel_pet2']")).click();
					((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//*[@for='mongrel-smallpet2']")));
					((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//*[@for='mongrel-smallpet2']")));
		
				}
			}

			else
			{
				((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//*[@for='radio_cat_pet2']")));
				((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//*[@for='radio_cat_pet2']")));
				
			/*	Actions builder = new Actions(driver.get());
					driver.get().findElement(By.xpath("//div[@id='pet2.pet_breed']/div/div/div/div/input")).sendKeys("Angora");
					Thread.sleep(1000);
					builder.sendKeys(Keys.ENTER).perform();*/
				
			}
		//	dateOfBirth = recordset.getField("DOB_Date")+"/"+recordset.getField("DOB_Month")+"/"+recordset.getField("DOB_Year");
		//	driver.get().findElement(By.id("pet2.pet_date_of_birth")).sendKeys(dateOfBirth);
			
			DOB_FromCoverStartDate = recordset.getField("DOB_FromCoverStartDate");
			dobArray = utilities.getDOB(DOB_FromCoverStartDate);
			driver.get().findElement(By.xpath("//*[@id='pet2.dateDayName']")).clear();
			driver.get().findElement(By.xpath("//*[@id='pet2.dateDayName']")).sendKeys(dobArray[0]);
			driver.get().findElement(By.xpath("//*[@id='pet2.dateMonthName']")).clear();
			driver.get().findElement(By.xpath("//*[@id='pet2.dateMonthName']")).sendKeys(dobArray[1]);
			driver.get().findElement(By.xpath("//*[@id='pet2.dateYearName']")).clear();
			driver.get().findElement(By.xpath("//*[@id='pet2.dateYearName']")).sendKeys(dobArray[2]);
			((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//label[contains(@for,'female_radio_1pet2')]")));	
			((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//label[contains(@for,'female_radio_1pet2')]")));
			((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//button[text()='Your details']")));	
			((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//button[text()='Your details']")));
			Thread.sleep(2500);
			String errorMessageAtTheField = driver.get().findElement(By.xpath("//div[@class='pet-details-form-cat']/div/div/div/div[@class='error-message']")).getText().trim();
		//	String errorMessageAtTheTop = driver.get().findElement(By.xpath("//*[@id='errorAlertContainer_2']/div/div/div/div/div")).getText();
			String errorMessageAtTheFieldFromExcel = recordset.getField("ErrorMessageAtTheField");
		//	String errorMessageAtTheTopFromExcel = recordset.getField("ErrorMessageAtTheTop");
			softAssert.assertEquals(errorMessageAtTheField, errorMessageAtTheFieldFromExcel);
		//	softAssert.assertEquals(errorMessageAtTheTop, errorMessageAtTheTopFromExcel);
			softAssert.assertAll();
			dbConnection.closeConnection();
		}
	}
}