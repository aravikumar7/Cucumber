/**
 * 
 */
package com.argos.pet.quotebuy.regression.tests;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.testng.annotations.Parameters;
import org.testng.asserts.SoftAssert;

import com.codoid.products.fillo.Recordset;
import com.argos.pet.quotebuy.regression.common.code.dbconnection.DBConnectionRegressionCommonCode;
import com.argos.pet.quotebuy.regression.common.code.pages.EditPetDetailsPage;
import com.argos.pet.quotebuy.regression.common.code.pages.YourQuoteSummaryPage;
import com.argos.pet.quotebuy.regression.common.code.tests.YourPetDetailsTest;
import com.argos.pet.quotebuy.regression.common.code.utilities.TestBase;
import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;


/**
 * @author d23747
 *
 */
public class EditPetDetailsTest_717 extends TestBase {

	DBConnectionRegressionCommonCode dbConnection;
	Utilities utilities;
	EditPetDetailsPage editPetDetailsPage;
	String className;
	public String ClassName;
	SoftAssert softAssert;
	YourQuoteSummaryPage yourQuoteSummaryPage;
	//static String[] uniqueTestDataArray;
	 ThreadLocal<String[]> regressionTestDataArray;
	
	@Parameters ("ClassName")
	public void initiateEditPetDetailsTest_717(String ClassName) throws Exception
	{
		utilities = new Utilities();
		editPetDetailsPage = new EditPetDetailsPage(driver);
		softAssert = new SoftAssert();
		yourQuoteSummaryPage = new YourQuoteSummaryPage(driver);
		regressionTestDataArray = YourPetDetailsTest.regressionTestDataArray;
		className = utilities.getClassName(ClassName);
		String  strQuery = "Select * from EditCover where TestClassName = '" + className + "'";
		dbConnection = new DBConnectionRegressionCommonCode();
		Recordset recordset = dbConnection.recordset(strQuery);
		recordset.next();
		recordset.moveFirst();

		editPetDetailsPage.clickEditPetDetailsLink();
		Thread.sleep(1000);
		editPetDetailsPage.setPetName("not to be changed");
		//editPetDetailsPage.populateDobDay("03");
		//editPetDetailsPage.populateDobMonth("02");
		//editPetDetailsPage.populateDobYear("2018");
	//	editPetDetailsPage.populatedateOfBirth("03/02/2018");
		
		editPetDetailsPage.selectDogCrossBreed();
		//editPetDetailsPage.whatBreedQuestionTextField();
		//driver.get().switchTo().activeElement().sendKeys(Keys.BACK_SPACE);
		editPetDetailsPage.populateBreedType("Afghan Hound Cross");
		//editPetDetailsPage.selectFromList();
		driver.get().switchTo().activeElement().sendKeys(Keys.TAB);
		editPetDetailsPage.clickCancelButton();
		Thread.sleep(1500);

		String PetNameEntered = (regressionTestDataArray.get())[0];
		String BreedEntered = (regressionTestDataArray.get())[1];
		String DOBEntered = (regressionTestDataArray.get())[5];
		String PetNameFromWeb = yourQuoteSummaryPage.getPetName();
		String str=driver.get().findElement(By.xpath("(//span[@class='summary'])[1]")).getText();
		String[] parts = str.split("�");
		String BreedFromWeb = parts[3];
	//	String DOBFromWeb = yourQuoteSummaryPage.getPetDOB();
		System.out.println(":"+PetNameFromWeb+":"+PetNameEntered+":");
		System.out.println(":"+BreedFromWeb+":"+BreedEntered+":");
		softAssert.assertEquals(PetNameFromWeb.trim(), PetNameEntered.trim());
		softAssert.assertEquals(BreedFromWeb.trim(), BreedEntered.trim());
		softAssert.assertAll();
		dbConnection.closeConnection();
	}
}