package com.argos.pet.quotebuy.regression.tests;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.asserts.SoftAssert;

import com.argos.pet.quotebuy.regression.common.code.dbconnection.DBConnection;
import com.argos.pet.quotebuy.regression.common.code.dbconnection.DBConnectionRegressionCommonCode;
import com.argos.pet.quotebuy.regression.common.code.utilities.TestBase;
import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;
import com.codoid.products.fillo.Recordset;


public class MultiPetYourPetDetailsTests_407_Test extends TestBase{

	DBConnection dbConnection;
	Utilities utilities;
	Actions actions;
	String[] dobArray;
	String DOB_FromCoverStartDate;
	SoftAssert softAssert;
	String dateOfBirth;

	public void initiateMultiPetYourPetDetailsTests_407(String ClassName) throws Exception
	{
		utilities = new Utilities();
		dbConnection = new DBConnection();
		softAssert = new SoftAssert();
		actions = new Actions(driver.get());
	//	utilities.waitElement(driver.get().findElement(By.xpath("//*[@id='yourPetsSubmitButton']")), driver);
	//	Thread.sleep(3000);
		String className = utilities.getClassName(ClassName);
		String strQuery = "Select * from MoreAboutYourPet where TestClassName = '" + className + "'";
		Recordset recordset = dbConnection.recordset(strQuery);
		recordset.next();
		recordset.moveFirst();
		if (recordset.getField("MultiPet").equalsIgnoreCase("Yes"))
		{
			strQuery = "Select * from MultiPet where TestClassName = '" + className + "'";
			dbConnection = new DBConnection();
			recordset = dbConnection.recordset(strQuery);
			recordset.next();
			recordset.moveFirst();
			Thread.sleep(2500);
			((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", 	driver.get().findElement(By.xpath("//button[text()='Add another pet']")));
			((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", 	driver.get().findElement(By.xpath("//button[text()='Add another pet']")));
		//	utilities.waitElement(driver.get().findElement(By.xpath("//*[@id='pet2.pet_name']")), driver);
			((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//*[@id='pet2.pet_name']")));
			driver.get().findElement(By.xpath("//*[@id='pet2.pet_name']")).sendKeys(recordset.getField("MultiPetName_1"));

			if (recordset.getField("MultiPetType_1").equalsIgnoreCase("Dog"))
			{
				((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//*[@for='radio_dog_pet2']")));
				((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//*[@for='radio_dog_pet2']")));
				utilities.waitElement(driver.get().findElement(By.xpath("//*[@for='breed_pet2']")), driver);
					if (recordset.getField("MultiPetTypeOfDog_1").equalsIgnoreCase("Breed"))
				{	
						((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//*[@for='breed_pet2']")));
						Actions builder = new Actions(driver.get());
						driver.get().findElement(By.xpath("//div[@id='pet2.pet_breed']/div/div/div/div/input")).sendKeys("African Crested Dog");
						Thread.sleep(1000);
						builder.sendKeys(Keys.ENTER).perform();
				}
				else if (recordset.getField("MultiPetTypeOfDog_1").equalsIgnoreCase("Crossbreed"))
				{
					Actions builder = new Actions(driver.get());
					driver.get().findElement(By.xpath("//div[@id='pet2.pet_breed']/div/div/div/div/input")).sendKeys("African Crested Dog Cross");
					Thread.sleep(1000);
					builder.sendKeys(Keys.ENTER).perform();
				}
				else if (recordset.getField("MultiPetTypeOfDog_1").equalsIgnoreCase("Mongrel"))
				{
					Thread.sleep(1000);
					((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//*[@for='mongrel_pet2']")));
					((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//*[@for='mongrel_pet2']")));
		
					((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//*[@for='mongrel-smallpet2']")));
					((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//*[@for='mongrel-smallpet2']")));
		
				}
			}

			else
			{
				((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//*[@for='cat-other_pet2']")));
				((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//*[@for='cat-other_pet2']")));
				
				Actions builder = new Actions(driver.get());
					driver.get().findElement(By.xpath("//div[@id='pet2.pet_breed']/div/div/div/div/input")).sendKeys("Angora");
					Thread.sleep(1000);
					builder.sendKeys(Keys.ENTER).perform();
				
			}
			DOB_FromCoverStartDate = recordset.getField("DOB_FromCoverStartDate");
			dobArray = utilities.getDOB(DOB_FromCoverStartDate);
			driver.get().findElement(By.xpath("//*[@id='pet2.dateDayName']")).clear();
			driver.get().findElement(By.xpath("//*[@id='pet2.dateDayName']")).sendKeys(dobArray[0]);
			driver.get().findElement(By.xpath("//*[@id='pet2.dateMonthName']")).clear();
			driver.get().findElement(By.xpath("//*[@id='pet2.dateMonthName']")).sendKeys(dobArray[1]);
			driver.get().findElement(By.xpath("//*[@id='pet2.dateYearName']")).clear();
			driver.get().findElement(By.xpath("//*[@id='pet2.dateYearName']")).sendKeys(dobArray[2]);
			if (recordset.getField("MultiPetSex_1").equalsIgnoreCase("Male"))
			{
				((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//label[contains(@for,'male_radio_1pet2')]")));
				((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//label[contains(@for,'male_radio_1pet2')]")));
			}
			else
			{
				((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//label[contains(@for,'female_radio_1pet2')]")));	
				((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//label[contains(@for,'female_radio_1pet2')]")));
			}
			
		//	((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.id("pet1.pet_cost")));
		//	((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.id("pet1.pet_cost")));
		//	driver.get().findElement(By.id("pet1.pet_cost")).sendKeys(Keys.SPACE);

		//	((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//div[text()='Next']//parent::button")));	
		//	((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//div[text()='Next']//parent::button")));
			Thread.sleep(1000);
			driver.get().findElement(By.xpath("//*[@id='pet2.pet_cost']")).sendKeys(Keys.BACK_SPACE);
			driver.get().findElement(By.xpath("//*[@id='pet2.pet_cost']")).sendKeys("100");
	
			
			((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("(//button[text()='Remove pet'])[2]")));	
			((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("(//button[text()='Remove pet'])[2]")));
		
			WebElement removePetButton = driver.get().findElement(By.xpath("//button[@class='btn btn-primary remove-pet-cta']"));
			utilities.waitElement(removePetButton, driver);
			removePetButton.click();
			Thread.sleep(2500);
			softAssert.assertFalse(driver.get().findElements(By.xpath("//button[text()='Remove pet']")).size()>0);
	//		driver.get().findElement(By.xpath("//*[@id='headingOne_1']/div/button")).click();
			//softAssert.assertFalse(driver.get().findElement(By.xpath("//*[@id='yourPetsSubmitButton']")).isEnabled());
			softAssert.assertAll();
			dbConnection.closeConnection();
		}
	}
}