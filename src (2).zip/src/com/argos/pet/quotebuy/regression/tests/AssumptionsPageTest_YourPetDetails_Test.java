/**
 * 
 */
package com.argos.pet.quotebuy.regression.tests;

import java.io.IOException;

import com.argos.pet.quotebuy.regression.common.code.dbconnection.DBConnection;
import com.argos.pet.quotebuy.regression.common.code.pages.AssumptionsPage;
import com.argos.pet.quotebuy.regression.common.code.utilities.TestBase;
import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Recordset;


/**
 * @author d23747
 *
 */
public class AssumptionsPageTest_YourPetDetails_Test extends TestBase {

	AssumptionsPage assumptionsPage;
	DBConnection dbConnection;
	TestBase testBase;
	
	public void testAssumptionsPage() throws FilloException, IOException
	{
		String  strQuery = "Select * from Assumptions";
		dbConnection = new DBConnection();
		Recordset recordset = dbConnection.recordset(strQuery);
		recordset.next();
		recordset.moveFirst();
		try
		{
			assumptionsPage = new AssumptionsPage(driver);
			
			if (recordset.getField("DogMicrochipped").equalsIgnoreCase("Yes"))
			{
			assumptionsPage.getDogCatMicrochippedYes();
			}
			else
			{
				assumptionsPage.getDogCatMicrochippedNo();
			}
			
			if (recordset.getField("DogWorking").equalsIgnoreCase("Yes"))
			{
			assumptionsPage.setDogWorkingYes();
			}
			else
			{
				assumptionsPage.setDogWorkingNo();
			}
			
			if (recordset.getField("DogFromRescueHome").equalsIgnoreCase("Yes"))
			{
			assumptionsPage.getDogCatFromRescueHomeYes();
			}
			else
			{
				assumptionsPage.getDogCatFromRescueHomeNo();
			}
			
			if (recordset.getField("DogAddressSameAsPolicyHolder").equalsIgnoreCase("Yes"))
			{
			assumptionsPage.getDogCatAddressSameAsPolicyHolderYes();
			}
			else
			{
				assumptionsPage.getDogCatAddressSameAsPolicyHolderNo();
			}
			
			if (recordset.getField("DogVeterinaryNeeds").equalsIgnoreCase("Yes"))
			{
			assumptionsPage.getDogCatVeterinaryNeedsYes();
			}
			else
			{
				assumptionsPage.getDogCatVeterinaryNeedsNo();
			}
			
			if (recordset.getField("DogAlchoholSoldPremises").equalsIgnoreCase("Yes"))
			{
			assumptionsPage.setDogAlchoholSoldPremisesYes();
			}
			else
			{
				assumptionsPage.setDogAlchoholSoldPremisesNo();
			}
			
			if (recordset.getField("DogBadBehaviour").equalsIgnoreCase("Yes"))
			{
			assumptionsPage.setDogBadBehaviourYes();
			}
			else
			{
				assumptionsPage.setDogBadBehaviourNo();
			}
			
			if (recordset.getField("CancelChanges").equalsIgnoreCase("Yes"))
			{
			assumptionsPage.setBackButton();
			}
			else
			{
				assumptionsPage.setBackButton();
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		dbConnection.closeConnection();
	}
}
