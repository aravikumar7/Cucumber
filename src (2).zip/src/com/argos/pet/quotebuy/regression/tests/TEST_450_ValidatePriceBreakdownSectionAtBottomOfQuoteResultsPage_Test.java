/**
 * 
 */
package com.argos.pet.quotebuy.regression.tests;

import org.openqa.selenium.By;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.argos.pet.quotebuy.regression.common.code.dbconnection.DBConnection;
import com.argos.pet.quotebuy.regression.common.code.pages.YourCoverPage;
import com.argos.pet.quotebuy.regression.common.code.tests.AlmostThereTest;
import com.argos.pet.quotebuy.regression.common.code.tests.ConfirmationTest;
import com.argos.pet.quotebuy.regression.common.code.tests.CustomerDetailsTest;
import com.argos.pet.quotebuy.regression.common.code.tests.MoreAboutYourPetTest;
import com.argos.pet.quotebuy.regression.common.code.tests.MultiPetYourCoverTest;
import com.argos.pet.quotebuy.regression.common.code.tests.MultiPetYourQuoteSummaryTest;
import com.argos.pet.quotebuy.regression.common.code.tests.PaymentTest;
import com.argos.pet.quotebuy.regression.common.code.tests.PreExistingConditionsTest;
import com.argos.pet.quotebuy.regression.common.code.tests.YourCoverTest;
import com.argos.pet.quotebuy.regression.common.code.tests.YourPetDetailsTest;
import com.argos.pet.quotebuy.regression.common.code.tests.YourQuoteSummaryTest;
import com.argos.pet.quotebuy.regression.common.code.utilities.TestBase;
import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;
import com.codoid.products.fillo.Recordset;


/**
 * @author d23747
 *
 */

public class TEST_450_ValidatePriceBreakdownSectionAtBottomOfQuoteResultsPage_Test extends TestBase {

	DBConnection dbConnection;
	YourPetDetailsTest yourPetDetailsTest;
	MoreAboutYourPetTest moreAboutYourPetTest;
	CustomerDetailsTest customerDetailsTest;
	YourCoverTest yourCoverTest;
	YourCoverPage yourCoverPage;
	MultiPetYourCoverTest multiPetYourCoverTest;
	YourQuoteSummaryTest yourQuoteSummaryTest;
	MultiPetYourQuoteSummaryTest multiPetYourQuoteSummaryTest;
	PreExistingConditionsTest preExistingConditionsTest;
	PaymentTest paymentPageTest;
	AlmostThereTest almostThereTest;
	ConfirmationTest confirmationTest;
	Utilities utilities;
	SoftAssert softAssert;
	String numberOfMultiPetsString;
	static String[] uniqueTestDataArray;
	public String TextToWrite;
	static int numberOfMultiPets = 2;

	public String classNameString() throws Exception {
		String className = this.getClass().getSimpleName();
		return className;
	}

	@Test(priority = 0)
	public void initiate_TEST_450_ValidatePriceBreakdownSectionAtBottomOfQuoteResultsPage() {
		try {
			dbConnection = new DBConnection();
			utilities = new Utilities();
			softAssert = new SoftAssert();
			TextToWrite = "Test: " + this.getClass().getSimpleName();
			utilities.Filewriter(TextToWrite);
			String strQuery = "Select * from MultiPet where TestClassName = '" + this.getClass().getSimpleName() + "'";
			Recordset recordset = dbConnection.recordset(strQuery);
			recordset.next();
			recordset.moveFirst();
			String multiPetYesNo = recordset.getField("MultiPet");
			numberOfMultiPetsString = recordset.getField("NumberOfMultiPets");
			int numberOfMultiPetsInt = Integer.valueOf(numberOfMultiPetsString);
			numberOfMultiPetsInt = numberOfMultiPetsInt + 1;
			yourPetDetailsTest = new YourPetDetailsTest();
			yourPetDetailsTest.initiateYourPetDetailsTest(classNameString());
			moreAboutYourPetTest = new MoreAboutYourPetTest();
			moreAboutYourPetTest.initiateMoreAboutYourPetTest(classNameString());
			customerDetailsTest = new CustomerDetailsTest();
			customerDetailsTest.initiateCustomerDetailsTest(classNameString());
			if (multiPetYesNo.equalsIgnoreCase("Yes")) {
				multiPetYourCoverTest = new MultiPetYourCoverTest();
				multiPetYourCoverTest.initiateMultiPetYourCoverTest(classNameString());
			}
			yourCoverTest = new YourCoverTest();
			yourCoverTest.testYourCover(classNameString());

			Thread.sleep(2500);
		//	driver.findElement(By.xpath("//*[@id='backButton']")).click();
			yourCoverPage = new YourCoverPage(driver);
		//	String priceBreakdownHeading = yourCoverPage.getPriceBreakdownHeading();
		//	softAssert.assertEquals(priceBreakdownHeading, "Price breakdown");

			String petNameOnWebsite = yourCoverPage.getPetName();
			softAssert.assertEquals(petNameOnWebsite, "abc def");

			String coverTypeOnWebsite = yourCoverPage.getCoverType();
			softAssert.assertEquals(coverTypeOnWebsite, "Time Limited �3,000");

			String monthlyPrice = yourCoverPage.getTotalMonthlyCost();

			String yearlyPrice = yourCoverPage.getTotalYearlyCost();
			TextToWrite = "Monthly Price is: " + monthlyPrice + "	Yearly Price is: " + yearlyPrice
					+ "	Pet Name On Website is: " + petNameOnWebsite + "	Cover Type On Website is: "
					+ coverTypeOnWebsite;
			dbConnection.closeConnection();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
			utilities.onTestFailure();
		}
	}
}