/**
 * 
 */
package com.argos.pet.quotebuy.regression.tests;

import java.io.IOException;

import com.argos.pet.quotebuy.regression.common.code.dbconnection.DBConnectionRegressionCommonCode;
import com.argos.pet.quotebuy.regression.common.code.pages.PaymentPage;
import com.argos.pet.quotebuy.regression.common.code.utilities.TestBase;
import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;
import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Recordset;


/**
 * @author d23747
 *
 */
public class PaymentPageTest_YourPetDetails extends TestBase {

	PaymentPage paymentPage;
	DBConnectionRegressionCommonCode dbConnection;
	Utilities utilities;
	
	public void testPaymentPage() throws FilloException, IOException, InterruptedException
	{
		String  strQuery = "Select * from Payment";
		dbConnection = new DBConnectionRegressionCommonCode();
		Recordset recordset = dbConnection.recordset(strQuery);
		recordset.next();
		recordset.moveFirst();
		paymentPage = new PaymentPage(driver);
		paymentPage.clickPayMonthlyRadioButton();
		paymentPage.clickDirectDebitRadioButton();
		paymentPage.populateDirectDebitAccountName(recordset.getField("AccountName"));
		paymentPage.populateSortCode1(recordset.getField("SortCode1"));
		paymentPage.populateSortCode2(recordset.getField("SortCode2"));
		paymentPage.populateSortCode3(recordset.getField("SortCode3"));
		paymentPage.populateAccountNumber(recordset.getField("AccountNumber"));
		paymentPage.populatePreferredPaymentDate(recordset.getField("PreferredPaymentDate"));
		paymentPage.clickDirectDebitConfirmationTickBox();
		paymentPage.clickConfirmPaymentButton();
		dbConnection.closeConnection();
	}
}
