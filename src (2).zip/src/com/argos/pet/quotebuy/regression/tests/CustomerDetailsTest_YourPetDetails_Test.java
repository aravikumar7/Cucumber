package com.argos.pet.quotebuy.regression.tests;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Parameters;
import org.testng.asserts.SoftAssert;
import org.openqa.selenium.JavascriptExecutor;
import com.codoid.products.fillo.Recordset;
import com.argos.pet.quotebuy.regression.common.code.dbconnection.DBConnection;
import com.argos.pet.quotebuy.regression.common.code.pages.CustomerDetailsPage;
import com.argos.pet.quotebuy.regression.common.code.utilities.TestBase;
import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;


public class CustomerDetailsTest_YourPetDetails_Test extends TestBase {

	DBConnection dbConnection;
	CustomerDetailsPage customerDetails;
	Utilities utilities;
	public String nextMonth;
	String[] DOBArray;
	String coverStartDate;
	String className;
	public String ClassName;
	SoftAssert softAssert;

	@Parameters ("ClassName")
	public void initiateCustomerDetailsTest(String ClassName) throws Exception
	{
		customerDetails = new CustomerDetailsPage(driver);
		dbConnection = new DBConnection();
		softAssert = new SoftAssert();
		utilities = new Utilities();
		className = utilities.getClassName(ClassName);
		String  strQuery = "Select * from CustomerDetails where TestClassName = '" + className + "'";
		Recordset recordset = dbConnection.recordset(strQuery);
		recordset.next();
		recordset.moveFirst();
		if (utilities.isElementPresent(By.xpath("//*[@id='yourPetsSubmitButton']"), driver))
		{
			driver.get().findElement(By.xpath("//*[@id='yourPetsSubmitButton']")).click();
		}
		nextMonth = utilities.getNextMonth();
		//String CoverStartDate_NumberOfDaysInFuture = recordset.getField("CoverStartDate_NumberOfDaysInFuture");
		//coverStartDate = utilities.getCoverStartDate(CoverStartDate_NumberOfDaysInFuture);
		customerDetails = new CustomerDetailsPage(driver);
		//+ Moved to Payment
		/*
		customerDetails.selectCustomerTitle(recordset.getField("Title"));
		customerDetails.populateCustomerFirstName(recordset.getField("FirstName"));
		customerDetails.populateCustomerLastName(recordset.getField("LastName"));
		String dob = recordset.getField("DOB_FromCoverStartDate");
		DOBArray = utilities.getDOB(dob);
		customerDetails.populateCustomerDOBDay(DOBArray[0]);
		customerDetails.populateCustomerDOBMonth(DOBArray[1]);
		customerDetails.populateCustomerDOBYear(DOBArray[2]);
		*/
		//- Moved to Payment
		customerDetails.populateCustomerEmail(recordset.getField("Email"));
		customerDetails.populateCustomerHouseNumberName(recordset.getField("HouseNumberName"));
		customerDetails.populateCustomerPostcode(recordset.getField("Postcode"));
		customerDetails.clickFindAddressButton();
		//if (utilities.isElementPresent(By.xpath("//*[@id='buildingRefError']/p"), driver))
		customerDetails.clickFloatingToasterPanelSuccessClose();
		//if (utilities.isElementPresent(By.xpath("//*[@id='buildingRefError']/p"), driver))
		/*if (driver.get().findElement(By.xpath("//h4[@class='toast-content__title']")).isDisplayed())
		{
			String houseNumberErrorTextOnWeb = customerDetails.getHouseNumberNameErrorText();
			String houseNumberErrorTextFromExcel = recordset.getField("HouseNumberNameErrorText");
			softAssert.assertEquals(houseNumberErrorTextOnWeb, houseNumberErrorTextFromExcel);
			customerDetails.clickFloatingToasterPanelClose();
			customerDetails.populateCustomerHouseNumberName("2");
			customerDetails.populateCustomerPostcode("YO15 2QP");
			Thread.sleep(1600);
			customerDetails.clickFindAddressButton();
			softAssert.assertAll();
		}*/
		
		
		boolean errortoaster=driver.get().findElements(By.xpath("//div[@class='toast-content__body' and contains(text(),'Invalid')]")).size()>0;
		if(errortoaster){
			System.out.println("Error toaster");
			WebElement errortoatser=driver.get().findElement(By.xpath("//*[@id='root']/div/div/div/button"));
			((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", errortoatser);
			((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", errortoatser);
		}
		
		
		boolean addressError=driver.get().findElements(By.xpath("//h4[text()='Error']")).size()>0;
		
	if(addressError || errortoaster){	
		String AddressNotFoundErrorText;
	if(addressError){
		AddressNotFoundErrorText = customerDetails.getNoResultsError();
		System.out.println("Address Error toaster");
		driver.get().findElement(By.xpath("//*[@id='root']/div/div/div/button")).click();
	}
		else{
		 AddressNotFoundErrorText = "";
		}
		//	if (AddressNotFoundErrorText.equalsIgnoreCase("No results found for that house number/name and postcode."))
			{
				System.out.println("Populating default");
				customerDetails.populateCustomerHouseNumberName("16");
				customerDetails.populateCustomerPostcode("WD7 8HT");
				customerDetails.clickFindAddressButton();
				customerDetails.clickFloatingToasterPanelSuccessClose();
				Thread.sleep(700);
				utilities.Filewriter(AddressNotFoundErrorText + "Hence new address used: CustomerHouseNumber = 16 & CustomerPostcode = WD7 8HT");
			}
		}
	
		
	
		if (recordset.getField("PromoCheckerLink").equalsIgnoreCase("Yes"))
		{
			Thread.sleep(700);
			driver.get().switchTo().activeElement().sendKeys(Keys.TAB);
			//driver.get().switchTo().activeElement().sendKeys(Keys.ENTER);
			customerDetails.selectPromoCheckerLink();
			Thread.sleep(800);
			customerDetails.populateCustomerPromotionalCode(recordset.getField("PromotionalCode"));
			Thread.sleep(700);
			customerDetails.applyCustomerPromotionalCode();
			//driver.get().switchTo().activeElement().sendKeys(Keys.TAB);
			Thread.sleep(700);
		}

		if(driver.get().findElement(By.xpath("//button[@type='submit']")).isEnabled()){
		customerDetails.clickGetAQuoteButton();
		}
		dbConnection.closeConnection();
	}
}