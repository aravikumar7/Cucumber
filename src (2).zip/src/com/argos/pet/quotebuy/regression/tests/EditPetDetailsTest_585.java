/**
 * 
 */
package com.argos.pet.quotebuy.regression.tests;

import org.openqa.selenium.Keys;
import org.testng.annotations.Parameters;

import com.argos.pet.quotebuy.regression.common.code.dbconnection.DBConnectionRegressionCommonCode;
import com.argos.pet.quotebuy.regression.common.code.pages.EditPetDetailsPage;
import com.argos.pet.quotebuy.regression.common.code.utilities.TestBase;
import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;
import com.codoid.products.fillo.Recordset;

/**
 * @author d23747
 *
 */
public class EditPetDetailsTest_585 extends TestBase {

	DBConnectionRegressionCommonCode dbConnection;
	Utilities utilities;
	EditPetDetailsPage editPetDetailsPage;
	String className;
	public String ClassName;

	@Parameters ("ClassName")
	public void initiateEditPetDetailsTest_585(String ClassName) throws Exception
	{
		utilities = new Utilities();
		editPetDetailsPage = new EditPetDetailsPage(driver);
		className = utilities.getClassName(ClassName);
		String  strQuery = "Select * from EditCover where TestClassName = '" + className + "'";
		dbConnection = new DBConnectionRegressionCommonCode();
		Recordset recordset = dbConnection.recordset(strQuery);
		recordset.next();
		recordset.moveFirst();
		
		editPetDetailsPage.clickEditPetDetailsLink();
//		editPetDetailsPage.setPetTypeCat();
//		Thread.sleep(700);
//		editPetDetailsPage.setPetTypeDog();
//		Thread.sleep(700);
		editPetDetailsPage.selectDogBreed();
		Thread.sleep(700);
	//	editPetDetailsPage.whatBreedQuestionTextField();
	//	driver.switchTo().activeElement().sendKeys(Keys.BACK_SPACE);
		editPetDetailsPage.populateBreedType(recordset.getField("DogBreedType"));
	//	editPetDetailsPage.selectFromList();
		editPetDetailsPage.populatePetCost(recordset.getField("CostOfThePet"));
		editPetDetailsPage.clickSaveCloseButton();
		dbConnection.closeConnection();
	}
}