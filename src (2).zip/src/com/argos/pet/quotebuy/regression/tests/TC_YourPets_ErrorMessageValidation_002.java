/**
 * 
 */
package com.argos.pet.quotebuy.regression.tests;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.argos.pet.quotebuy.regression.common.code.pages.YourPetDetailsPage;
import com.argos.pet.quotebuy.regression.common.code.utilities.TestBase;



/**
 * @author d23747
 *
 */
public class TC_YourPets_ErrorMessageValidation_002 extends TestBase {

	YourPetDetailsPage yourPetDetailsPage;

	@Test (priority = 0)
	public void testDogNameIsRequired()
	{
		try
		{
		yourPetDetailsPage = new YourPetDetailsPage(driver);
		yourPetDetailsPage.setPetTypeDog();
		String petNameErrorText = yourPetDetailsPage.setPetNameErrorMessage();
		Assert.assertEquals(petNameErrorText, "Pet name - This field is required.");
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	@Test (priority = 1)
	public void testCatNameIsRequired()
	{
		yourPetDetailsPage = new YourPetDetailsPage(driver);
		yourPetDetailsPage.setPetTypeCat();
	}

	@Test (enabled = false)
	public void testPetNameWithSpace() throws InterruptedException
	{
		yourPetDetailsPage = new YourPetDetailsPage(driver);
		yourPetDetailsPage.setPetName(" ");
	}

	@Test (enabled = false)
	public void testDogNameFieldLabel()
	{
		//refresh;
		yourPetDetailsPage = new YourPetDetailsPage(driver);
		yourPetDetailsPage.setPetTypeDog();
	}

	@Test (enabled = false)
	public void testCatNameFieldLabel()
	{
		yourPetDetailsPage = new YourPetDetailsPage(driver);
		yourPetDetailsPage.setPetTypeCat();
	}
}
