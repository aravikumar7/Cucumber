/**
 * 
 */
package com.argos.pet.quotebuy.regression.tests;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.argos.pet.quotebuy.regression.common.code.dbconnection.DBConnection;
import com.argos.pet.quotebuy.regression.common.code.pages.YourCoverPage;
import com.argos.pet.quotebuy.regression.common.code.pages.YourQuoteSummaryPage;
import com.argos.pet.quotebuy.regression.common.code.tests.CustomerDetailsTest;
import com.argos.pet.quotebuy.regression.common.code.tests.MoreAboutYourPetTest;
import com.argos.pet.quotebuy.regression.common.code.tests.MultiPetYourCoverTest;
import com.argos.pet.quotebuy.regression.common.code.tests.MultiPetYourQuoteSummaryTest;
import com.argos.pet.quotebuy.regression.common.code.tests.PaymentTest;
import com.argos.pet.quotebuy.regression.common.code.tests.PreExistingConditionsTest;
import com.argos.pet.quotebuy.regression.common.code.tests.YourCoverTest;
import com.argos.pet.quotebuy.regression.common.code.tests.YourPetDetailsTest;
import com.argos.pet.quotebuy.regression.common.code.tests.YourQuoteSummaryTest;
import com.argos.pet.quotebuy.regression.common.code.utilities.TestBase;
import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;
import com.codoid.products.fillo.Recordset;


/**
 * @author d23747
 *
 */

public class TEST_694_ValidateSaveCloseButtonInQuoteReview_Test extends TestBase {

	DBConnection dbConnection;
	YourPetDetailsTest yourPetDetailsTest;
	MoreAboutYourPetTest moreAboutYourPetTest;
	CustomerDetailsTest customerDetailsTest;
	YourCoverTest yourCoverTest;
	MultiPetYourCoverTest multiPetYourCoverTest;
	YourQuoteSummaryTest yourQuoteSummaryTest;
	MultiPetYourQuoteSummaryTest multiPetYourQuoteSummaryTest;
	PreExistingConditionsTest preExistingConditionsTest;
	PaymentTest paymentPageTest;
	YourQuoteSummaryPage yourQuoteSummaryPage;
	YourCoverPage yourCoverPage;
	Utilities utilities;
	SoftAssert softAssert;
	Actions actions;
	String numberOfMultiPetsString;
	public String TextToWrite;
	static int numberOfMultiPets = 2;

	public String classNameString() throws Exception
	{
		String className = this.getClass().getSimpleName();
		return className;
	}

	@Test (priority = 0)
	public void initiate_TEST_694_ValidateSaveCloseButtonInQuoteReview()
	{
		try
		{
			dbConnection = new DBConnection();
			utilities = new Utilities();
			softAssert = new SoftAssert();
			actions = new Actions(driver.get());
			TextToWrite = "Test: " + this.getClass().getSimpleName();
			utilities.Filewriter(TextToWrite);
			String  strQuery = "Select * from MultiPet where TestClassName = '" + this.getClass().getSimpleName() + "'";
			Recordset recordset = dbConnection.recordset(strQuery);
			recordset.next();
			recordset.moveFirst();
			String multiPetYesNo = recordset.getField("MultiPet");
			numberOfMultiPetsString = recordset.getField("NumberOfMultiPets");
			int numberOfMultiPetsInt = Integer.valueOf(numberOfMultiPetsString);
			numberOfMultiPetsInt = numberOfMultiPetsInt + 1;
			yourPetDetailsTest = new YourPetDetailsTest();
			yourPetDetailsTest.initiateYourPetDetailsTest(classNameString());
			moreAboutYourPetTest = new MoreAboutYourPetTest();
			moreAboutYourPetTest.initiateMoreAboutYourPetTest(classNameString());
			customerDetailsTest = new CustomerDetailsTest();
			customerDetailsTest.initiateCustomerDetailsTest(classNameString());
			if (multiPetYesNo.equalsIgnoreCase("Yes"))
			{
				multiPetYourCoverTest = new MultiPetYourCoverTest();
				multiPetYourCoverTest.initiateMultiPetYourCoverTest(classNameString());
			}
			yourCoverTest = new YourCoverTest();
			yourCoverTest.testYourCover(classNameString());
			
			yourQuoteSummaryPage = new YourQuoteSummaryPage(driver);
//			WebElement clickChangeCoverLink = driver.get().findElement(By.xpath("(//img[@src='/img/svg-icons/pencil.svg'])[3]"));
			//	utilities.waitElement(clickChangeCoverLink, driver);
				yourQuoteSummaryPage.clickChangeCoverLink();
				Thread.sleep(1500);
			//	WebElement timeLimitedButton = driver.get().findElement(By.xpath("//*[@id='chooseProductLevel_1']/div/div[1]/button"));
			//	utilities.waitElement(timeLimitedButton, driver);
				yourCoverPage = new YourCoverPage(driver);
				yourCoverPage.clickCoverType();
				yourCoverPage.clickChooseLifetimeButton();
			//	WebElement covers = driver.get().findElement(By.xpath("//*[@id='coverLevel_103']"));
			//	utilities.waitElement(covers, driver);
				yourCoverPage.clickRadio�1000Button();
				Thread.sleep(700);
				yourCoverPage.clickSaveCloseButton();
				TextToWrite = "Lifetime �1000 selected";
				utilities.Filewriter(TextToWrite);
				Thread.sleep(1500);
				yourCoverPage.clickCloseToasterButton();
				WebElement payNowButton = driver.get().findElement(By.xpath("//button[@class='btn btn-primary']"));
				utilities.waitElement(payNowButton, driver);
				
				yourQuoteSummaryPage.clickChangeCoverLink();
			//	timeLimitedButton = driver.get().findElement(By.xpath("//*[@id='chooseProductLevel_1']/div/div[1]/button"));
			//	utilities.waitElement(timeLimitedButton, driver);
				Thread.sleep(700);
				yourCoverPage.clickCoverType();
				yourCoverPage.clickChooseLifetimeButton();
				Thread.sleep(1500);
			//	covers = driver.get().findElement(By.xpath("//*[@id='coverLevel_103']"));
		//		utilities.waitElement(covers, driver);
				yourCoverPage.clickRadio�4500Button();
			//	Thread.sleep(700);
				yourCoverPage.clickSaveCloseButton();
				TextToWrite = "Lifetime �4500 selected";
				utilities.Filewriter(TextToWrite);
				Thread.sleep(1500);
				yourCoverPage.clickCloseToasterButton();
				payNowButton = driver.get().findElement(By.xpath("//button[@class='btn btn-primary']"));
				utilities.waitElement(payNowButton, driver);
				
				yourQuoteSummaryPage.clickChangeCoverLink();
				//timeLimitedButton = driver.get().findElement(By.xpath("//*[@id='chooseProductLevel_1']/div/div[1]/button"));
				//utilities.waitElement(timeLimitedButton, driver);
				Thread.sleep(700);
				yourCoverPage.clickCoverType();
				yourCoverPage.clickChooseLifetimeButton();
				//covers = driver.get().findElement(By.xpath("//*[@id='coverLevel_103']"));
				//utilities.waitElement(covers, driver);
				Thread.sleep(700);
				yourCoverPage.clickRadio�7000Button();
			//	Thread.sleep(700);
				yourCoverPage.clickSaveCloseButton();
				TextToWrite = "Lifetime �7000 selected";
				utilities.Filewriter(TextToWrite);
				Thread.sleep(1500);
				yourCoverPage.clickCloseToasterButton();
				payNowButton = driver.get().findElement(By.xpath("//button[@class='btn btn-primary']"));
				utilities.waitElement(payNowButton, driver);
				
				yourQuoteSummaryPage.clickChangeCoverLink();
		//		timeLimitedButton = driver.get().findElement(By.xpath("//*[@id='chooseProductLevel_1']/div/div[1]/button"));
		//		utilities.waitElement(timeLimitedButton, driver);
				Thread.sleep(700);
				yourCoverPage.clickCoverType();
				yourCoverPage.clickChooseTimeLimitedButton();
		//		covers = driver.get().findElement(By.xpath("//*[@id='coverLevel_100']"));
		//		utilities.waitElement(covers, driver);
				Thread.sleep(700);
				yourCoverPage.clickRadio�2500Button();
				//Thread.sleep(700);
				yourCoverPage.clickSaveCloseButton();
				TextToWrite = "TimeLimited �2500 selected";
				utilities.Filewriter(TextToWrite);
				Thread.sleep(1500);
				yourCoverPage.clickCloseToasterButton();
				payNowButton = driver.get().findElement(By.xpath("//button[@class='btn btn-primary']"));
				utilities.waitElement(payNowButton, driver);
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", payNowButton);
				((JavascriptExecutor) driver).executeScript("arguments[0].click();", payNowButton);
			}
			catch(Exception e)
			{
				e.printStackTrace();
				System.out.println(e.getMessage());
				utilities.onTestFailure();
			}
			dbConnection.closeConnection();
		}
	}