/**
 * 
 */
package com.argos.pet.quotebuy.regression.tests;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.testng.annotations.Parameters;
import org.testng.asserts.SoftAssert;

import com.codoid.products.fillo.Recordset;
import com.argos.pet.quotebuy.regression.common.code.dbconnection.DBConnectionRegressionCommonCode;
import com.argos.pet.quotebuy.regression.common.code.pages.EditPetDetailsPage;
import com.argos.pet.quotebuy.regression.common.code.pages.YourQuoteSummaryPage;
import com.argos.pet.quotebuy.regression.common.code.utilities.TestBase;
import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;


/**
 * @author d23747
 *
 */
public class EditPetDetailsTest_715 extends TestBase {

	DBConnectionRegressionCommonCode dbConnection;
	Utilities utilities;
	EditPetDetailsPage editPetDetailsPage;
	String className;
	public String ClassName;
	SoftAssert softAssert;
	YourQuoteSummaryPage yourQuoteSummaryPage;

	@Parameters ("ClassName")
	public void initiateEditPetDetailsTest_715(String ClassName) throws Exception
	{
		utilities = new Utilities();
		editPetDetailsPage = new EditPetDetailsPage(driver);
		softAssert = new SoftAssert();
		yourQuoteSummaryPage = new YourQuoteSummaryPage(driver);
		className = utilities.getClassName(ClassName);
		String  strQuery = "Select * from EditCover where TestClassName = '" + className + "'";
		dbConnection = new DBConnectionRegressionCommonCode();
		Recordset recordset = dbConnection.recordset(strQuery);
		recordset.next();
		recordset.moveFirst();

		editPetDetailsPage.clickEditPetDetailsLink();
		editPetDetailsPage.setPetName("");
		editPetDetailsPage.populateDobDay("");
		editPetDetailsPage.populateDobMonth("");
		editPetDetailsPage.populateDobYear("");
	//	editPetDetailsPage.populatedateOfBirth("");
		editPetDetailsPage.selectDogCrossBreed();
	//	editPetDetailsPage.populateBreedType("");
	//	editPetDetailsPage.populatePetCost("");
		driver.get().switchTo().activeElement().sendKeys(Keys.TAB);
		editPetDetailsPage.clickSaveCloseButton();
		editPetDetailsPage.clickCancelButton();
		Thread.sleep(1500);
		String ErrorMessageForPetNameFromExcel = recordset.getField("ErrorMessageForPetName");
		String ErrorMessageForBreedFromExcel = recordset.getField("ErrorMessageForBreed");
		String ErrorMessageForDOBFromExcel = recordset.getField("ErrorMessageForDOB");
	//	String ErrorMessageForPetCostFromExcel = recordset.getField("ErrorMessageForPetCost");
	//	String ErrorMessageAtTheTopFromExcel = recordset.getField("ErrorMessageAtTheTop");
		String ErrorMessageForPetNameFromWeb = driver.get().findElement(By.xpath("(//div[@class='error-message'])[1]")).getText().trim();
		String ErrorMessageForBreedFromWeb = driver.get().findElement(By.xpath("(//div[@class='error-message'])[2]")).getText().trim();
		String ErrorMessageForDOBFromWeb = driver.get().findElement(By.xpath("(//div[@class='error-message'])[3]")).getText().trim();
	//	String ErrorMessageForPetCostFromWeb = driver.get().findElement(By.xpath("(//div[@class='error-message'])[4]")).getText().trim();
	//	String ErrorMessageAtTheTopFromWeb = driver.get().findElement(By.xpath("//*[@id='errorAlertContainerModal']/div/div/div/div/div")).getText();
		
	//	System.out.println(":"+ErrorMessageForPetCostFromWeb+":"+  ErrorMessageForPetCostFromExcel+":");
		
		softAssert.assertEquals(ErrorMessageForPetNameFromWeb, ErrorMessageForPetNameFromExcel);
		softAssert.assertEquals(ErrorMessageForBreedFromWeb, ErrorMessageForBreedFromExcel);
		softAssert.assertEquals(ErrorMessageForDOBFromWeb, ErrorMessageForDOBFromExcel);
		//softAssert.assertEquals(ErrorMessageForPetCostFromWeb, ErrorMessageForPetCostFromExcel);
		//softAssert.assertEquals(ErrorMessageAtTheTopFromWeb, ErrorMessageAtTheTopFromExcel);
		softAssert.assertAll();
		dbConnection.closeConnection();
	}
}