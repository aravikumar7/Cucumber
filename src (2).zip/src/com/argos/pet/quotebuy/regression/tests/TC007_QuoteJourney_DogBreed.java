/**
 * 
 */
package com.argos.pet.quotebuy.regression.tests;

import org.testng.annotations.Test;

import com.argos.pet.quotebuy.regression.common.code.utilities.TestBase;
import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;


public class TC007_QuoteJourney_DogBreed extends TestBase {

	Utilities utilities;
	YourPetDetailsTest_YourPetDetails yourPetDetailsTest;
	MoreAboutYourPetTest_YourPetDetails moreAboutYourPetTest;
	CustomerDetailsTest_YourPetDetails_Test customerDetailsTest;
	YourCoverTest_YourPetDetails yourCoverTest;
	YourQuoteSummaryTest_YourPetDetails yourQuoteSummaryTest;
	PreExistingConditionsTest_YourPetDetails preExistingConditionsTest;
	PaymentPageTest_YourPetDetails paymentPageTest;
	AlmostThereTest_YourPetDetails almostThereTest;
	ConfirmationTest_YourPetDetails_Test confirmationTest;
	String ClassName;

	@Test (priority = 0)
	public void initiate_TC007_QuoteJourney_DogBreed() throws Exception
	{
		yourPetDetailsTest = new YourPetDetailsTest_YourPetDetails();
		yourPetDetailsTest.initiateYourPetDetailsTest(ClassName);
		moreAboutYourPetTest = new MoreAboutYourPetTest_YourPetDetails();
		moreAboutYourPetTest.initiateMoreAboutYourPetTest(ClassName);
		customerDetailsTest = new CustomerDetailsTest_YourPetDetails_Test();
		customerDetailsTest.initiateCustomerDetailsTest(ClassName);
		yourCoverTest = new YourCoverTest_YourPetDetails();	
		yourCoverTest.testYourCover();
		yourQuoteSummaryTest = new YourQuoteSummaryTest_YourPetDetails();
		yourQuoteSummaryTest.testYourQuoteSummary();
		paymentPageTest = new PaymentPageTest_YourPetDetails();
		paymentPageTest.testPaymentPage();
		almostThereTest = new AlmostThereTest_YourPetDetails();
		almostThereTest.initiateAlmostThereTest();
		confirmationTest = new ConfirmationTest_YourPetDetails_Test();
		confirmationTest.initiateConfirmationTest();
	}
}