/**
 * 
 */
package com.argos.pet.quotebuy.regression.tests;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.testng.annotations.Parameters;
import org.testng.asserts.SoftAssert;

import com.argos.pet.quotebuy.regression.common.code.dbconnection.DBConnectionRegressionCommonCode;
import com.argos.pet.quotebuy.regression.common.code.pages.EditPetDetailsPage;
import com.argos.pet.quotebuy.regression.common.code.pages.YourQuoteSummaryPage;
import com.argos.pet.quotebuy.regression.common.code.utilities.TestBase;
import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;
import com.codoid.products.fillo.Recordset;


/**
 * @author d23747
 *
 */
public class EditPetDetailsTest_719 extends TestBase {

	DBConnectionRegressionCommonCode dbConnection;
	Utilities utilities;
	EditPetDetailsPage editPetDetailsPage;
	String className;
	public String ClassName;
	SoftAssert softAssert;
	YourQuoteSummaryPage yourQuoteSummaryPage;

	@Parameters ("ClassName")
	public void initiateEditPetDetailsTest_719(String ClassName) throws Exception
	{
		utilities = new Utilities();
		editPetDetailsPage = new EditPetDetailsPage(driver);
		softAssert = new SoftAssert();
		yourQuoteSummaryPage = new YourQuoteSummaryPage(driver);
		className = utilities.getClassName(ClassName);
		String  strQuery = "Select * from EditCover where TestClassName = '" + className + "'";
		dbConnection = new DBConnectionRegressionCommonCode();
		Recordset recordset = dbConnection.recordset(strQuery);
		recordset.next();
		recordset.moveFirst();

		editPetDetailsPage.clickEditPetDetailsLink();
		Thread.sleep(700);
		editPetDetailsPage.selectDogCrossBreed();
		Thread.sleep(700);
	//	editPetDetailsPage.whatBreedQuestionTextField();
	//	driver.get().switchTo().activeElement().sendKeys(Keys.BACK_SPACE);
		editPetDetailsPage.populateBreedType("Afghan Hound Cross");
	//	editPetDetailsPage.selectFromList();
		editPetDetailsPage.populatePetCost("20");
	//	driver.get().switchTo().activeElement().sendKeys(Keys.TAB);
		editPetDetailsPage.clickSaveCloseButton();
		Thread.sleep(2500);
	/*	if (utilities.isElementPresent(By.xpath("//*[@id='floatingToasterPanel']/div/div/div/div"), driver.get()))
		//utilities.waitElement(driver.get().findElement(By.xpath("//*[@id='floatingToasterPanel']/div/div/div/div")), driver.get());
		{
			driver.get().findElement(By.xpath("//*[@id='floatingToasterPanel']/div/div/div/button")).click();
			Thread.sleep(2500);
			driver.get().switchTo().activeElement();
		}*/
		
		boolean successtoaster=driver.get().findElements(By.xpath("//button[@class='Toastify__close-button Toastify__close-button--success']")).size()>0;
		if(successtoaster) {
		((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//button[@class='Toastify__close-button Toastify__close-button--success']")));
		((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//button[@class='Toastify__close-button Toastify__close-button--success']")));
	}
		String petBreed = yourQuoteSummaryPage.getPetBreed();
		softAssert.assertEquals(petBreed, "Afghan Hound Cross");

		editPetDetailsPage.clickEditPetDetailsLink();
		editPetDetailsPage.selectDogMongrel();
		Thread.sleep(2500);
		editPetDetailsPage.selectSmallMongrel();
		Thread.sleep(2500);
		editPetDetailsPage.populatePetCost("20");
		editPetDetailsPage.clickSaveCloseButton();
		Thread.sleep(2500);
	//	if (utilities.isElementPresent(By.xpath("//*[@id='floatingToasterPanel']/div/div/div/div"), driver.get()))
	/*	utilities.waitElement(driver.get().findElement(By.xpath("//*[@id='floatingToasterPanel']/div/div/div/div")), driver.get());
		{
			driver.get().findElement(By.xpath("//*[@id='floatingToasterPanel']/div/div/div/button")).click();
			Thread.sleep(2500);
			driver.get().switchTo().activeElement();
		}*/
		successtoaster=driver.get().findElements(By.xpath("//button[@class='Toastify__close-button Toastify__close-button--success']")).size()>0;
		if(successtoaster) {
		((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//button[@class='Toastify__close-button Toastify__close-button--success']")));
		((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//button[@class='Toastify__close-button Toastify__close-button--success']")));
	}
		petBreed = yourQuoteSummaryPage.getPetBreed();
		softAssert.assertEquals(petBreed, "Mongrel Small Up to 10Kg");
		Thread.sleep(2500);

		editPetDetailsPage.clickEditPetDetailsLink();
		editPetDetailsPage.selectDogMongrel();
		Thread.sleep(2500);
		editPetDetailsPage.selectMediumMongrel();
		editPetDetailsPage.populatePetCost("20");
		editPetDetailsPage.clickSaveCloseButton();
		Thread.sleep(2500);
		//if (utilities.isElementPresent(By.xpath("//*[@id='floatingToasterPanel']/div/div/div/div"), driver.get()))
	/*	utilities.waitElement(driver.get().findElement(By.xpath("//*[@id='floatingToasterPanel']/div/div/div/div")), driver.get());
		{
			driver.get().findElement(By.xpath("//*[@id='floatingToasterPanel']/div/div/div/button")).click();
			Thread.sleep(2500);
			driver.get().switchTo().activeElement();
		}*/
		successtoaster=driver.get().findElements(By.xpath("//button[@class='Toastify__close-button Toastify__close-button--success']")).size()>0;
		if(successtoaster) {
		((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//button[@class='Toastify__close-button Toastify__close-button--success']")));
		((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//button[@class='Toastify__close-button Toastify__close-button--success']")));
	}
	
		petBreed = yourQuoteSummaryPage.getPetBreed();
		softAssert.assertEquals(petBreed, "Mongrel Medium 10Kg to 20Kg");
		Thread.sleep(2500);																											

		editPetDetailsPage.clickEditPetDetailsLink();
		editPetDetailsPage.selectDogMongrel();
		Thread.sleep(2500);
		editPetDetailsPage.selectLargeMongrel();
		Thread.sleep(2500);
		editPetDetailsPage.populatePetCost("20");
		editPetDetailsPage.clickSaveCloseButton();
		Thread.sleep(2500);
		//if (utilities.isElementPresent(By.xpath("//*[@id='floatingToasterPanel']/div/div/div/div"), driver.get()))
		/*utilities.waitElement(driver.get().findElement(By.xpath("//*[@id='floatingToasterPanel']/div/div/div/div")), driver.get());
		{
			driver.get().findElement(By.xpath("//*[@id='floatingToasterPanel']/div/div/div/button")).click();
			Thread.sleep(2500);
			driver.get().switchTo().activeElement();
		}*/
		successtoaster=driver.get().findElements(By.xpath("//button[@class='Toastify__close-button Toastify__close-button--success']")).size()>0;
		if(successtoaster) {
		((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//button[@class='Toastify__close-button Toastify__close-button--success']")));
		((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//button[@class='Toastify__close-button Toastify__close-button--success']")));
	}
	petBreed = yourQuoteSummaryPage.getPetBreed();
		softAssert.assertEquals(petBreed, "Mongrel Large over 20Kg");
		Thread.sleep(2500);

		editPetDetailsPage.clickEditPetDetailsLink();
		editPetDetailsPage.selectDogBreed();
		Thread.sleep(2500);
//		editPetDetailsPage.whatBreedQuestionTextField();
		driver.get().switchTo().activeElement().sendKeys(Keys.BACK_SPACE);
		editPetDetailsPage.populateBreedType("Afghan Hound");
//		editPetDetailsPage.selectFromList();
		Thread.sleep(2500);
		editPetDetailsPage.populatePetCost("20");
		editPetDetailsPage.clickSaveCloseButton();
		Thread.sleep(2500);
		//if (utilities.isElementPresent(By.xpath("//*[@id='floatingToasterPanel']/div/div/div/div"), driver.get()))
	/*	utilities.waitElement(driver.get().findElement(By.xpath("//*[@id='floatingToasterPanel']/div/div/div/div")), driver.get());
		{
			driver.get().findElement(By.xpath("//*[@id='floatingToasterPanel']/div/div/div/button")).click();
			Thread.sleep(2500);
			driver.get().switchTo().activeElement();
		}*/
		successtoaster=driver.get().findElements(By.xpath("//button[@class='Toastify__close-button Toastify__close-button--success']")).size()>0;
		if(successtoaster) {
		((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//button[@class='Toastify__close-button Toastify__close-button--success']")));
		((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//button[@class='Toastify__close-button Toastify__close-button--success']")));
	}
	
		petBreed = yourQuoteSummaryPage.getPetBreed();
		softAssert.assertEquals(petBreed, "Afghan Hound");
		Thread.sleep(2500);
		softAssert.assertAll();
		dbConnection.closeConnection();
	}
}