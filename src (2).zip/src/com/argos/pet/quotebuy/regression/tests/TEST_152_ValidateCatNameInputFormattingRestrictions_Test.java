/**
 * 
 */
package com.argos.pet.quotebuy.regression.tests;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.argos.pet.quotebuy.regression.common.code.dbconnection.DBConnection;
import com.argos.pet.quotebuy.regression.common.code.pages.YourPetDetailsPage;
import com.argos.pet.quotebuy.regression.common.code.utilities.TestBase;
import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;
import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Recordset;

/**
 * @author d23747
 *
 */
public class TEST_152_ValidateCatNameInputFormattingRestrictions_Test extends TestBase {

	DBConnection dbConnection;
	Utilities utilities;
	YourPetDetailsPage yourPetDetailsPage;
	TestBase testBase;
	SoftAssert softAssert;

	@Test
	public void initiate_TEST_152_ValidateCatNameInputFormattingRestrictions() throws FilloException, IOException
	{
		yourPetDetailsPage = new YourPetDetailsPage(driver);
		String  strQuery = "Select * from PetQuote where TestClassName = '" + this.getClass().getSimpleName() + "'";
		dbConnection = new DBConnection();
		Recordset recordset = dbConnection.recordset(strQuery);
		recordset.next();
		recordset.moveFirst();
		{
			try
			{
				testBase = new TestBase();
				softAssert = new SoftAssert();
				utilities = new Utilities();
				yourPetDetailsPage = new YourPetDetailsPage(driver);
				yourPetDetailsPage.setPetName(recordset.getField("PetFullName"));
				driver.get().switchTo().activeElement().sendKeys(Keys.TAB);
				//softAssert.assertTrue(!utilities.isElementPresent(By.xpath("//div[contains(@class, 'pet-name_1-error input-error-content w-100 d-flex show')]"), driver));
				softAssert.assertTrue(!utilities.isElementPresent(By.xpath("//label[@for='pet1.pet_name']/following-sibling::div"), driver));
				softAssert.assertAll();
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
		}
		dbConnection.closeConnection();
	}
}
