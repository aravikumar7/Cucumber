/**
 * 
 */
package com.argos.pet.quotebuy.regression.tests;

import java.io.IOException;

import org.openqa.selenium.By;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.argos.pet.quotebuy.regression.common.code.dbconnection.DBConnection;
import com.argos.pet.quotebuy.regression.common.code.pages.YourPetDetailsPage;
import com.argos.pet.quotebuy.regression.common.code.utilities.TestBase;
import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;
import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Recordset;


/**
 * @author d23747
 *
 */

public class TEST_158_ValidateCatSexFieldIsMandatory_Test extends TestBase {

	DBConnection dbConnection;
	Utilities utilities;
	YourPetDetailsPage yourPetDetailsPage;
	TestBase testBase;
	SoftAssert softAssert;
	String[] dobArray;

	@Test
	public void initiate_TEST_158_ValidateCatSexFieldIsMandatory() throws FilloException, IOException
	{
		yourPetDetailsPage = new YourPetDetailsPage(driver);
		String  strQuery = "Select * from PetQuote where TestClassName = '" + this.getClass().getSimpleName() + "'";
		dbConnection = new DBConnection();
		Recordset recordset = dbConnection.recordset(strQuery);
		recordset.next();
		recordset.moveFirst();
		strQuery = recordset.getField("DOB_FromCoverStartDate");
		{
			try
			{
				testBase = new TestBase();
				softAssert = new SoftAssert();
				utilities = new Utilities();
				yourPetDetailsPage = new YourPetDetailsPage(driver);
				yourPetDetailsPage.setPetName(recordset.getField("PetFullName"));

				yourPetDetailsPage.setPetTypeCat();
				Thread.sleep(500);
				driver.get().findElement(By.xpath("//label[@for='cat-other_pet1']")).click();
				//utilities.waitElement(driver.get().findElement(By.xpath("//*[@id=\'whatBreedQuestion_1\']/div[1]/div[1]/div/div")), driver);
				yourPetDetailsPage.whatBreedQuestionTextField();
				yourPetDetailsPage.populateBreedType(recordset.getField("CatBreed"));
				yourPetDetailsPage.selectFromList();
				dobArray = utilities.getDOB(strQuery);
				yourPetDetailsPage.populateDobDay(dobArray[0]);
				yourPetDetailsPage.populateDobMonth(dobArray[1]);
				yourPetDetailsPage.populateDobYear(dobArray[2]);

				yourPetDetailsPage.clickNextButton();
				//String errorText = driver.get().findElement(By.xpath("//*[@id='errorAlertContainer_1']/div/div/div/div/div")).getText();
				String errorText = driver.get().findElement(By.xpath("//*[@id='errorList_1']/li/button")).getText();
				softAssert.assertEquals(errorText, recordset.getField("ErrorMessageAtTheField"));
				softAssert.assertAll();
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
		}
		dbConnection.closeConnection();
	}
}
