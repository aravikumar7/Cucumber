package com.argos.pet.quotebuy.regression.tests;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class ReadConfig
{

	public Properties properties;
	public String envName;
	public String url;
	public String chromePath;
	public String iEPath;
	public String fireFoxPath;
	public String logFilePath;
	public String testResultFilePath;
	public String screenshotPath;


	public ReadConfig() throws IOException
	{
		properties = new Properties();
		FileInputStream fileInputStream = new FileInputStream(System.getProperty("user.dir") + "/src/com/sainsburys/pet/quotebuy/config/config.properties");
		properties.load(fileInputStream);
	}
	
	public String getTestEnvironmentName()
	{
		String envName = properties.getProperty("TestEnvironmentName");
		return envName;
	}

	public String getTestEnvironmentURL()
	{
		String url = properties.getProperty("TestEnvironmentURL");
		return url;
	}

	public String getUsername()
	{
		String userName = properties.getProperty("Username");
		return userName;
	}

	public String getPassword()
	{
		String password = properties.getProperty("Password");
		return password;
	}

	public String getChromePath()
	{
		String chromePath = properties.getProperty("chromepath");
		return chromePath;
	}

	public String getIEPath()
	{
		String iEPath = properties.getProperty("iepath");
		return iEPath;
	}

	public String getFireFoxPath()
	{
		String fireFoxPath = properties.getProperty("firefoxpath");
		return fireFoxPath;
	}
	
	public String getEdgePath()
	{
		String edgePath = properties.getProperty("edgepath");
		return edgePath;
	}

	public String getLogFilePath()
	{
		String logFilePath = properties.getProperty("logfilepath");
		return logFilePath;
	}
	
	public String getTestResultFilePath()
	{
		String testResultFilePath = properties.getProperty("testResultFilePath");
		return testResultFilePath;
	}
	
	public String getScreenshotPath()
	{
		String screenshotPath = properties.getProperty("screenshotpath");
		return screenshotPath;
	}

}
