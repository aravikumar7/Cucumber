/**
 * 
 */
package com.argos.pet.quotebuy.regression.tests;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.argos.pet.quotebuy.regression.common.code.dbconnection.DBConnection;
import com.argos.pet.quotebuy.regression.common.code.pages.YourPetDetailsPage;
import com.argos.pet.quotebuy.regression.common.code.utilities.TestBase;
import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;
import com.codoid.products.fillo.Recordset;


/**
 * @author d23747
 *
 */

public class TEST_139_ValidateTypeOfBreedQuestionIsMandatory_Test extends TestBase {

	DBConnection dbConnection;
	Utilities utilities;
	YourPetDetailsPage yourPetDetailsPage;
	TestBase testBase;
	SoftAssert softAssert;
	String[] dobArray;

	@Test (priority = 0)
	public void initiate_TEST_139_ValidateTypeOfBreedQuestionIsMandatory() throws Exception
	{
		String  strQuery = "Select * from PetQuote Where TestClassName = '" + this.getClass().getSimpleName() + "'";
		dbConnection = new DBConnection();
		Recordset recordset = dbConnection.recordset(strQuery);
		recordset.next();
		recordset.moveFirst();
		strQuery = recordset.getField("DOB_FromCoverStartDate");
		
		{
			try
			{
				utilities = new Utilities();
				testBase = new TestBase();
				softAssert = new SoftAssert();
				utilities = new Utilities();
				yourPetDetailsPage = new YourPetDetailsPage(driver);
				yourPetDetailsPage.setPetName(recordset.getField("PetFullName"));
				yourPetDetailsPage.setPetTypeDog();
			//	utilities.waitElement(driver.get().findElement(By.xpath("//*[@id='breedDogType_1']")), driver);
				yourPetDetailsPage.selectDogBreed();
				dobArray = utilities.getDOB(strQuery);
				yourPetDetailsPage.populateDobDay(dobArray[0]);
				yourPetDetailsPage.populateDobMonth(dobArray[1]);
				yourPetDetailsPage.populateDobYear(dobArray[2]);
				driver.get().switchTo().activeElement().sendKeys(Keys.TAB);
				yourPetDetailsPage.selectMalePet();
				yourPetDetailsPage.clickNextButton();
			//	String errorText = driver.get().findElement(By.xpath("//div[@class='errors-inner']/ul/li[1]/button")).getText();
				String errorText_0 = driver.get().findElement(By.xpath("//label[@for='pet1.pet_breed']/following-sibling::div[2]")).getText();
			//	softAssert.assertTrue(errorText.contains(recordset.getField("ErrorMessageAtTheTop")));
				softAssert.assertEquals(errorText_0, recordset.getField("ErrorMessageAtTheField"));
				Thread.sleep(700);
				softAssert.assertAll();
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
		}
		dbConnection.closeConnection();
	}
}
