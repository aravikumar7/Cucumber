/**
 * 
 */
package com.argos.pet.quotebuy.regression.tests;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.testng.annotations.Parameters;
import org.testng.asserts.SoftAssert;

import com.argos.pet.quotebuy.regression.common.code.dbconnection.DBConnectionRegressionCommonCode;
import com.argos.pet.quotebuy.regression.common.code.pages.YourPetDetailsPage;
import com.argos.pet.quotebuy.regression.common.code.utilities.TestBase;
import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;
import com.argos.pet.quotebuy.regression.tests.MultiPetYourPetDetailsTest_YourPetDetails;
import com.codoid.products.fillo.Recordset;


/**
 * @author d23747
 *
 */
public class MultiPetMoreAboutYourPetTest_YourPetDetails extends TestBase {
	DBConnectionRegressionCommonCode dbConnection;
	Utilities utilities;
	YourPetDetailsPage yourPetDetailsPage;
	SoftAssert softAssert;
	MultiPetYourPetDetailsTest_YourPetDetails multiPetYourPetDetailsTest;
	String[] dobArray;
	String className;
	String[] uniqueTestDataArray;
	static String multiPetAnyInjuryIllness;
	int numberOfMultiPetsInt;
	public String TextToWrite;
	public String ClassName;

	@Parameters ("ClassName")
	public String initiateMultiPetMoreAboutYourPetTest(String ClassName) throws Exception
	{
		utilities = new Utilities();
		numberOfMultiPetsInt = MultiPetTest_YourPetDetails.numberOfMultiPets;
		uniqueTestDataArray = MultiPetYourPetDetailsTest_YourPetDetails.uniqueTestDataArray;
		className = utilities.getClassName(ClassName);
		String  strQuery = "Select * from MultiPet where TestClassName = '" + className + "'";
		dbConnection = new DBConnectionRegressionCommonCode();
		Recordset recordset = dbConnection.recordset(strQuery);
		recordset.next();
		recordset.moveFirst();
		softAssert = new SoftAssert();
		yourPetDetailsPage = new YourPetDetailsPage(driver);
		driver.get().findElement(By.xpath("//*[@id='petCost_" + numberOfMultiPetsInt + "']")).clear();
		if (!recordset.getField("MultiPetCost_" + (numberOfMultiPetsInt - 1) + "").equalsIgnoreCase("I didn't pay anything"))
		{
			driver.get().findElement(By.xpath("//*[@id='petCost_" + numberOfMultiPetsInt + "']")).sendKeys(recordset.getField("MultiPetCost_" + numberOfMultiPetsInt + ""));
			TextToWrite = "Pet " + (numberOfMultiPetsInt) + " Cost: " + recordset.getField("MultiPetCost_" + numberOfMultiPetsInt);
			utilities.Filewriter(TextToWrite);
		}
		else
		{
			driver.get().findElement(By.xpath("//*[@id='zeroPetCost_" + numberOfMultiPetsInt + "']")).click();
		}
		driver.get().switchTo().activeElement().sendKeys(Keys.TAB);
		Thread.sleep(700);
		if (recordset.getField("MultiPetNeutered_" + (numberOfMultiPetsInt - 1) + "").equalsIgnoreCase("Yes"))
		{
			driver.get().findElement(By.xpath("//*[@id='pet_neutered_Yes_" + numberOfMultiPetsInt + "']")).click();
			TextToWrite = "Pet " + (numberOfMultiPetsInt) + " Neutered = Yes";
			utilities.Filewriter(TextToWrite);
		}
		else
		{
			Thread.sleep(700);
			driver.get().findElement(By.xpath("//*[@id='pet_neutered_No_" + numberOfMultiPetsInt + "']")).click();
			TextToWrite = "Pet " + (numberOfMultiPetsInt) + " Neutered = No";
			utilities.Filewriter(TextToWrite);
		}
		multiPetAnyInjuryIllness = recordset.getField("MultiPetAnyInjuryIllness_" + (numberOfMultiPetsInt -1 ) + "");
		if (multiPetAnyInjuryIllness.equalsIgnoreCase("Yes"))
		{
			driver.get().findElement(By.xpath("//*[@id='pet_any_injury_illness_Yes_" + numberOfMultiPetsInt + "']")).click();
			TextToWrite = "Pet " + (numberOfMultiPetsInt) + " Injury Illness = Yes";
			utilities.Filewriter(TextToWrite);
		}
		else
		{
			driver.get().findElement(By.xpath("//*[@id='pet_any_injury_illness_No_" + numberOfMultiPetsInt + "']")).click();
			if (recordset.getField("MultiPetType_" + (numberOfMultiPetsInt - 1) + "").equalsIgnoreCase("Dog"))
			{
				String MultiPetPetAnyInjuryIllnessNoTextMessage = driver.get().findElement(By.xpath("//*[@id='js-warning-pet_any_injury_illness_" + numberOfMultiPetsInt + "']/div")).getText();
				String noTextMessageFromExcel = recordset.getField("MultiPetPetAnyInjuryIllnessNoTextMessage_" + (numberOfMultiPetsInt - 1) + "");
				String noTextMessageFromExcel2 = recordset.getField("MultiPetPetAnyInjuryIllnessNoTextMessage_" + (numberOfMultiPetsInt - 1) + "C");
				String finalMultiPetPetAnyInjuryIllnessNoTextMessage = noTextMessageFromExcel + uniqueTestDataArray[0] + noTextMessageFromExcel2;
				softAssert.assertEquals(MultiPetPetAnyInjuryIllnessNoTextMessage, finalMultiPetPetAnyInjuryIllnessNoTextMessage);
				softAssert.assertAll();
				TextToWrite = "Pet " + (numberOfMultiPetsInt) + " Injury Illness = No";
				utilities.Filewriter(TextToWrite);
			}
		}
		dbConnection.closeConnection();
		return multiPetAnyInjuryIllness;
	}
}