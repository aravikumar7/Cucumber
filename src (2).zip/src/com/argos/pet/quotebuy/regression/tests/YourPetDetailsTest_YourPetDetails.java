/**
 * 
 */
package com.argos.pet.quotebuy.regression.tests;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.testng.annotations.Parameters;
import org.testng.asserts.SoftAssert;

import com.codoid.products.fillo.Recordset;
import com.argos.pet.quotebuy.regression.common.code.dbconnection.DBConnectionRegressionCommonCode;
import com.argos.pet.quotebuy.regression.common.code.pages.YourPetDetailsPage;
import com.argos.pet.quotebuy.regression.common.code.utilities.TestBase;
import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;

public class YourPetDetailsTest_YourPetDetails extends TestBase {

	DBConnectionRegressionCommonCode dbConnection;
	Utilities utilities;
	YourPetDetailsPage yourPetDetailsPage;
	MoreAboutYourPetTest_YourPetDetails tc008_PopulateMoreAboutYourPet;
	CustomerDetailsTest_YourPetDetails_Test tc009_PopulateCustomerDetails;
	YourCoverTest_YourPetDetails yourCoverTest;
	YourQuoteSummaryTest_YourPetDetails yourQuoteSummaryTest;
	PreExistingConditionsTest_YourPetDetails preExistingConditionsTest;
	PaymentPageTest_YourPetDetails testPaymentPage;
	TestBase testBase;
	SoftAssert softAssert;
	String className;
	public String ClassName;
	String[] dobArray;
	String dateOfBirth;
	
	@Parameters ("ClassName")
	public void initiateYourPetDetailsTest(String ClassName) throws Exception
	{
		utilities = new Utilities();
		className = utilities.getClassName(ClassName);
		String  strQuery = "Select * from PetQuote where TestClassName = '" + className + "'";
		dbConnection = new DBConnectionRegressionCommonCode();
		Recordset recordset = dbConnection.recordset(strQuery);
		recordset.next();
		recordset.moveFirst();
		strQuery = recordset.getField("DOB_FromCoverStartDate");
		{
				testBase = new TestBase();
				softAssert = new SoftAssert();
				yourPetDetailsPage = new YourPetDetailsPage(driver);
				utilities = new Utilities();
				
				yourPetDetailsPage.setPetName(recordset.getField("PetFullName"));
				if (recordset.getField("PetType").equalsIgnoreCase("Dog"))
				{
					yourPetDetailsPage.setPetTypeDog();
			//		utilities.waitElement(driver.get().findElement(By.xpath("//*[@id='breedDogType_1']")), driver);
					if (recordset.getField("TypeOfDog").equalsIgnoreCase("Breed"))
					{
						yourPetDetailsPage.selectDogBreed();
					//	yourPetDetailsPage.whatBreedQuestionTextField();
						System.out.println("Bdreed is "+recordset.getField("DogBreedType"));
						yourPetDetailsPage.populateBreedType(recordset.getField("DogBreedType"));
					//	yourPetDetailsPage.selectFromList();
					}
					else if (recordset.getField("TypeOfDog").equalsIgnoreCase("Crossbreed"))
					{
						yourPetDetailsPage.selectDogCrossBreed();
					//	yourPetDetailsPage.whatBreedQuestionTextField();
						yourPetDetailsPage.populateBreedType(recordset.getField("DogCrossBreedType"));
					//	yourPetDetailsPage.selectFromList();
					}
					else if (recordset.getField("TypeOfDog").equalsIgnoreCase("Mongrel"))
					{
						yourPetDetailsPage.selectDogMongrel();
						//utilities.waitElement(driver.get().findElement(By.xpath("//*[@id=\'mongrel148164\']")), driver);
						if (recordset.getField("DogSize").equalsIgnoreCase("Small"))
						{
							yourPetDetailsPage.selectSmallMongrel();
						}
						else if (recordset.getField("DogSize").equalsIgnoreCase("Medium"))
						{
							yourPetDetailsPage.selectMediumMongrel();
						}
						else if (recordset.getField("DogSize").equalsIgnoreCase("Large"))
						{
							yourPetDetailsPage.selectLargeMongrel();
						}
						else
						{
							yourPetDetailsPage.selectSmallMongrel();
						}
					}
					else
					{
						yourPetDetailsPage.selectDogBreed();
						//yourPetDetailsPage.whatBreedQuestionTextField();
						yourPetDetailsPage.populateBreedType("Bulldog");
						//yourPetDetailsPage.selectFromList();
					}
				}

				else if (recordset.getField("PetType").equalsIgnoreCase("Cat"))
				{
					yourPetDetailsPage.setPetTypeCat();
					/*
					 * utilities.waitElement(driver.get().findElement(By.xpath(
					 * "//*[@id=\'whatBreedQuestion_1\']/div[1]/div[1]/div/div")), driver);
					 * yourPetDetailsPage.whatBreedQuestionTextField();
					 * yourPetDetailsPage.populateBreedType(recordset.getField("CatBreed"));
					 * yourPetDetailsPage.selectFromList();
					 */
					if(recordset.getField("CatBreed").equalsIgnoreCase("Moggie")) {
						driver.get().findElement(By.xpath("//label[@for='moggie_pet1']")).click();
							}
						else if(recordset.getField("CatBreed").equalsIgnoreCase("Domestic ShortHair")) {
							driver.get().findElement(By.xpath("//label[@for='british-shorthair_pet1']")).click();
								}
						else if(recordset.getField("CatBreed").equalsIgnoreCase("British ShortHair")) {
							driver.get().findElement(By.xpath("//label[@for='domestic-shorthair_pet1']")).click();
							}
						else if(recordset.getField("CatBreed").equalsIgnoreCase("Crossbreed")) {
							driver.get().findElement(By.xpath("//label[@for='cat-crossbreed_pet1']")).click();
							}
						else {
							((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//label[@for='cat-other_pet1']")));
							driver.get().findElement(By.xpath("//label[@for='cat-other_pet1']")).click();
							//utilities.waitElement(driver.get().findElement(By.xpath("//*[@id=\'whatBreedQuestion_1\']/div[1]/div[1]/div/div")), driver);
							//yourPetDetailsPage.whatBreedQuestionTextField();
							yourPetDetailsPage.populateBreedType(recordset.getField("CatBreed"));
							//yourPetDetailsPage.selectFromList();
						}
				}
				
				else if (recordset.getField("PetType").equalsIgnoreCase("Rabbit")) {
					yourPetDetailsPage.setPetTypeRabbit();
					
					if(recordset.getField("RabbitBreed").equalsIgnoreCase("Lop-Mini")){
						((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//label[@for='lop-mini_pet1']")));
						driver.get().findElement(By.xpath("//label[@for='lop-mini_pet1']")).click();
					}
					else if(recordset.getField("RabbitBreed").equalsIgnoreCase("Lop-Dwarf")){
						((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//label[@for='lop-dwarf_pet1']")));
						driver.get().findElement(By.xpath("//label[@for='lop-dwarf_pet1']")).click();
					}
				else if(recordset.getField("RabbitBreed").equalsIgnoreCase("Non-Pedigree Rabbit")){
					((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//label[@for='non-pedigree_pet1']")));
						driver.get().findElement(By.xpath("//label[@for='non-pedigree_pet1']")).click();
					}
				else if(recordset.getField("RabbitBreed").equalsIgnoreCase("Lionhead")){
					((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//label[@for='lionhead_pet1']")));
						driver.get().findElement(By.xpath("//label[@for='lionhead_pet1']")).click();
					}
				else if(recordset.getField("RabbitBreed").equalsIgnoreCase("Netherlands Dwarf")){
					((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//label[@for='netherlands-dwarf_pet1']")));
						driver.get().findElement(By.xpath("//label[@for='netherlands-dwarf_pet1']")).click();
					}
					else{
						((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//label[@for='rabbit-other_pet1']")));
						driver.get().findElement(By.xpath("//label[@for='rabbit-other_pet1']")).click();
						yourPetDetailsPage.populateBreedType(recordset.getField("RabbitBreed"));
					}
				}
				
				dobArray = utilities.getDOB(strQuery);
				yourPetDetailsPage.populateDobDay(dobArray[0]);
				yourPetDetailsPage.populateDobMonth(dobArray[1]);
				yourPetDetailsPage.populateDobYear(dobArray[2]);
				
				if (recordset.getField("Sex").equalsIgnoreCase("Male"))
				{
					yourPetDetailsPage.selectMalePet();
				}
				else
				{
					yourPetDetailsPage.selectFemalePet();
				}

	//			yourPetDetailsPage.clickNextButton();

		dbConnection.closeConnection();
	}
}
}