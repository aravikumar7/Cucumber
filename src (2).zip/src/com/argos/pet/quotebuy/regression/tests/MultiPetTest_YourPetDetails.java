/**
 * 
 */
package com.argos.pet.quotebuy.regression.tests;

import org.testng.annotations.Parameters;

import com.argos.pet.quotebuy.regression.common.code.dbconnection.DBConnectionRegressionCommonCode;
import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;
import com.codoid.products.fillo.Recordset;


/**
 * @author d23747
 *
 */
public class MultiPetTest_YourPetDetails {
	MultiPetYourPetDetailsTest_YourPetDetails multiPetYourPetDetailsTest;
	MultiPetMoreAboutYourPetTest_YourPetDetails multiPetMoreAboutYourPetTest;
	DBConnectionRegressionCommonCode dbConnection;
	Utilities utilities;
	String numberOfMultiPetsString;
	String className;
	static int numberOfMultiPets = 2;
	public String ClassName;

	@Parameters ("ClassName")
	public int initiateMultiPetTest(String numberOfMultiPetsString, String ClassName) throws Exception
	{
		dbConnection = new DBConnectionRegressionCommonCode();
		utilities = new Utilities();
		className = utilities.getClassName(ClassName);
		String  strQuery = "Select * from MultiPet where TestClassName = '" + className + "'";
		Recordset recordset = dbConnection.recordset(strQuery);
		recordset.next();
		recordset.moveFirst();
		numberOfMultiPetsString = recordset.getField("NumberOfMultiPets");
		int numberOfMultiPetsInt = Integer.valueOf(numberOfMultiPetsString);
		numberOfMultiPetsInt = numberOfMultiPetsInt + 1;
		if (recordset.getField("MultiPet").equalsIgnoreCase("Yes"))
		{
			for (numberOfMultiPets = 2; numberOfMultiPets <= numberOfMultiPetsInt; numberOfMultiPets ++)
			{
				multiPetYourPetDetailsTest = new MultiPetYourPetDetailsTest_YourPetDetails();
				multiPetYourPetDetailsTest.initiateMultiPetYourPetDetailsTest(ClassName);
				multiPetMoreAboutYourPetTest = new MultiPetMoreAboutYourPetTest_YourPetDetails();
				multiPetMoreAboutYourPetTest.initiateMultiPetMoreAboutYourPetTest(ClassName);
			}
		}
		dbConnection.closeConnection();
		return numberOfMultiPets;
	}
}
