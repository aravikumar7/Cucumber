/**
 * 
 */
package com.argos.pet.quotebuy.regression.tests;

import org.openqa.selenium.By;

import com.argos.pet.quotebuy.regression.common.code.dbconnection.DBConnection;
import com.argos.pet.quotebuy.regression.common.code.pages.YourCoverPage;
import com.argos.pet.quotebuy.regression.common.code.utilities.TestBase;
import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;

/**
 * @author d23747
 *
 */
public class YourCoverTest_437_YourPetDetails extends TestBase {

	YourCoverPage yourCoverPage;
	DBConnection dbConnection;
	Utilities utilities;

	public void testYourCover() throws Exception
	{
		yourCoverPage = new YourCoverPage(driver);
		dbConnection = new DBConnection();
		utilities = new Utilities();
			yourCoverPage.clickChooseTimeLimitedButton();
		//	utilities.waitElement(driver.findElement(By.xpath("//*[@id='coverLevel_4']")), driver);
			yourCoverPage.clickRadio�2500Button();
			Thread.sleep(100);
			yourCoverPage.clickChooseLifetimeButton();
			Thread.sleep(100);
		//	utilities.waitElement(driver.findElement(By.xpath("//*[@id='coverLevel_7']")), driver);
			Thread.sleep(100);
			yourCoverPage.clickRadio�1000Button();
			Thread.sleep(100);
			yourCoverPage.clickRadio�4500Button();
			Thread.sleep(100);
			yourCoverPage.clickRadio�7000Button();
			Thread.sleep(100);
			yourCoverPage.clickChooseMaxBenefitButton();//update button
			Thread.sleep(100);
		//	utilities.waitElement(driver.findElement(By.xpath("//*[@id='coverLevel_10']")), driver);
			Thread.sleep(100);
			yourCoverPage.clickRadioMax�2000Button();
			Thread.sleep(100);
			yourCoverPage.clickRadioMax�5000Button();
			Thread.sleep(100);
		
		yourCoverPage.clickReviewButton();
	}
}
