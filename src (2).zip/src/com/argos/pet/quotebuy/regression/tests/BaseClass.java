package com.argos.pet.quotebuy.regression.tests;

import java.io.IOException;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.ProfilesIni;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

public class BaseClass {
	ReadConfig readConfig;
	public String TestEnvironmentURL;
	public String Username;
	public String Password;
	public String chromepath;
	public String iepath;
	public String firefoxpath;
	public String logfilepath;
	public WebDriver driver;
	public Logger logger;

	//@Parameters ("Browser") //To be defined in TestNG.xml file. This did not work so i had to comment it
	@SuppressWarnings("deprecation")
	@BeforeClass
	public void setUpMethod() throws IOException { //pass a string variable browser when @parameter starts working
		readConfig = new ReadConfig();

		TestEnvironmentURL = readConfig.getTestEnvironmentURL();
		chromepath = readConfig.getChromePath();
		iepath = readConfig.getIEPath();
		firefoxpath = readConfig.getFireFoxPath();
		logfilepath = readConfig.getLogFilePath();
		Username = readConfig.getUsername();
		Password = readConfig.getPassword();


		String browser = "Chrome"; //comment this after @parameter starts working

		if (browser.equalsIgnoreCase("Chrome"))
		{
			ChromeOptions options = new ChromeOptions();
			options.addArguments("--disable-notifications");
			options.setExperimentalOption("useAutomationExtension", false);
			//options.addArguments("auth-server-whitelist='https://uat9.everypaw.com/quote'");
			System.setProperty("webdriver.chrome.driver", chromepath);
			driver = new ChromeDriver(options);
		}

		else if (browser.equalsIgnoreCase("Firefox"))
		{
			System.setProperty("webdriver.gecko.driver", firefoxpath);
			FirefoxProfile profile = new ProfilesIni().getProfile("default");
			profile.setAcceptUntrustedCertificates(false);
			DesiredCapabilities dc = DesiredCapabilities.firefox();
			dc.setCapability(FirefoxDriver.PROFILE, profile);
			driver = new FirefoxDriver(dc);
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		}

		else if (browser.equalsIgnoreCase("IE"))
		{
			System.setProperty("webdriver.ie.driver", readConfig.getIEPath());
			driver = new InternetExplorerDriver();
		}
		try
		{
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			driver.get("https://" + Username + ":" + Password + "@uat9.everypaw.com/quote");
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}

		//logger is not working need to check this later
		/*logger = Logger.getLogger("SainsburysPetQuoteBuyTest");
		FileHandler fileHandler;
		try {
			fileHandler = new FileHandler(logfilepath);
			logger.addHandler(fileHandler);
			SimpleFormatter formatter = new SimpleFormatter();
			fileHandler.setFormatter(formatter);

		}
		catch (SecurityException e)
		{
			e.printStackTrace();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}

		logger.info("sainsburys test started");*/
	}

	public WebDriverWait waitElement()
	{
		WebDriverWait wait = new WebDriverWait(driver, 20);
		return wait;
	}

	@AfterClass
	public void teadDown() {
		driver.close();
	}

}
