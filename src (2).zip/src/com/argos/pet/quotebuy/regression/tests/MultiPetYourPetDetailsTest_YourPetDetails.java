/**
 * 
 */
package com.argos.pet.quotebuy.regression.tests;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Parameters;
import org.testng.asserts.SoftAssert;

import com.argos.pet.quotebuy.regression.common.code.dbconnection.DBConnectionRegressionCommonCode;
import com.argos.pet.quotebuy.regression.common.code.pages.YourPetDetailsPage;
import com.argos.pet.quotebuy.regression.common.code.utilities.TestBase;
import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;
import com.codoid.products.fillo.Recordset;

import org.openqa.selenium.JavascriptExecutor;


/**
 * @author d23747
 *
 */
public class MultiPetYourPetDetailsTest_YourPetDetails extends TestBase {

	DBConnectionRegressionCommonCode dbConnection;
	Utilities utilities;
	YourPetDetailsPage yourPetDetailsPage;
	SoftAssert softAssert;
	String[] dobArray;
	String className;
	static String[] uniqueTestDataArray;
	static int numberOfMultiPetsInt;
	public String TextToWrite;
	public String ClassName;
	String dateOfBirth;

	@Parameters ("ClassName")

	public String[] initiateMultiPetYourPetDetailsTest(String ClassName) throws Exception
	{
		utilities = new Utilities();
		className = utilities.getClassName(ClassName);
		numberOfMultiPetsInt = MultiPetTest_YourPetDetails.numberOfMultiPets;
		uniqueTestDataArray = utilities.getUniqueTestData();
		String  strQuery = "Select * from MultiPet where TestClassName = '" + className + "'";
		dbConnection = new DBConnectionRegressionCommonCode();
		Recordset recordset = dbConnection.recordset(strQuery);
		recordset.next();
		recordset.moveFirst();
		softAssert = new SoftAssert();
		Actions actions = new Actions(driver.get());
		yourPetDetailsPage = new YourPetDetailsPage(driver);
		if (recordset.getField("MultiPet").equalsIgnoreCase("Yes"))
		{
			if (Integer.valueOf(recordset.getField("NumberOfMultiPets")) > 0)
			{
				Thread.sleep(2500);
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//*[text()='Add another pet']")));
				Thread.sleep(700);
				driver.get().findElement(By.xpath("//*[text()='Add another pet']")).click();
				utilities.waitElement(driver.get().findElement(By.id("pet"+numberOfMultiPetsInt + ".pet_name")), driver);
				driver.get().findElement(By.id("pet"+numberOfMultiPetsInt + ".pet_name")).sendKeys(uniqueTestDataArray[0]);

				if (recordset.getField("MultiPetType_" + (numberOfMultiPetsInt-1) + "").equalsIgnoreCase("Dog"))
				{
					((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//*[@id='radio_dog_pet" + numberOfMultiPetsInt + "']")));
					((JavascriptExecutor) driver).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//*[@id='radio_dog_pet" + numberOfMultiPetsInt + "']")));
					utilities.waitElement(driver.get().findElement(By.xpath("//*[@for='breed_pet" + numberOfMultiPetsInt + "']")), driver);
					if (recordset.getField("MultiPetTypeOfDog_" + (numberOfMultiPetsInt-1) + "").equalsIgnoreCase("Breed"))
					{	
						((JavascriptExecutor) driver).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//*[@for='breed_pet" + numberOfMultiPetsInt + "']")));
						Actions builder = new Actions(driver.get());
						driver.get().findElement(By.xpath("//div[@id='pet"+ numberOfMultiPetsInt + ".pet_breed']/div/div/div/div/input")).sendKeys(uniqueTestDataArray[1]);
						Thread.sleep(1000);
						builder.sendKeys(Keys.ENTER).perform();
						
						
						TextToWrite = "Pet " + numberOfMultiPetsInt + " Details: Full Name: " + uniqueTestDataArray[0] + " Dog Breed Type: " + uniqueTestDataArray[1];
						utilities.Filewriter(TextToWrite);
					}
					else if (recordset.getField("MultiPetTypeOfDog_" + (numberOfMultiPetsInt-1) + "").equalsIgnoreCase("Crossbreed"))
					{
						((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//*[@id='crossbreedDogType_" + numberOfMultiPetsInt + "']")));
						((JavascriptExecutor) driver).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//*[@id='crossbreedDogType_" + numberOfMultiPetsInt + "']")));
						Actions builder = new Actions(driver.get());
							driver.get().findElement(By.xpath("//div[@id='pet"+ numberOfMultiPetsInt + ".pet_breed']/div/div/div/div/input")).sendKeys(uniqueTestDataArray[1]);
							Thread.sleep(1000);
							builder.sendKeys(Keys.ENTER).perform();
						
						TextToWrite = "Pet " + numberOfMultiPetsInt + " Details: Full Name: " + uniqueTestDataArray[0] + " Dog Crossbreed Type: " + uniqueTestDataArray[2];
						utilities.Filewriter(TextToWrite);
					}
					else if (recordset.getField("MultiPetTypeOfDog_" + (numberOfMultiPetsInt-1) + "").equalsIgnoreCase("Mongrel"))
					{
						((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//*[@id='radio_mongrel_" + numberOfMultiPetsInt + "']")));
						((JavascriptExecutor) driver).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//*[@id='radio_mongrel_" + numberOfMultiPetsInt + "']")));
						utilities.waitElement(driver.get().findElement(By.xpath("//*[@id='dogSize_" + numberOfMultiPetsInt + "']/fieldset/legend")), driver);
						if (uniqueTestDataArray[3].equalsIgnoreCase("Small"))
						{
							Thread.sleep(1000);
							driver.get().findElement(By.xpath("//*[@id='mongrel-smallpet" + numberOfMultiPetsInt + "']")).click();
							((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//*[@for='mmongrel-smallpet" + numberOfMultiPetsInt + "']")));
							((JavascriptExecutor) driver).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//*[@for='mongrel-smallpet" + numberOfMultiPetsInt + "']")));
				
							TextToWrite = "Pet " + numberOfMultiPetsInt + " Details: Full Name: " + uniqueTestDataArray[0] + " Dog Type: Mongrel Small";
							utilities.Filewriter(TextToWrite);
						}
						else if (uniqueTestDataArray[3].equalsIgnoreCase("Medium"))
						{
							Thread.sleep(1000);
							driver.get().findElement(By.xpath("//*[@id='mongrel-mediumpet" + numberOfMultiPetsInt + "']")).click();
							((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//*[@for='mongrel-mediumpet" + numberOfMultiPetsInt + "']")));
							((JavascriptExecutor) driver).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//*[@for='mongrel-mediumpet" + numberOfMultiPetsInt + "']")));
				
							TextToWrite = "Pet " + numberOfMultiPetsInt + " Details: Full Name: " + uniqueTestDataArray[0] + " Dog Type: Mongrel Medium";
							utilities.Filewriter(TextToWrite);
						}
						else if (uniqueTestDataArray[3].equalsIgnoreCase("Large"))
						{
							Thread.sleep(1000);
							((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//*[@for='mongrel-largepet" + numberOfMultiPetsInt + "']")));
							((JavascriptExecutor) driver).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//*[@for='mongrel-largepet" + numberOfMultiPetsInt + "']")));
					
							TextToWrite = "Pet " + numberOfMultiPetsInt + " Details: Full Name: " + uniqueTestDataArray[0] + " Dog Type: Mongrel Large";
							utilities.Filewriter(TextToWrite);
						}
					}
				}

				else if (recordset.getField("MultiPetType_" + (numberOfMultiPetsInt-1) + "").equalsIgnoreCase("Cat"))
				{
					Thread.sleep(1000);
					((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//*[@id='radio_cat_pet" + numberOfMultiPetsInt + "']")));
					((JavascriptExecutor) driver).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//*[@id='radio_cat_pet" + numberOfMultiPetsInt + "']")));
					
					TextToWrite = "Pet " + numberOfMultiPetsInt + " Details: Full Name: " + uniqueTestDataArray[0] + " Cat Type: " + uniqueTestDataArray[4];
					utilities.Filewriter(TextToWrite);
				//
					if (recordset.getField("MultiPetTypeOfDog_" + (numberOfMultiPetsInt-1) + "").equalsIgnoreCase("Moggie")){
						Thread.sleep(1000);
						((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//*[@for='moggie_pet" + numberOfMultiPetsInt + "']")));
						((JavascriptExecutor) driver).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//*[@for='moggie_pet" + numberOfMultiPetsInt + "']")));
						}
					else if (recordset.getField("MultiPetTypeOfDog_" + (numberOfMultiPetsInt-1) + "").equalsIgnoreCase("Domestic ShortHair")){
						Thread.sleep(1000);
						((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//*[@for='domestic-shorthair_pet" + numberOfMultiPetsInt + "']")));
						((JavascriptExecutor) driver).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//*[@for='domestic-shorthair_pet" + numberOfMultiPetsInt + "']")));
						}
					else if (recordset.getField("MultiPetTypeOfDog_" + (numberOfMultiPetsInt-1) + "").equalsIgnoreCase("British ShortHair")){
						Thread.sleep(1000);
						((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//*[@for='british-shorthair_pet" + numberOfMultiPetsInt + "']")));
						((JavascriptExecutor) driver).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//*[@for='british-shorthair_pet" + numberOfMultiPetsInt + "']")));
						}
					else if (recordset.getField("MultiPetTypeOfDog_" + (numberOfMultiPetsInt-1) + "").equalsIgnoreCase("Crossbreed")){
						Thread.sleep(1500);
						((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//*[@for='cat-crossbreed_pet" + numberOfMultiPetsInt + "']")));
						((JavascriptExecutor) driver).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//*[@for='cat-crossbreed_pet" + numberOfMultiPetsInt + "']")));
						}
					else{
						Thread.sleep(1000);
						((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//*[@for='cat-other_pet" + numberOfMultiPetsInt + "']")));
						((JavascriptExecutor) driver).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//*[@for='cat-other_pet" + numberOfMultiPetsInt + "']")));
						
						Actions builder = new Actions(driver.get());
							driver.get().findElement(By.xpath("//div[@id='pet"+ numberOfMultiPetsInt + ".pet_breed']/div/div/div/div/input")).sendKeys(uniqueTestDataArray[4]);
							Thread.sleep(1000);
							builder.sendKeys(Keys.ENTER).perform();
					}
					TextToWrite = "Pet " + numberOfMultiPetsInt + " Details: Full Name: " + uniqueTestDataArray[0] + " Cat Type: " + uniqueTestDataArray[4];
					utilities.Filewriter(TextToWrite);
				}
			/*	dateOfBirth = utilities.getDOB(uniqueTestDataArray[5]);
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.id("pet" + numberOfMultiPetsInt + ".pet_date_of_birth")));
				driver.get().findElement(By.id("pet" + numberOfMultiPetsInt + ".pet_date_of_birth")).clear();
				driver.get().findElement(By.id("pet" + numberOfMultiPetsInt + ".pet_date_of_birth")).sendKeys(dateOfBirth);
				*/
				dobArray = utilities.getDOB(uniqueTestDataArray[5]);
				driver.get().findElement(By.xpath("//*[@id='daySelectDob_" + numberOfMultiPetsInt + "']")).clear();
				driver.get().findElement(By.xpath("//*[@id='pet" + numberOfMultiPetsInt + ".dateDayName']")).sendKeys(dobArray[0]);
				driver.get().findElement(By.xpath("//*[@id='pet" + numberOfMultiPetsInt + ".dateMonthName']")).clear();
				driver.get().findElement(By.xpath("//*[@id='pet" + numberOfMultiPetsInt + ".dateMonthName']")).sendKeys(dobArray[1]);
				driver.get().findElement(By.xpath("//*[@id='pet" + numberOfMultiPetsInt + ".dateYearName']")).clear();
				driver.get().findElement(By.xpath("//*[@id='pet" + numberOfMultiPetsInt + ".dateYearName']")).sendKeys(dobArray[2]);
				
				TextToWrite = "Pet " + numberOfMultiPetsInt + " DOB: " + dobArray[0] + "." + dobArray[1] + "." + dobArray[2];
				utilities.Filewriter(TextToWrite);
				if (recordset.getField("MultiPetSex_" + (numberOfMultiPetsInt) + "").equalsIgnoreCase("Male"))
				{
					((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//label[contains(@for,'male_radio_1pet" + numberOfMultiPetsInt + "')]")));
					((JavascriptExecutor) driver).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//label[contains(@for,'male_radio_1pet" + numberOfMultiPetsInt + "')]")));
					TextToWrite = "Pet: " + numberOfMultiPetsInt + " Sex: Male";
					utilities.Filewriter(TextToWrite);
				}
				else
				{
					((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//label[contains(@for,'female_radio_1pet" + numberOfMultiPetsInt + "')]")));	
					((JavascriptExecutor) driver).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//label[contains(@for,'female_radio_1pet" + numberOfMultiPetsInt + "')]")));
					TextToWrite = "Pet: " + numberOfMultiPetsInt + " Sex: Female";
					utilities.Filewriter(TextToWrite);
				}
				Thread.sleep(1000);
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//div[text()='Next']//parent::button")));	
				((JavascriptExecutor) driver).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//div[text()='Next']//parent::button")));
				
				numberOfMultiPetsInt ++;
			}
		}
		dbConnection.closeConnection();
		return uniqueTestDataArray;
	}
}