/**
 * 
 */
package com.argos.pet.quotebuy.regression.tests;

import org.openqa.selenium.By;
import org.testng.asserts.SoftAssert;

import com.argos.pet.quotebuy.regression.common.code.dbconnection.DBConnection;
import com.argos.pet.quotebuy.regression.common.code.pages.YourCoverPage;
import com.argos.pet.quotebuy.regression.common.code.utilities.TestBase;
import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;

/**
 * @author d23747
 *
 */
public class YourCoverTest_440_YourPetDetails extends TestBase {

	YourCoverPage yourCoverPage;
	DBConnection dbConnection;
	Utilities utilities;
	SoftAssert softAssert;

	public void testYourCover() throws Exception
	{
		yourCoverPage = new YourCoverPage(driver);
		dbConnection = new DBConnection();
		softAssert=new SoftAssert();
		utilities = new Utilities();
			yourCoverPage.clickChooseTimeLimitedButton();
		//	utilities.waitElement(driver.get().findElement(By.xpath("//*[@id='coverLevel_4']")), driver);
			yourCoverPage.clickRadio�2500Button();
			Thread.sleep(100);
			
			yourCoverPage.clickCompareBenefits();
			//*[@id="cpModalBody"]/table/tbody/tr[*]/td[1]/div
			Thread.sleep(500);
		//	softAssert.assertEquals(yourCoverPage.checkMonthlyPrice(),"Monthly price");
			softAssert.assertEquals(yourCoverPage.checkExcess(),"Excess");
			softAssert.assertEquals(yourCoverPage.checkVetFeeLimit(),"Vet fees");
			softAssert.assertEquals(yourCoverPage.checkDeathFromIllness(),"Death from illness");
			softAssert.assertEquals(yourCoverPage.checkDeathFromAccident(),"Death from accident");
			softAssert.assertEquals(yourCoverPage.checkFindingYourPet(),"Finding your pet");
			softAssert.assertEquals(yourCoverPage.checkLossByTheftOrStraying(),"Loss by theft or straying");
			softAssert.assertEquals(yourCoverPage.checkThirdPartyLiability(),"Third Party Liability");
			softAssert.assertEquals(yourCoverPage.checkHospitalisationFees(),"Hospitalisation/boarding fees");
			softAssert.assertEquals(yourCoverPage.checkHolidayCancellation(),"Holiday cancellation");
			yourCoverPage.closeCompareBenefits();
			
			Thread.sleep(1000);
			yourCoverPage.clickChooseLifetimeButton();
			Thread.sleep(100);
			//utilities.waitElement(driver.get().findElement(By.xpath("//*[@id='coverLevel_7']")), driver);
			Thread.sleep(100);
			yourCoverPage.clickRadio�2500Button();
			Thread.sleep(100);
			yourCoverPage.clickCompareBenefits();
			//*[@id="cpModalBody"]/table/tbody/tr[*]/td[1]/div
			Thread.sleep(500);
			softAssert.assertEquals(yourCoverPage.checkMonthlyPrice(),"Monthly price");
			softAssert.assertEquals(yourCoverPage.checkExcess(),"Excess");
			softAssert.assertEquals(yourCoverPage.checkVetFeeLimit(),"Vet fee limit");
			softAssert.assertEquals(yourCoverPage.checkDeathFromIllness(),"Death from illness");
			softAssert.assertEquals(yourCoverPage.checkDeathFromAccident(),"Death from accident");
			softAssert.assertEquals(yourCoverPage.checkFindingYourPet(),"Finding your pet");
			softAssert.assertEquals(yourCoverPage.checkLossByTheftOrStraying(),"Loss by theft or straying");
			softAssert.assertEquals(yourCoverPage.checkThirdPartyLiability(),"Third Party Liability");
			softAssert.assertEquals(yourCoverPage.checkHospitalisationFees(),"Hospitalisation/boarding fees");
			softAssert.assertEquals(yourCoverPage.checkHolidayCancellation(),"Holiday cancellation");
			yourCoverPage.closeCompareBenefits();
			
			
			yourCoverPage.clickRadio�1000Button();
			Thread.sleep(100);
			yourCoverPage.clickRadio�4500Button();
			Thread.sleep(100);
			yourCoverPage.clickRadio�7000Button();
			Thread.sleep(100);
			yourCoverPage.clickChooseMaxBenefitButton();//update button
			Thread.sleep(100);
			utilities.waitElement(driver.get().findElement(By.xpath("//*[@id='coverLevel_10']")), driver);
			Thread.sleep(100);
			yourCoverPage.clickRadioMax�2000Button();
			Thread.sleep(100);
			yourCoverPage.clickCompareBenefits();
			//*[@id="cpModalBody"]/table/tbody/tr[*]/td[1]/div
			Thread.sleep(500);
			softAssert.assertEquals(yourCoverPage.checkMonthlyPrice(),"Monthly price");
			softAssert.assertEquals(yourCoverPage.checkExcess(),"Excess");
			softAssert.assertEquals(yourCoverPage.checkVetFeeLimit(),"Vet fee limit");
			softAssert.assertEquals(yourCoverPage.checkDeathFromIllness(),"Death from illness");
			softAssert.assertEquals(yourCoverPage.checkDeathFromAccident(),"Death from accident");
			softAssert.assertEquals(yourCoverPage.checkFindingYourPet(),"Finding your pet");
			softAssert.assertEquals(yourCoverPage.checkLossByTheftOrStraying(),"Loss by theft or straying");
			softAssert.assertEquals(yourCoverPage.checkThirdPartyLiability(),"Third Party Liability");
			softAssert.assertEquals(yourCoverPage.checkHospitalisationFees(),"Hospitalisation/boarding fees");
			softAssert.assertEquals(yourCoverPage.checkHolidayCancellation(),"Holiday cancellation");
			yourCoverPage.closeCompareBenefits();
			
			yourCoverPage.clickRadioMax�5000Button();
			Thread.sleep(100);
			softAssert.assertAll();
		yourCoverPage.clickReviewButton();
	}
}
