/**
 * 
 */
package com.argos.pet.quotebuy.regression.tests;

import java.io.IOException;

import org.testng.annotations.Test;

/**
 * @author d23747
 *
 */
public class TC_Login_001 extends BaseClass {

	@Test
	public void loginToApplication() throws IOException
	{
		
	}
}
