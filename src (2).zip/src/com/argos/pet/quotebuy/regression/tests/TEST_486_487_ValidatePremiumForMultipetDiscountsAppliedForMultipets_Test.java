/**
 * 
 */
package com.argos.pet.quotebuy.regression.tests;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.argos.pet.quotebuy.regression.common.code.dbconnection.DBConnection;
import com.argos.pet.quotebuy.regression.common.code.tests.AlmostThereTest;
import com.argos.pet.quotebuy.regression.common.code.tests.ConfirmationTest;
import com.argos.pet.quotebuy.regression.common.code.tests.CustomerDetailsTest;
import com.argos.pet.quotebuy.regression.common.code.tests.MoreAboutYourPetTest;
import com.argos.pet.quotebuy.regression.common.code.tests.MultiPetYourCoverTest;
import com.argos.pet.quotebuy.regression.common.code.tests.MultiPetYourQuoteSummaryTest;
import com.argos.pet.quotebuy.regression.common.code.tests.PaymentTest;
import com.argos.pet.quotebuy.regression.common.code.tests.PreExistingConditionsTest;
import com.argos.pet.quotebuy.regression.common.code.tests.YourCoverTest;
import com.argos.pet.quotebuy.regression.common.code.tests.YourPetDetailsTest;
import com.argos.pet.quotebuy.regression.common.code.tests.YourQuoteSummaryTest;
import com.argos.pet.quotebuy.regression.common.code.utilities.TestBase;
import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;
import com.codoid.products.fillo.Recordset;


/**
 * @author d23747
 *
 */

public class TEST_486_487_ValidatePremiumForMultipetDiscountsAppliedForMultipets_Test extends TestBase {

	DBConnection dbConnection;
	YourPetDetailsTest yourPetDetailsTest;
	MoreAboutYourPetTest moreAboutYourPetTest;
	CustomerDetailsTest customerDetailsTest;
	YourCoverTest yourCoverTest;
	MultiPetYourCoverTest multiPetYourCoverTest;
	YourQuoteSummaryTest yourQuoteSummaryTest;
	MultiPetYourQuoteSummaryTest multiPetYourQuoteSummaryTest;
	PreExistingConditionsTest preExistingConditionsTest;
	PaymentTest paymentPageTest;
	AlmostThereTest almostThereTest;
	ConfirmationTest confirmationTest;
	Utilities utilities;
	SoftAssert softAssert;
	String numberOfMultiPetsString;
	public String TextToWrite;
	static int numberOfMultiPets = 2;

	public String classNameString() throws Exception {
		String className = this.getClass().getSimpleName();
		return className;
	}

	@Test(priority = 0)
	public void initiate_TEST_486_487_ValidatePremiumForMultipetDiscountsAppliedForMultipets() {
		try {
			dbConnection = new DBConnection();
			utilities = new Utilities();
			softAssert = new SoftAssert();
			TextToWrite = "Test: " + classNameString();
			utilities.Filewriter(TextToWrite);
			String strQuery = "Select * from MultiPet where TestClassName = '" + classNameString() + "'";
			Recordset recordset = dbConnection.recordset(strQuery);
			recordset.next();
			recordset.moveFirst();
			String multiPetYesNo = recordset.getField("MultiPet");
			numberOfMultiPetsString = recordset.getField("NumberOfMultiPets");
			int numberOfMultiPetsInt = Integer.valueOf(numberOfMultiPetsString);
			numberOfMultiPetsInt = numberOfMultiPetsInt + 1;
			yourPetDetailsTest = new YourPetDetailsTest();
			yourPetDetailsTest.initiateYourPetDetailsTest(classNameString());
			moreAboutYourPetTest = new MoreAboutYourPetTest();
			moreAboutYourPetTest.initiateMoreAboutYourPetTest(classNameString());
			customerDetailsTest = new CustomerDetailsTest();
			customerDetailsTest.initiateCustomerDetailsTest(classNameString());
			yourCoverTest = new YourCoverTest();
			yourCoverTest.testYourCover(classNameString());
			if (multiPetYesNo.equalsIgnoreCase("Yes")) {
				multiPetYourCoverTest = new MultiPetYourCoverTest();
				multiPetYourCoverTest.initiateMultiPetYourCoverTest(classNameString());
			}
			

			Thread.sleep(1000);
			String multiPetDiscountMessage = driver.get().findElement(By.xpath("//span[@class='my-auto discount__row--description']")).getText();
			softAssert.assertEquals(multiPetDiscountMessage, "Multi-pet discount");
			System.out.println(":"+multiPetDiscountMessage+":");
			
			String multiPetDiscountAppliedMessage = driver.get().findElement(By.xpath("//div[contains(text(), 'Discounts applied')]")).getText();
			System.out.println(":"+multiPetDiscountAppliedMessage+":");
			
			softAssert.assertEquals(multiPetDiscountAppliedMessage, "Discounts applied");
	/*		driver.get().findElement(By.id("userPhoneNumber")).sendKeys("0700000000000");
			driver.get().findElement(By.id("submitPhoneNumber")).click();
			driver.get().switchTo().activeElement().sendKeys(Keys.TAB);*/
			Thread.sleep(700);
			((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//button[text()='Next']")));
			((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//button[text()='Next']")));
			Thread.sleep(700);
			utilities.waitElement(driver.get().findElement(By.xpath("//label[@for='MP']")), driver);
	/*		String multiPetDiscountMessageFromReviewYourQuotePage = driver.get().findElement(By.xpath("//*[@id='sidebar']/div[1]/div/div/table/tbody/tr[5]/td[1]")).getText();
			System.out.println("Multipet : "+multiPetDiscountMessageFromReviewYourQuotePage);
			softAssert.assertEquals(multiPetDiscountMessageFromReviewYourQuotePage, "Multi-pet discount");
			
			String multiPetDiscountAppliedMessageFromReviewYourQuotePage = driver.get().findElement(By.xpath("//*[@id='sidebar']/div[1]/div/div/table/tbody/tr[5]/td[2]")).getText();
			softAssert.assertEquals(multiPetDiscountAppliedMessageFromReviewYourQuotePage, "Applied");
			System.out.println("Applied : "+multiPetDiscountAppliedMessageFromReviewYourQuotePage);*/
			softAssert.assertAll();
			dbConnection.closeConnection();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
			utilities.onTestFailure();
		}
	}
}