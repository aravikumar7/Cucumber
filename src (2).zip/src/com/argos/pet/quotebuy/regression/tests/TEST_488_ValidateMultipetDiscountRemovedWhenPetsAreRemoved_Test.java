/**
 * 
 */
package com.argos.pet.quotebuy.regression.tests;

import java.time.Duration;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.argos.pet.quotebuy.regression.common.code.dbconnection.DBConnection;
import com.argos.pet.quotebuy.regression.common.code.tests.AlmostThereTest;
import com.argos.pet.quotebuy.regression.common.code.tests.ConfirmationTest;
import com.argos.pet.quotebuy.regression.common.code.tests.CustomerDetailsTest;
import com.argos.pet.quotebuy.regression.common.code.tests.MoreAboutYourPetTest;
import com.argos.pet.quotebuy.regression.common.code.tests.MultiPetYourCoverTest;
import com.argos.pet.quotebuy.regression.common.code.tests.MultiPetYourQuoteSummaryTest;
import com.argos.pet.quotebuy.regression.common.code.tests.PaymentTest;
import com.argos.pet.quotebuy.regression.common.code.tests.PreExistingConditionsTest;
import com.argos.pet.quotebuy.regression.common.code.tests.YourCoverTest;
import com.argos.pet.quotebuy.regression.common.code.tests.YourPetDetailsTest;
import com.argos.pet.quotebuy.regression.common.code.tests.YourQuoteSummaryTest;
import com.argos.pet.quotebuy.regression.common.code.utilities.TestBase;
import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;
import com.codoid.products.fillo.Recordset;


/**
 * @author d23747
 *
 */

public class TEST_488_ValidateMultipetDiscountRemovedWhenPetsAreRemoved_Test extends TestBase {

	DBConnection dbConnection;
	YourPetDetailsTest yourPetDetailsTest;
	MoreAboutYourPetTest moreAboutYourPetTest;
	CustomerDetailsTest customerDetailsTest;
	YourCoverTest yourCoverTest;
	MultiPetYourCoverTest multiPetYourCoverTest;
	YourQuoteSummaryTest yourQuoteSummaryTest;
	MultiPetYourQuoteSummaryTest multiPetYourQuoteSummaryTest;
	PreExistingConditionsTest preExistingConditionsTest;
	PaymentTest paymentPageTest;
	AlmostThereTest almostThereTest;
	ConfirmationTest confirmationTest;
	Utilities utilities;
	SoftAssert softAssert;
	Wait<WebDriver> wait;
	String numberOfMultiPetsString;
	public String TextToWrite;
	static int numberOfMultiPets = 2;

	public String classNameString() throws Exception
	{
		String className = this.getClass().getSimpleName();
		return className;
	}

	@Test (priority = 0)
	public void initiate_TEST_488_ValidateMultipetDiscountRemovedWhenPetsAreRemoved()
	{
		try
		{
			dbConnection = new DBConnection();
			utilities = new Utilities();
			softAssert = new SoftAssert();
			TextToWrite = "Test: " + this.getClass().getSimpleName();
			utilities.Filewriter(TextToWrite);
			String  strQuery = "Select * from MultiPet where TestClassName = '" + this.getClass().getSimpleName() + "'";
			Recordset recordset = dbConnection.recordset(strQuery);
			recordset.next();
			recordset.moveFirst();
			String multiPetYesNo = recordset.getField("MultiPet");
			numberOfMultiPetsString = recordset.getField("NumberOfMultiPets");
			int numberOfMultiPetsInt = Integer.valueOf(numberOfMultiPetsString);
			numberOfMultiPetsInt = numberOfMultiPetsInt + 1;
			yourPetDetailsTest = new YourPetDetailsTest();
			yourPetDetailsTest.initiateYourPetDetailsTest(classNameString());
			moreAboutYourPetTest = new MoreAboutYourPetTest();
			moreAboutYourPetTest.initiateMoreAboutYourPetTest(classNameString());
			customerDetailsTest = new CustomerDetailsTest();
			customerDetailsTest.initiateCustomerDetailsTest(classNameString());
			yourCoverTest = new YourCoverTest();
			yourCoverTest.testYourCover(classNameString());
			if (multiPetYesNo.equalsIgnoreCase("Yes"))
			{
				multiPetYourCoverTest = new MultiPetYourCoverTest();
				multiPetYourCoverTest.initiateMultiPetYourCoverTest(classNameString());
			}
			

			String multiPetDiscountAppliedMessage = driver.get().findElement(By.xpath("//div[@class='discounts']/div/div")).getText();
			softAssert.assertEquals(multiPetDiscountAppliedMessage, "Discounts applied");
			System.out.println(":"+multiPetDiscountAppliedMessage+":");
			((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("(//div[text()='Remove pet'])[2]")));
			((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("(//div[text()='Remove pet'])[2]")));
			
			WebElement removePetButton = driver.get().findElement(By.xpath("//button[text()='Remove pet']"));
			utilities.waitElement(removePetButton, driver);
			removePetButton.click();
			
			if (!utilities.isElementPresent((By.id("pageLoadingCoverAnimation")),driver)) 
			{
			 wait = new FluentWait<WebDriver>(driver.get()).withTimeout(Duration.ofSeconds(20))
			        .pollingEvery(Duration.ofMillis(600)).ignoring(NoSuchElementException.class);
			wait.until(ExpectedConditions.invisibilityOf(driver.get().findElement(By.id("pageLoadingCoverAnimation"))));
			}
			
			boolean successtoaster=driver.get().findElements(By.xpath("//div[@class='Toastify']/div/div/button")).size()>0;
			if(successtoaster) {
			((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//div[@class='Toastify']/div/div/button")));
			((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//div[@class='Toastify']/div/div/button")));
			}
			
			Thread.sleep(3500);
			
			((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("(//div[text()='Remove pet'])[2]")));
			((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("(//div[text()='Remove pet'])[2]")));
		//	utilities.actionWaitClick(driver, driver.get().findElement(By.xpath("(//div[text()='Remove pet'])[2]")));
			
		//	driver.get().findElement(By.xpath("(//div[text()='Remove pet'])[2]")).click();
			removePetButton = driver.get().findElement(By.xpath("//button[text()='Remove pet']"));
			utilities.waitElement(removePetButton, driver);
			((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", removePetButton);
		//	((JavascriptExecutor) driver).executeScript("arguments[0].click();", removePetButton);
			removePetButton.click();
			if (!utilities.isElementPresent((By.id("pageLoadingCoverAnimation")),driver)) 
			{
				wait = new FluentWait<WebDriver>(driver.get()).withTimeout(Duration.ofSeconds(20))
			        .pollingEvery(Duration.ofMillis(600)).ignoring(NoSuchElementException.class);
			wait.until(ExpectedConditions.invisibilityOf(driver.get().findElement(By.id("pageLoadingCoverAnimation"))));
			}
		
			successtoaster=driver.get().findElements(By.xpath("//div[@class='Toastify']/div/div/button")).size()>0;
			if(successtoaster) {
			((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//div[@class='Toastify']/div/div/button")));
			((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//div[@class='Toastify']/div/div/button")));
			}
			
			Thread.sleep(3500);
			
			//String multiPetDiscountAppliedMessageFromReviewYourQuotePage = driver.get().findElement(By.xpath("//*[contains(text(), 'Applied')]")).getText();
			//softAssert.assertNotEquals(multiPetDiscountAppliedMessageFromReviewYourQuotePage, "Applied");
			WebElement payNowButton = driver.get().findElement(By.xpath("//button[text()='Next']"));
			utilities.waitElement(payNowButton, driver);
		/*	payNowButton.click();
			WebElement monthlyPayment=driver.get().findElement(By.xpath("//label[@for='MP']"));
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", monthlyPayment);
			((JavascriptExecutor) driver).executeScript("arguments[0].click();", monthlyPayment);
			
			WebElement backButton=driver.get().findElement(By.xpath("(//a[contains(@href,'/quote/review')])[2]"));
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", backButton);
			((JavascriptExecutor) driver).executeScript("arguments[0].click();", backButton);
			*/
			
			softAssert.assertFalse(utilities.isElementPresent(By.xpath("//div[contains(text(), 'Discounts applied')]"),driver));			
			 
			
			
			softAssert.assertAll();
			dbConnection.closeConnection();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println(e.getMessage());
			utilities.onTestFailure();
		}
	}
}