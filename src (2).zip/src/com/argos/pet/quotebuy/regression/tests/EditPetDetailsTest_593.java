/**
 * 
 */
package com.argos.pet.quotebuy.regression.tests;

import org.testng.annotations.Parameters;

import com.codoid.products.fillo.Recordset;
import com.argos.pet.quotebuy.regression.common.code.dbconnection.DBConnectionRegressionCommonCode;
import com.argos.pet.quotebuy.regression.common.code.pages.EditPetDetailsPage;
import com.argos.pet.quotebuy.regression.common.code.utilities.TestBase;
import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;


/**
 * @author d23747
 *
 */
public class EditPetDetailsTest_593 extends TestBase {

	DBConnectionRegressionCommonCode dbConnection;
	Utilities utilities;
	EditPetDetailsPage editPetDetailsPage;
	String className;
	public String ClassName;

	@Parameters ("ClassName")
	public void initiateEditPetDetailsTest_593(String ClassName) throws Exception
	{
		utilities = new Utilities();
		editPetDetailsPage = new EditPetDetailsPage(driver);
		className = utilities.getClassName(ClassName);
		String  strQuery = "Select * from EditCover where TestClassName = '" + className + "'";
		dbConnection = new DBConnectionRegressionCommonCode();
		Recordset recordset = dbConnection.recordset(strQuery);
		recordset.next();
		recordset.moveFirst();
		
		editPetDetailsPage.clickEditPetDetailsLink();
		//editPetDetailsPage.populatePetCost(recordset.getField("CostOfThePet"));
		editPetDetailsPage.selectNeuteredYes();
		editPetDetailsPage.clickSaveCloseButton();
		dbConnection.closeConnection();
	}
}