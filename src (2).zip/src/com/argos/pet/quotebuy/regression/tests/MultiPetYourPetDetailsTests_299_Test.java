package com.argos.pet.quotebuy.regression.tests;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.testng.asserts.SoftAssert;

import com.argos.pet.quotebuy.regression.common.code.dbconnection.DBConnection;
import com.argos.pet.quotebuy.regression.common.code.utilities.TestBase;
import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;
import com.codoid.products.fillo.Recordset;

public class MultiPetYourPetDetailsTests_299_Test extends TestBase{

	DBConnection dbConnection;
	Utilities utilities;
	Actions actions;
	SoftAssert softAssert;

	public void initiateMultiPetYourPetDetailsTests_299(String ClassName) throws Exception
	{
		utilities = new Utilities();
		dbConnection = new DBConnection();
		actions = new Actions(driver.get());
		softAssert = new SoftAssert();
	//	utilities.waitElement(driver.get().findElement(By.xpath("//*[@id='yourPetsSubmitButton']")), driver);
	//	Thread.sleep(3000);
		String className = utilities.getClassName(ClassName);
		String strQuery = "Select * from MoreAboutYourPet where TestClassName = '" + className + "'";
		Recordset recordset = dbConnection.recordset(strQuery);
		recordset.next();
		recordset.moveFirst();
		if (recordset.getField("MultiPet").equalsIgnoreCase("Yes"))
		{
			strQuery = "Select * from MultiPet where TestClassName = '" + className + "'";
			dbConnection = new DBConnection();
			recordset = dbConnection.recordset(strQuery);
			recordset.next();
			recordset.moveFirst();
			Thread.sleep(2500);
			((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", 	driver.get().findElement(By.xpath("//button[text()='Add another pet']")));
			((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", 	driver.get().findElement(By.xpath("//button[text()='Add another pet']")));
		//	utilities.waitElement(driver.get().findElement(By.xpath("//*[@id='pet2.pet_name']")), driver);
			((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//*[@id='pet2.pet_name']")));
			driver.get().findElement(By.xpath("//*[@id='pet2.pet_name']")).sendKeys(recordset.getField("MultiPetName_1"));
			
			((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//*[@for='radio_dog_pet2']")));
			((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//*[@for='radio_dog_pet2']")));
			/*
			 * if (recordset.getField("MultiPetSex_1").equalsIgnoreCase("Male")) {
			 * ((JavascriptExecutor)
			 * driver).executeScript("arguments[0].scrollIntoView(true);",
			 * driver.get().findElement(By.xpath("//label[contains(@for,'male_radio_1pet2')]")));
			 * ((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();",
			 * driver.get().findElement(By.xpath("//label[contains(@for,'male_radio_1pet2')]")));
			 * } else { ((JavascriptExecutor)
			 * driver).executeScript("arguments[0].scrollIntoView(true);",
			 * driver.get().findElement(By.xpath("//label[contains(@for,'female_radio_1pet2')]")))
			 * ; ((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();",
			 * driver.get().findElement(By.xpath("//label[contains(@for,'female_radio_1pet2')]")))
			 * ; }
			 */
			((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//button[text()='Your details']")));	
			((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//button[text()='Your details']")));
			
			String errorTextAtTheField = driver.get().findElement(By.xpath("//div[@class='pet-details-form-dog']/div/div/div[@class='error-message']")).getText();
			softAssert.assertEquals(errorTextAtTheField, recordset.getField("ErrorMessageAtTheField"));
			//softAssert.assertFalse(driver.get().findElement(By.xpath("//*[@id='petDetailsSubmit_2']")).isDisplayed());
			softAssert.assertAll();
			dbConnection.closeConnection();
		}
	}
}