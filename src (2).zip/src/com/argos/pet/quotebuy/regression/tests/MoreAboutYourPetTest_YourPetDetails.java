/**
 * 
 */
package com.argos.pet.quotebuy.regression.tests;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.codoid.products.fillo.Recordset;
import com.argos.pet.quotebuy.regression.common.code.dbconnection.DBConnectionRegressionCommonCode;
import com.argos.pet.quotebuy.regression.common.code.pages.MoreAboutYourPetPage;
import com.argos.pet.quotebuy.regression.common.code.utilities.TestBase;
import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;


/**
 * @author d23747
 *
 */
public class MoreAboutYourPetTest_YourPetDetails extends TestBase {

	DBConnectionRegressionCommonCode dbConnection;
	Utilities utilities;
	MoreAboutYourPetPage moreAboutYourPetPage;
	TestBase testBase;
	String className;
	Actions actions;
	public String ClassName;
	static String petInjuryIllness;

	public void initiateMoreAboutYourPetTest(String ClassName) throws Exception
	{
		utilities = new Utilities();
		className = utilities.getClassName(ClassName);
		String  strQuery = "Select * from MoreAboutYourPet where TestClassName = '" + className + "'";
		utilities = new Utilities();
		moreAboutYourPetPage = new MoreAboutYourPetPage(driver);
		dbConnection = new DBConnectionRegressionCommonCode();
		actions = new Actions(driver.get());
		Recordset recordset = dbConnection.recordset(strQuery);
		recordset.next();
		recordset.moveFirst();
		{
			Thread.sleep(2500);
			moreAboutYourPetPage.enterPetCost(recordset.getField("CostOfThePet"));
			driver.get().switchTo().activeElement().sendKeys(Keys.TAB);
			Thread.sleep(1500);

			if (recordset.getField("PetNeuteredRadioButton").equalsIgnoreCase("No"))
			{
				Thread.sleep(1500);
				moreAboutYourPetPage.selectPetNeuteredNoRadioButton();
			}
			else if (recordset.getField("PetNeuteredRadioButton").equalsIgnoreCase("Yes"))
			{
				Thread.sleep(1500);
				moreAboutYourPetPage.selectPetNeuteredYesRadioButton();
			}
			else
			{
				Thread.sleep(1500);
				moreAboutYourPetPage.selectPetNeuteredNoRadioButton();
			}
			petInjuryIllness = recordset.getField("PetAnyInjuryIllnessRadioButton");

			if (recordset.getField("PetAnyInjuryIllnessRadioButton").equalsIgnoreCase("No"))
			{
				moreAboutYourPetPage.selectPetAnyInjuryIllnessNoRadioButton();
			}
			else if (recordset.getField("PetAnyInjuryIllnessRadioButton").equalsIgnoreCase("Yes"))
			{
				moreAboutYourPetPage.selectPetAnyInjuryIllnessYesRadioButton();
			}
			else
			{
				moreAboutYourPetPage.selectPetAnyInjuryIllnessNoRadioButton();
			}
			if (recordset.getField("ChangeAssumptionLink").equals("Top"))
			{
				moreAboutYourPetPage.selectChangeAssumptionTopLink();
			}
			else if (recordset.getField("ChangeAssumptionLink").equals("Bottom"))
			{
				moreAboutYourPetPage.selectChangeAssumptionBottomLink();
			}
			else
			{
				moreAboutYourPetPage.selectAssumptionCorrectTickBox();
			}
		
			testBase = new TestBase();
		
		//	Thread.sleep(2500);
		//	petInjuryIllness = recordset.getField("PetAnyInjuryIllnessRadioButtonBasedOnRisk");
			if(className=="TEST_618_ValidateModifyingCatPriceHigherToLowerChangesQuoteResult_Test" || 
			   className=="TEST_619_ValidateModifyingCatPriceLowerToHigherChangesQuoteResult_Test" || 
			   className=="TEST_620_ValidateModifyingDogPriceHigherToLowerChangesQuoteResult_Test" || 
			   className=="TEST_656_ValidateModifyingRabbitPriceHigherToLowerChangesQuoteResult_Test" || 
			   className=="TEST_657_ValidateModifyingRabbitPriceLowerToHigherChangesQuoteResult_Test" || 
			   className=="TEST_622_ValidateModifyingDogPriceLowerToHigherChangesQuoteResult_Test"){
				WebElement dob = driver.get().findElement(By.id("pet1.pet_date_of_birth"));
				((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", dob);
				Thread.sleep(1500);
				((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", dob);
				// dob.sendKeys(Keys.ENTER);
				Thread.sleep(1500);
				dob.sendKeys(Keys.TAB);
				Thread.sleep(1500);
			moreAboutYourPetPage.clickNextButton();
			}
		}
	}
}