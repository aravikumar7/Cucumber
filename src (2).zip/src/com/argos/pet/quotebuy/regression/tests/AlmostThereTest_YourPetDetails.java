/**
 * 
 */
package com.argos.pet.quotebuy.regression.tests;

import java.io.IOException;

import com.argos.pet.quotebuy.regression.common.code.dbconnection.DBConnectionRegressionCommonCode;
import com.argos.pet.quotebuy.regression.common.code.pages.AlmostTherePage;
import com.argos.pet.quotebuy.regression.common.code.utilities.TestBase;
import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Recordset;


/**
 * @author d23747
 *
 */
public class AlmostThereTest_YourPetDetails extends TestBase {

	AlmostTherePage almostTherePage;
	DBConnectionRegressionCommonCode dbConnection;

	public void initiateAlmostThereTest() throws FilloException, IOException
	{
		almostTherePage = new AlmostTherePage(driver);
		dbConnection = new DBConnectionRegressionCommonCode();
		String  strQuery = "Select * from AlmostThere";
		Recordset recordset = dbConnection.recordset(strQuery);
		recordset.next();
		recordset.moveFirst();
		if (recordset.getField("BuyNowButton").equalsIgnoreCase("Top"))
		{
			almostTherePage.clickBuyNowTopButton();
		}
		else
		{
			almostTherePage.clickBuyNowBottomButton();
		}
		dbConnection.closeConnection();
	}
}
