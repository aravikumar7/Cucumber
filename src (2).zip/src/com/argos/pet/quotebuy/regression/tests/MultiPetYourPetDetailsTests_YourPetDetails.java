package com.argos.pet.quotebuy.regression.tests;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.argos.pet.quotebuy.regression.common.code.dbconnection.DBConnectionRegressionCommonCode;
import com.argos.pet.quotebuy.regression.common.code.utilities.TestBase;
import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;
import com.codoid.products.fillo.Recordset;

import org.openqa.selenium.JavascriptExecutor;

public class MultiPetYourPetDetailsTests_YourPetDetails extends TestBase{

	DBConnectionRegressionCommonCode dbConnection;
	Utilities utilities;
	Actions actions;
	String[] dobArray;
	String DOB_FromCoverStartDate;
	String dateOfBirth;
	
	public void initiateMultiPetYourPetDetailsTests(String ClassName) throws Exception
	{
		utilities = new Utilities();
		dbConnection = new DBConnectionRegressionCommonCode();
		actions = new Actions(driver.get());
		utilities.waitElement(driver.get().findElement(By.xpath("//*[@id='yourPetsSubmitButton']")), driver);
		Thread.sleep(3000);
		String className = utilities.getClassName(ClassName);
		String strQuery = "Select * from MoreAboutYourPet where TestClassName = '" + className + "'";
		Recordset recordset = dbConnection.recordset(strQuery);
		recordset.next();
		recordset.moveFirst();
		if (recordset.getField("MultiPet").equalsIgnoreCase("Yes"))
		{
			strQuery = "Select * from MultiPet where TestClassName = '" + className + "'";
			dbConnection = new DBConnectionRegressionCommonCode();
			recordset = dbConnection.recordset(strQuery);
			recordset.next();
			recordset.moveFirst();
			Thread.sleep(2500);
			driver.get().findElement(By.xpath("//*[@id='addAnotherPet_1']")).click();
			utilities.waitElement(driver.get().findElement(By.xpath("//*[@id='petName_2']")), driver);
			driver.get().findElement(By.xpath("//*[@id='petName_2']")).sendKeys(recordset.getField("MultiPetName_1"));

			if (recordset.getField("MultiPetType_1").equalsIgnoreCase("Dog"))
			{
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//*[@id='radio_dog_pet2']")));
				((JavascriptExecutor) driver).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//*[@id='radio_dog_pet2']")));
				utilities.waitElement(driver.get().findElement(By.xpath("//*[@for='breed_pet2']")), driver);
					if (recordset.getField("MultiPetTypeOfDog_1").equalsIgnoreCase("Breed"))
				{	
						((JavascriptExecutor) driver).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//*[@for='breed_pet2']")));
						Actions builder = new Actions(driver.get());
						driver.get().findElement(By.xpath("//div[@id='pet2.pet_breed']/div/div/div/div/input")).sendKeys("African Crested Dog");
						Thread.sleep(1000);
						builder.sendKeys(Keys.ENTER).perform();
				}
				else if (recordset.getField("MultiPetTypeOfDog_1").equalsIgnoreCase("Crossbreed"))
				{
					Actions builder = new Actions(driver.get());
					driver.get().findElement(By.xpath("//div[@id='pet2.pet_breed']/div/div/div/div/input")).sendKeys("African Crested Dog Cross");
					Thread.sleep(1000);
					builder.sendKeys(Keys.ENTER).perform();
				}
				else if (recordset.getField("MultiPetTypeOfDog_1").equalsIgnoreCase("Mongrel"))
				{
					Thread.sleep(1000);
					driver.get().findElement(By.xpath("//*[@id='mongrel-smallpet2']")).click();
					((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//*[@for='mmongrel-smallpet2']")));
					((JavascriptExecutor) driver).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//*[@for='mongrel-smallpet2']")));
		
				}
			}

			else
			{
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//*[@for='cat-other_pet2']")));
				((JavascriptExecutor) driver).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//*[@for='cat-other_pet2']")));
				
				Actions builder = new Actions(driver.get());
					driver.get().findElement(By.xpath("//div[@id='pet2.pet_breed']/div/div/div/div/input")).sendKeys("Angora");
					Thread.sleep(1000);
					builder.sendKeys(Keys.ENTER).perform();
				
			}
			dateOfBirth = recordset.getField("DOB_Date")+"/"+recordset.getField("DOB_Month")+"/"+recordset.getField("DOB_Year");
			driver.get().findElement(By.id("pet2.pet_date_of_birth")).sendKeys(dateOfBirth);
			if (recordset.getField("MultiPetSex_1").equalsIgnoreCase("Male"))
			{
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//label[contains(@for,'male_radio_1pet2')]")));
				((JavascriptExecutor) driver).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//label[contains(@for,'male_radio_1pet2')]")));
			}
			else
			{
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//label[contains(@for,'female_radio_1pet2')]")));	
				((JavascriptExecutor) driver).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//label[contains(@for,'female_radio_1pet2')]")));
			}

			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//div[text()='Next']//parent::button")));	
			((JavascriptExecutor) driver).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//div[text()='Next']//parent::button")));
		
			Thread.sleep(2500);
			dbConnection.closeConnection();
		}
	}
}