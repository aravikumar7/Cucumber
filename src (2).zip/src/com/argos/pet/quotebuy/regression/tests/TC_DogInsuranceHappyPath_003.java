/**
 * 
 */
package com.argos.pet.quotebuy.regression.tests;

import org.testng.annotations.Test;

import com.argos.pet.quotebuy.regression.common.code.pages.YourPetDetailsPage;



/**
 * @author d23747
 *
 */
public class TC_DogInsuranceHappyPath_003 {

	YourPetDetailsPage yourPetDetailsPage;

    @Test
    public void dogInsuranceHappyPathTest() throws InterruptedException
    {
        yourPetDetailsPage.setPetName("Tommy");
        yourPetDetailsPage.setPetTypeDog();
    }
}
