/**
 * 
 */
package com.argos.pet.quotebuy.regression.tests;

import org.openqa.selenium.By;

import com.argos.pet.quotebuy.regression.common.code.dbconnection.DBConnectionRegressionCommonCode;
import com.argos.pet.quotebuy.regression.common.code.pages.YourCoverPage;
import com.argos.pet.quotebuy.regression.common.code.utilities.TestBase;
import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;
import com.codoid.products.fillo.Recordset;

public class YourCoverTest_YourPetDetails extends TestBase {

	YourCoverPage yourCoverPage;
	DBConnectionRegressionCommonCode dbConnection;
	Utilities utilities;

	public void testYourCover() throws Exception
	{
		yourCoverPage = new YourCoverPage(driver);
		dbConnection = new DBConnectionRegressionCommonCode();
		utilities = new Utilities();
		String  strQuery = "Select * from YourCover";
		Recordset recordset = dbConnection.recordset(strQuery);
		recordset.next();
		recordset.moveFirst();
		if (recordset.getField("CoverType").equalsIgnoreCase("TimeLimited"))
		{
			String QuoteReferenceNumberText = yourCoverPage.getQuoteReferenceNumberText();
			System.out.println(QuoteReferenceNumberText);
			String QuoteValidityDate = yourCoverPage.getQuoteValidityDate();
			//System.out.println(QuoteValidityDate);
			String QuoteTimeLimitedMonthlyCost = yourCoverPage.getQuoteTimeLimitedMonthlyCost();
			//System.out.println(QuoteTimeLimitedMonthlyCost);
			String QuoteTimeLimitedYearlyCost = yourCoverPage.getQuoteTimeLimitedYearlyCost();
			//System.out.println(QuoteTimeLimitedYearlyCost);
			String TextToWrite = QuoteValidityDate + "_" + QuoteTimeLimitedMonthlyCost + "_" + QuoteTimeLimitedYearlyCost;
			utilities.Filewriter(TextToWrite);
			//utilities.TakePassScreenShot(driver);
			yourCoverPage.clickChooseTimeLimitedButton();
	//		utilities.waitElement(driver.findElement(By.xpath("//*[@id='coverLevel_4']")), driver);
			if (recordset.getField("TimeLimitedLevelOfCover").equalsIgnoreCase("�3000"))
			{
				yourCoverPage.clickRadio�1000Button();
			}
		}

		else if(recordset.getField("CoverType").equalsIgnoreCase("Lifetime"))
		{
			String QuoteLifetimeMonthlyCost = yourCoverPage.getQuoteLifetimeMonthlyCost();
			//System.out.println(QuoteLifetimeMonthlyCost);
			String QuoteLifetimeYearlyCost = yourCoverPage.getQuoteLifetimeYearlyCost();
			//System.out.println(QuoteLifetimeYearlyCost);
			String TextToWrite = QuoteLifetimeMonthlyCost + "_" + QuoteLifetimeYearlyCost;
			utilities.Filewriter(TextToWrite);
			//utilities.TakePassScreenShot(driver);
			yourCoverPage.clickChooseLifetimeButton();
		//	utilities.waitElement(driver.findElement(By.xpath("//*[@id='coverLevel_7']")), driver);

			if (recordset.getField("LifetimeLevelOfCover").equalsIgnoreCase("�2500"))
			{
				yourCoverPage.clickRadio�2500Button();
			}
			
			if (recordset.getField("LifetimeLevelOfCover").equalsIgnoreCase("�2500"))
			{
				yourCoverPage.clickRadio�2500Button();
			}
			
			if (recordset.getField("LifetimeLevelOfCover").equalsIgnoreCase("�7000"))
			{
				yourCoverPage.clickRadio�7000Button();
			}
			
		}
		
		else {
			if (recordset.getField("MaxBenefitOfCover").equalsIgnoreCase("�3000"))
			{
				yourCoverPage.clickRadioMax�2000Button();
			}
			if (recordset.getField("MaxBenefitOfCover").equalsIgnoreCase("�6000"))
			{
				yourCoverPage.clickRadioMax�5000Button();
			}
		}
		yourCoverPage.clickReviewButton();
		dbConnection.closeConnection();
	}
}
