/**
 * 
 */
package com.argos.pet.quotebuy.regression.tests;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.testng.annotations.Parameters;
import org.testng.asserts.SoftAssert;

import com.codoid.products.fillo.Recordset;
import com.argos.pet.quotebuy.regression.common.code.dbconnection.DBConnectionRegressionCommonCode;
import com.argos.pet.quotebuy.regression.common.code.pages.EditPetDetailsPage;
import com.argos.pet.quotebuy.regression.common.code.pages.YourPetDetailsPage;
import com.argos.pet.quotebuy.regression.common.code.pages.YourQuoteSummaryPage;
import com.argos.pet.quotebuy.regression.common.code.tests.YourPetDetailsTest;
import com.argos.pet.quotebuy.regression.common.code.utilities.TestBase;
import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;


/**
 * @author d23747
 *
 */
public class EditPetDetailsTest_733 extends TestBase {

	DBConnectionRegressionCommonCode dbConnection;
	Utilities utilities;
	EditPetDetailsPage editPetDetailsPage;
	String className;
	public String ClassName;
	public static ThreadLocal<String[]> regressionTestDataArray;
	SoftAssert softAssert;
	String[] dobArray;
	YourQuoteSummaryPage yourQuoteSummaryPage;
	
	@Parameters ("ClassName")
	public void initiateEditPetDetailsTest_733(String ClassName) throws Exception
	{
		utilities = new Utilities();
		editPetDetailsPage = new EditPetDetailsPage(driver);
		softAssert = new SoftAssert();
		yourQuoteSummaryPage = new YourQuoteSummaryPage(driver);
		className = utilities.getClassName(ClassName);
		String  strQuery = "Select * from EditCover where TestClassName = '" + className + "'";
		dbConnection = new DBConnectionRegressionCommonCode();
		Recordset recordset = dbConnection.recordset(strQuery);
		recordset.next();
		recordset.moveFirst();
		regressionTestDataArray = YourPetDetailsTest.regressionTestDataArray;

		editPetDetailsPage.clickEditPetDetailsLink();
		dobArray = utilities.getDOB(recordset.getField("DOB_FromCoverStartDate"));
		System.out.println("Pet: 1 DOB: " + dobArray[0] + "." + dobArray[1] + "." + dobArray[2]);
		Thread.sleep(500);
		editPetDetailsPage.populateDobDay(dobArray[0]);
		editPetDetailsPage.populateDobMonth(dobArray[1]);
		editPetDetailsPage.populateDobYear(dobArray[2]);
	//	editPetDetailsPage.populatedateOfBirth("02/06/2015");
		driver.get().switchTo().activeElement().sendKeys(Keys.TAB);
		editPetDetailsPage.clickSaveCloseButton();
		Thread.sleep(500);
		if (utilities.isElementPresent(By.xpath("//*[@id='floatingToasterPanel']/div/div/div/div"), driver))
		{
			driver.get().findElement(By.xpath("//*[@id='floatingToasterPanel']/div/div/div/button")).click();
			Thread.sleep(2500);
			driver.get().switchTo().activeElement();
			dbConnection.closeConnection();
		}
	}
}