/**
 * 
 */
package com.argos.pet.quotebuy.regression.tests;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.argos.pet.quotebuy.regression.common.code.dbconnection.DBConnection;
import com.argos.pet.quotebuy.regression.common.code.tests.MoreAboutYourPetTest;
import com.argos.pet.quotebuy.regression.common.code.tests.MultiPetYourCoverTest;
import com.argos.pet.quotebuy.regression.common.code.tests.MultiPetYourQuoteSummaryTest;
import com.argos.pet.quotebuy.regression.common.code.tests.PaymentTest;
import com.argos.pet.quotebuy.regression.common.code.tests.PreExistingConditionsTest;
import com.argos.pet.quotebuy.regression.common.code.tests.YourCoverTest;
import com.argos.pet.quotebuy.regression.common.code.tests.YourPetDetailsTest;
import com.argos.pet.quotebuy.regression.common.code.tests.YourQuoteSummaryTest;
import com.argos.pet.quotebuy.regression.common.code.utilities.TestBase;
import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;
import com.codoid.products.fillo.Recordset;


/**
 * @author d23747
 *
 */

public class TEST_598_ValidateContinueWithoutProductSelection_Test extends TestBase {

	DBConnection dbConnection;
	YourPetDetailsTest yourPetDetailsTest;
	MoreAboutYourPetTest moreAboutYourPetTest;
	CustomerDetailsTest_YourPetDetails_Test customerDetailsTest;
	YourCoverTest yourCoverTest;
	MultiPetYourCoverTest multiPetYourCoverTest;
	YourQuoteSummaryTest yourQuoteSummaryTest;
	MultiPetYourQuoteSummaryTest multiPetYourQuoteSummaryTest;
	EditPetDetailsTest_593 editPetDetailsTest_593;
	PreExistingConditionsTest preExistingConditionsTest;
	PaymentTest paymentPageTest;
	Utilities utilities;
	SoftAssert softAssert;
	String numberOfMultiPetsString;
	public String TextToWrite;
	static int numberOfMultiPets = 2;

	public String classNameString() throws Exception
	{
		String className = this.getClass().getSimpleName();
		return className;
	}

	@Test (priority = 0)
	public void initiate_TEST_598_ValidateContinueWithoutProductSelection_Test()
	{
		try
		{
			dbConnection = new DBConnection();
			utilities = new Utilities();
			softAssert = new SoftAssert();
			TextToWrite = "Test: " + this.getClass().getSimpleName();
			utilities.Filewriter(TextToWrite);
			String  strQuery = "Select * from MultiPet where TestClassName = '" + this.getClass().getSimpleName() + "'";
			Recordset recordset = dbConnection.recordset(strQuery);
			recordset.next();
			recordset.moveFirst();
			String multiPetYesNo = recordset.getField("MultiPet");
			numberOfMultiPetsString = recordset.getField("NumberOfMultiPets");
			int numberOfMultiPetsInt = Integer.valueOf(numberOfMultiPetsString);
			numberOfMultiPetsInt = numberOfMultiPetsInt + 1;
			yourPetDetailsTest = new YourPetDetailsTest();
			yourPetDetailsTest.initiateYourPetDetailsTest(classNameString());
			moreAboutYourPetTest = new MoreAboutYourPetTest();
			moreAboutYourPetTest.initiateMoreAboutYourPetTest(classNameString());
			customerDetailsTest = new CustomerDetailsTest_YourPetDetails_Test();
			customerDetailsTest.initiateCustomerDetailsTest(classNameString());
			if (multiPetYesNo.equalsIgnoreCase("Yes"))
			{
				multiPetYourCoverTest = new MultiPetYourCoverTest();
				multiPetYourCoverTest.initiateMultiPetYourCoverTest(classNameString());
			}
	//		yourCoverTest = new YourCoverTest();
		//	yourCoverTest.testYourCover(classNameString());
			
			//driver.get().switchTo().activeElement().sendKeys(Keys.TAB);
			//WebElement payNowButton = driver.get().findElement(By.xpath("//*[@id='goToReviewPage']"));
			//utilities.waitElement(payNowButton, driver);
			Thread.sleep(3000);
			//payNowButton.click();
			if(driver.get().findElements(By.xpath("//*[@id='goToReviewPage']")).size() < 1) {
			softAssert.assertTrue(true);
			}
			else {
				softAssert.assertTrue(true);
			}
				softAssert.assertAll();
			dbConnection.closeConnection();

		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println(e.getMessage());
			utilities.onTestFailure();
		}
	}
}