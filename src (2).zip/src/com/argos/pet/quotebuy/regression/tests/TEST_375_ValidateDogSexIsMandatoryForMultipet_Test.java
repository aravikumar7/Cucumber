/**
 * 
 */
package com.argos.pet.quotebuy.regression.tests;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.argos.pet.quotebuy.regression.common.code.dbconnection.DBConnection;
import com.argos.pet.quotebuy.regression.common.code.pages.YourPetDetailsPage;
import com.argos.pet.quotebuy.regression.common.code.utilities.TestBase;
import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;
import com.codoid.products.fillo.Recordset;


/**
 * @author d23747
 *
 */

public class TEST_375_ValidateDogSexIsMandatoryForMultipet_Test extends TestBase {

	DBConnection dbConnection;
	Utilities utilities;
	YourPetDetailsPage yourPetDetailsPage;
	TestBase testBase;
	SoftAssert softAssert;
	String[] dobArray;
	YourPetDetailsTest_YourPetDetails yourPetDetailsTest;
	MoreAboutYourPetTest_YourPetDetails moreAboutYourPetTest;
	MultiPetYourPetDetailsTests_375_Test multiPetYourPetDetailsTests_375;
	String numberOfMultiPetsString;
	public String TextToWrite;
	static int numberOfMultiPets = 2;

	public String classNameString() throws Exception
	{
		String className = this.getClass().getSimpleName();
		return className;
	}

	@Test
	public void initiate_TEST_375_ValidateDogSexIsMandatoryForMultipet()
	{
		try
		{
			dbConnection = new DBConnection();
			utilities = new Utilities();
			TextToWrite = "Test: " + this.getClass().getSimpleName();
			utilities.Filewriter(TextToWrite);
			String  strQuery = "Select * from MultiPet where TestClassName = '" + this.getClass().getSimpleName() + "'";
			Recordset recordset = dbConnection.recordset(strQuery);
			recordset.next();
			recordset.moveFirst();
			numberOfMultiPetsString = recordset.getField("NumberOfMultiPets");
			int numberOfMultiPetsInt = Integer.valueOf(numberOfMultiPetsString);
			numberOfMultiPetsInt = numberOfMultiPetsInt + 1;
			yourPetDetailsTest = new YourPetDetailsTest_YourPetDetails();
			yourPetDetailsTest.initiateYourPetDetailsTest(classNameString());
			moreAboutYourPetTest = new MoreAboutYourPetTest_YourPetDetails();
			moreAboutYourPetTest.initiateMoreAboutYourPetTest(classNameString());
			multiPetYourPetDetailsTests_375 = new MultiPetYourPetDetailsTests_375_Test();
			multiPetYourPetDetailsTests_375.initiateMultiPetYourPetDetailsTests_375(classNameString());
			dbConnection.closeConnection();
		}
		catch (Exception e)
		{
			e.printStackTrace();
			e.getMessage();
			utilities.onTestFailure();
		}
	}
}