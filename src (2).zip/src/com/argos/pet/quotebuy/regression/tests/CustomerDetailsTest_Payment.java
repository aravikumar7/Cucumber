package com.argos.pet.quotebuy.regression.tests;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.argos.pet.quotebuy.regression.common.code.dbconnection.DBConnectionRegressionCommonCode;
import com.argos.pet.quotebuy.regression.common.code.pages.CustomerDetailsPage;
import com.argos.pet.quotebuy.regression.common.code.pages.PaymentPage;
import com.argos.pet.quotebuy.regression.common.code.tests.YourPetDetailsTest;
import com.argos.pet.quotebuy.regression.common.code.utilities.TestBase;
import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;
import com.codoid.products.fillo.Recordset;

public class CustomerDetailsTest_Payment extends TestBase {

	DBConnectionRegressionCommonCode dbConnection;
//	CustomerDetailsPage customerDetails;
	PaymentPage paymentPage;
	TEST_209_ValidateCustomerAgeValidation_Test test_209_ValidateCustomerAgeValidation;
	Actions actions;
	Utilities utilities;
	SoftAssert softAssert;
	String className;
	String coverStartDate;
	ThreadLocal<String[]> regressionTestDataArray;
	public String nextMonth;
	public String TextToWrite;
	Actions builder;
	String dateOfBirth;
	
	@Test
	public void initiateCustomerDetailsCusDetTestTest() throws Exception
	{
		paymentPage = new PaymentPage(driver);
		test_209_ValidateCustomerAgeValidation = new TEST_209_ValidateCustomerAgeValidation_Test();
		softAssert = new SoftAssert();
		actions = new Actions(driver.get());
		utilities = new Utilities();
		dbConnection = new DBConnectionRegressionCommonCode();
		className = test_209_ValidateCustomerAgeValidation.classNameString();
		String  strQuery = "Select * from RegressionData where TestClassName = '" + className + "'";
		Recordset recordset = dbConnection.recordset(strQuery);
		recordset.next();
		recordset.moveFirst();
		nextMonth = utilities.getNextMonth();
		regressionTestDataArray = YourPetDetailsTest.regressionTestDataArray;
	//	customerDetails = new CustomerDetailsPage(driver);
		driver.get().switchTo().activeElement().sendKeys(Keys.TAB);
		paymentPage.selectCustomerTitle((regressionTestDataArray.get())[13]);
		driver.get().findElement(By.id("customer_first_name")).click();
		driver.get().switchTo().activeElement().sendKeys(Keys.TAB);
			
		String CustomerFirstName_BlankErrorMessage_FromExcel = recordset.getField("CustomerFirstName_BlankErrorMessage");
			String CustomerFirstName_BlankErrorMessage_FromWeb = driver.get().findElement(By.xpath("//*[@id='customer_first_nameContainer']/div")).getText();
			softAssert.assertEquals(CustomerFirstName_BlankErrorMessage_FromWeb, CustomerFirstName_BlankErrorMessage_FromExcel);
			softAssert.assertAll();
			TextToWrite = "Blank customer first name error message is displayed correctly";
			utilities.Filewriter(TextToWrite);
	
			paymentPage.populateCustomerFirstName((regressionTestDataArray.get())[6]);
		driver.get().findElement(By.id("customer_last_name")).click();
		driver.get().switchTo().activeElement().sendKeys(Keys.TAB);
			String CustomerLastName_BlankErrorMessage_FromExcel = recordset.getField("CustomerLastName_BlankErrorMessage");
			String CustomerLastName_BlankErrorMessage_FromWeb = driver.get().findElement(By.xpath("//*[@id='customer_last_nameContainer']/div")).getText();
			softAssert.assertEquals(CustomerLastName_BlankErrorMessage_FromWeb, CustomerLastName_BlankErrorMessage_FromExcel);
			softAssert.assertAll();
			TextToWrite = "Blank customer last name error message is displayed correctly";
			utilities.Filewriter(TextToWrite);
		
			paymentPage.populateCustomerLastName((regressionTestDataArray.get())[7]);
		dateOfBirth = (regressionTestDataArray.get())[8]+"/"+(regressionTestDataArray.get())[9]+"/"+(regressionTestDataArray.get())[10];
		paymentPage.populatedateOfBirth("");
		driver.get().switchTo().activeElement().sendKeys(Keys.TAB);
		
			String CustomerDOBYear_BlankErrorMessage_FromExcel = recordset.getField("CustomerDOBYear_BlankErrorMessage");
			String CustomerDOBYear_BlankErrorMessage_FromWeb = driver.get().findElement(By.xpath("//*[@id='customer_date_of_birthContainer']/div")).getText();
			softAssert.assertEquals(CustomerDOBYear_BlankErrorMessage_FromWeb, CustomerDOBYear_BlankErrorMessage_FromExcel);
			softAssert.assertAll();
			TextToWrite = "Blank customer DOB error message is displayed correctly";
			utilities.Filewriter(TextToWrite);
		
			paymentPage.populatedateOfBirth(dateOfBirth);
	
	
			String PhoneNumber_BlankErrorMessage_FromExcel = recordset.getField("PhoneNumber_BlankErrorMessage");
			String PhoneNumber_BlankErrorMessage_FromWeb = driver.get().findElement(By.xpath("//div[@id='customer_contact_numberContainer']/div")).getText();
			softAssert.assertEquals(PhoneNumber_BlankErrorMessage_FromWeb, PhoneNumber_BlankErrorMessage_FromExcel);
			softAssert.assertAll();
			TextToWrite = "Blank Phone Number error message is displayed correctly";
			utilities.Filewriter(TextToWrite);
	
			paymentPage.populateCustomerPhoneNumber((regressionTestDataArray.get())[17]);
		TextToWrite = "Customer Details: " + " Title: " + (regressionTestDataArray.get())[13] + " First Name: " + (regressionTestDataArray.get())[6] + " Last Name: " + 
				(regressionTestDataArray.get())[7] + " DOB: " + (regressionTestDataArray.get())[8] + "." + (regressionTestDataArray.get())[9] + "." + (regressionTestDataArray.get())[10];
		
		utilities.Filewriter(TextToWrite);
	//	customerDetails.clickFloatingToasterPanelSuccessClose();
		Thread.sleep(3500);
	//	customerDetails.clickGetAQuoteButton();
		if (recordset.getField("PaymentFrequency").equalsIgnoreCase("Monthly"))
		{
			paymentPage.clickPayMonthlyRadioButton();
			TextToWrite = "Payment Frequency = Monthly";
			utilities.Filewriter(TextToWrite);
		}
		else
		{
			paymentPage.clickPayYearlyRadioButton();
			TextToWrite = "Payment Frequency = Yearly";
			utilities.Filewriter(TextToWrite);
		}
		
		
		if(recordset.getField("PaymentMeans").equalsIgnoreCase("DirectDebit"))
		{
		paymentPage.clickDirectDebitRadioButton();
		paymentPage.populateSortCode(recordset.getField("SortCode1")+"�"+recordset.getField("SortCode2")+"�"+recordset.getField("SortCode3"));
		paymentPage.populateAccountNumber(recordset.getField("AccountNumber"));
		paymentPage.populatePreferredPaymentDate(recordset.getField("PreferredPaymentDate"));
		}
		else if(recordset.getField("PaymentMeans").equalsIgnoreCase("DirectCredit"))
		{
			paymentPage.clickDebitCreditCardRadioButton();
			paymentPage.populateCreditCardNumber(recordset.getField("CreditCardNumber"));
			paymentPage.populateCreditCardExpiryDateMM(recordset.getField("CreditCardExpiryDateMM"));
			paymentPage.populateCreditCardExpiryDateYY(recordset.getField("CreditCardExpiryDateYY"));
			paymentPage.populateCreditCardSecurityCode(recordset.getField("CreditCardSecurityCode"));
			paymentPage.populateCreditCardAccountName(recordset.getField("AccountName"));
		}
		
		TextToWrite = "Preferred Payment Date = " + recordset.getField("PreferredPaymentDate");
		utilities.Filewriter(TextToWrite);
		paymentPage.clickDirectDebitConfirmationTickBox();
		paymentPage.clickConfirmPaymentButton();
		dbConnection.closeConnection();
		//return regressionTestDataArray;
	}
}