/**
 * 
 */
package com.argos.pet.quotebuy.regression.tests;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.testng.annotations.Parameters;
import org.testng.asserts.SoftAssert;

import com.argos.pet.quotebuy.regression.common.code.dbconnection.DBConnectionRegressionCommonCode;
import com.argos.pet.quotebuy.regression.common.code.pages.EditPetDetailsPage;
import com.argos.pet.quotebuy.regression.common.code.pages.YourQuoteSummaryPage;
import com.argos.pet.quotebuy.regression.common.code.utilities.TestBase;
import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;
import com.codoid.products.fillo.Recordset;


/**
 * @author d23747
 *
 */
public class EditPetDetailsTest_720 extends TestBase {

	DBConnectionRegressionCommonCode dbConnection;
	Utilities utilities;
	EditPetDetailsPage editPetDetailsPage;
	String className;
	public String ClassName;
	SoftAssert softAssert;
	YourQuoteSummaryPage yourQuoteSummaryPage;

	@Parameters ("ClassName")
	public void initiateEditPetDetailsTest_720(String ClassName) throws Exception
	{
		utilities = new Utilities();
		editPetDetailsPage = new EditPetDetailsPage(driver);
		softAssert = new SoftAssert();
		yourQuoteSummaryPage = new YourQuoteSummaryPage(driver);
		className = utilities.getClassName(ClassName);
		String  strQuery = "Select * from EditCover where TestClassName = '" + className + "'";
		dbConnection = new DBConnectionRegressionCommonCode();
		Recordset recordset = dbConnection.recordset(strQuery);
		recordset.next();
		recordset.moveFirst();

		editPetDetailsPage.clickEditPetDetailsLink();
		Thread.sleep(700);
	//	editPetDetailsPage.setPetTypeDog();
	//	Thread.sleep(700);
	//	editPetDetailsPage.setPetTypeCat();
	//	Thread.sleep(700);
	//	editPetDetailsPage.whatBreedQuestionTextField();
	//	driver.get().switchTo().activeElement().sendKeys(Keys.BACK_SPACE);
		driver.get().findElement(By.xpath("//label[@for='cat-other_pet1']")).click();
		editPetDetailsPage.populateBreedType("Colour Point (Longhair)");
	//	editPetDetailsPage.selectFromList();
		//driver.get().switchTo().activeElement().sendKeys(Keys.TAB);
		editPetDetailsPage.populatePetCost("20");
		editPetDetailsPage.clickSaveCloseButton();
		Thread.sleep(2500);
		if (utilities.isElementPresent(By.xpath("//*[@id='floatingToasterPanel']/div/div/div/div"), driver))
		{
			driver.get().findElement(By.xpath("//*[@id='floatingToasterPanel']/div/div/div/button")).click();
			Thread.sleep(2500);
			driver.get().switchTo().activeElement();
		}
		String petBreed = yourQuoteSummaryPage.getPetBreed();
		System.out.println(petBreed);
		softAssert.assertEquals(petBreed, "Colour Point (Longhair)");
		Thread.sleep(2500);
		softAssert.assertAll();
		dbConnection.closeConnection();
	}
}