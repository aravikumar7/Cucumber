/**
 * 
 */
package com.argos.pet.quotebuy.regression.tests;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.codoid.products.fillo.Recordset;
import com.argos.pet.quotebuy.regression.common.code.dbconnection.DBConnection;
import com.argos.pet.quotebuy.regression.common.code.tests.CustomerDetailsTest;
import com.argos.pet.quotebuy.regression.common.code.tests.MoreAboutYourPetTest;
import com.argos.pet.quotebuy.regression.common.code.tests.MultiPetYourCoverTest;
import com.argos.pet.quotebuy.regression.common.code.tests.MultiPetYourQuoteSummaryTest;
import com.argos.pet.quotebuy.regression.common.code.tests.PaymentTest;
import com.argos.pet.quotebuy.regression.common.code.tests.PreExistingConditionsTest;
import com.argos.pet.quotebuy.regression.common.code.tests.YourCoverTest;
import com.argos.pet.quotebuy.regression.common.code.tests.YourPetDetailsTest;
import com.argos.pet.quotebuy.regression.common.code.tests.YourQuoteSummaryTest;
import com.argos.pet.quotebuy.regression.common.code.utilities.TestBase;
import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;


/**
 * @author d23747
 *
 */

public class TEST_650_ValidateRemovePetUnderPetDetailsForMultipet_Test extends TestBase {

	DBConnection dbConnection;
	YourPetDetailsTest yourPetDetailsTest;
	MoreAboutYourPetTest moreAboutYourPetTest;
	CustomerDetailsTest customerDetailsTest;
	YourCoverTest yourCoverTest;
	MultiPetYourCoverTest multiPetYourCoverTest;
	YourQuoteSummaryTest yourQuoteSummaryTest;
	MultiPetYourQuoteSummaryTest multiPetYourQuoteSummaryTest;
	PreExistingConditionsTest preExistingConditionsTest;
	PaymentTest paymentPageTest;
	Utilities utilities;
	SoftAssert softAssert;
	Actions actions;
	String numberOfMultiPetsString;
	public String TextToWrite;
	static int numberOfMultiPets = 2;

	public String classNameString() throws Exception
	{
		String className = this.getClass().getSimpleName();
		return className;
	}

	@Test (priority = 0)
	public void initiate_TEST_650_ValidateRemovePetUnderPetDetailsForMultipet()
	{
		try
		{
			dbConnection = new DBConnection();
			utilities = new Utilities();
			softAssert = new SoftAssert();
			actions = new Actions(driver.get());
			TextToWrite = "Test: " + this.getClass().getSimpleName();
			utilities.Filewriter(TextToWrite);
			String  strQuery = "Select * from MultiPet where TestClassName = '" + this.getClass().getSimpleName() + "'";
			Recordset recordset = dbConnection.recordset(strQuery);
			recordset.next();
			recordset.moveFirst();
			numberOfMultiPetsString = recordset.getField("NumberOfMultiPets");
			int numberOfMultiPetsInt = Integer.valueOf(numberOfMultiPetsString);
			numberOfMultiPetsInt = numberOfMultiPetsInt + 1;
			yourPetDetailsTest = new YourPetDetailsTest();
			yourPetDetailsTest.initiateYourPetDetailsTest(classNameString());
			moreAboutYourPetTest = new MoreAboutYourPetTest();
			moreAboutYourPetTest.initiateMoreAboutYourPetTest(classNameString());
			
			WebElement backButton = driver.get().findElement(By.xpath("(//a[@href='/quote/'])[2]"));
			((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", backButton);
			((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", backButton);

			WebElement removePetLink = driver.get().findElement(By.xpath("(//button[text()='Remove pet'])[2]"));
			((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", removePetLink);
			((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", removePetLink);
			
			WebElement removePetButton = driver.get().findElement(By.xpath("//button[@class='btn btn-primary remove-pet-cta']"));
			((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", removePetButton);
			((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", removePetButton);
			
			dbConnection.closeConnection();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println(e.getMessage());
			utilities.onTestFailure();
		}
	}
}