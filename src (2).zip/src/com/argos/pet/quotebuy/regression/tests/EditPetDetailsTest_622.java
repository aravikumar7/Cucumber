/**
 * 
 */
package com.argos.pet.quotebuy.regression.tests;

import org.openqa.selenium.Keys;
import org.testng.annotations.Parameters;

import com.argos.pet.quotebuy.regression.common.code.dbconnection.DBConnectionRegressionCommonCode;
import com.argos.pet.quotebuy.regression.common.code.pages.EditPetDetailsPage;
import com.argos.pet.quotebuy.regression.common.code.utilities.TestBase;
import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;
import com.codoid.products.fillo.Recordset;

/**
 * @author d23747
 *
 */
public class EditPetDetailsTest_622 extends TestBase {

	DBConnectionRegressionCommonCode dbConnection;
	Utilities utilities;
	EditPetDetailsPage editPetDetailsPage;
	String className;
	public String ClassName;

	@Parameters ("ClassName")
	public void initiateEditPetDetailsTest_622(String ClassName) throws Exception
	{
		utilities = new Utilities();
		editPetDetailsPage = new EditPetDetailsPage(driver);
		className = utilities.getClassName(ClassName);
		String  strQuery = "Select * from EditCover where TestClassName = '" + className + "'";
		dbConnection = new DBConnectionRegressionCommonCode();
		Recordset recordset = dbConnection.recordset(strQuery);
		recordset.next();
		recordset.moveFirst();
		String PetCost = recordset.getField("CostOfThePet");
		
		editPetDetailsPage.clickEditPetDetailsLink();
		editPetDetailsPage.populatePetCost(PetCost);
		driver.get().switchTo().activeElement().sendKeys(Keys.TAB);
		Thread.sleep(700);
		editPetDetailsPage.clickSaveCloseButton();
		Thread.sleep(700);
		dbConnection.closeConnection();
	}
}