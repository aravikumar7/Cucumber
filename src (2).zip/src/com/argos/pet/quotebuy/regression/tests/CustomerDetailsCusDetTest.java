package com.argos.pet.quotebuy.regression.tests;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.argos.pet.quotebuy.regression.common.code.dbconnection.DBConnectionRegressionCommonCode;
import com.argos.pet.quotebuy.regression.common.code.pages.CustomerDetailsPage;
import com.argos.pet.quotebuy.regression.common.code.tests.YourPetDetailsTest;
import com.argos.pet.quotebuy.regression.common.code.utilities.TestBase;
import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;
import com.codoid.products.fillo.Recordset;

public class CustomerDetailsCusDetTest extends TestBase {

	DBConnectionRegressionCommonCode dbConnection;
	CustomerDetailsPage customerDetails;
	TEST_209_ValidateCustomerAgeValidation_Test test_209_ValidateCustomerAgeValidation;
	Actions actions;
	Utilities utilities;
	SoftAssert softAssert;
	String className;
	String coverStartDate;
	ThreadLocal<String[]> regressionTestDataArray;
	public String nextMonth;
	public String TextToWrite;
	Actions builder;
	String dateOfBirth;
	
	@Test
	public String[] initiateCustomerDetailsCusDetTestTest() throws Exception
	{
		customerDetails = new CustomerDetailsPage(driver);
		test_209_ValidateCustomerAgeValidation = new TEST_209_ValidateCustomerAgeValidation_Test();
		softAssert = new SoftAssert();
		actions = new Actions(driver.get());
		utilities = new Utilities();
		dbConnection = new DBConnectionRegressionCommonCode();
		className = test_209_ValidateCustomerAgeValidation.classNameString();
		//System.out.println("Class name is :"+className);
		String  strQuery = "Select * from RegressionData where TestClassName = '" + className + "'";
		Recordset recordset = dbConnection.recordset(strQuery);
		recordset.next();
		recordset.moveFirst();
		nextMonth = utilities.getNextMonth();
		regressionTestDataArray = YourPetDetailsTest.regressionTestDataArray;
	//+ Moved to Payment
		/*
		String CoverStartDate_NumberOfDaysInFuture = regressionTestDataArray[16];
		coverStartDate = utilities.getCoverStartDate(CoverStartDate_NumberOfDaysInFuture);
		System.out.println(coverStartDate);
		customerDetails = new CustomerDetailsPage(driver);
		driver.get()get().switchTo().activeElement().sendKeys(Keys.TAB);
		customerDetails.selectCustomerTitle(regressionTestDataArray[13]);
		driver.get()findElement(By.id("customer_first_name")).click();
		driver.get()get().switchTo().activeElement().sendKeys(Keys.TAB);
			
		String CustomerFirstName_BlankErrorMessage_FromExcel = recordset.getField("CustomerFirstName_BlankErrorMessage");
			String CustomerFirstName_BlankErrorMessage_FromWeb = driver.get()findElement(By.xpath("//*[@id='customer_first_nameContainer']/div")).getText();
			softAssert.assertEquals(CustomerFirstName_BlankErrorMessage_FromWeb, CustomerFirstName_BlankErrorMessage_FromExcel);
			softAssert.assertAll();
			TextToWrite = "Blank customer first name error message is displayed correctly";
			utilities.Filewriter(TextToWrite);
	
			customerDetails.populateCustomerFirstName(regressionTestDataArray[6]);
		driver.get()findElement(By.id("customer_last_name")).click();
		driver.get()get().switchTo().activeElement().sendKeys(Keys.TAB);
			String CustomerLastName_BlankErrorMessage_FromExcel = recordset.getField("CustomerLastName_BlankErrorMessage");
			String CustomerLastName_BlankErrorMessage_FromWeb = driver.get()findElement(By.xpath("//*[@id='customer_last_nameContainer']/div")).getText();
			softAssert.assertEquals(CustomerLastName_BlankErrorMessage_FromWeb, CustomerLastName_BlankErrorMessage_FromExcel);
			softAssert.assertAll();
			TextToWrite = "Blank customer last name error message is displayed correctly";
			utilities.Filewriter(TextToWrite);
		
		customerDetails.populateCustomerLastName(regressionTestDataArray[7]);
		dateOfBirth = regressionTestDataArray[8]+"/"+regressionTestDataArray[9]+"/"+regressionTestDataArray[10];
		customerDetails.populatedateOfBirth("");
		driver.get()get().switchTo().activeElement().sendKeys(Keys.TAB);
		
			String CustomerDOBYear_BlankErrorMessage_FromExcel = recordset.getField("CustomerDOBYear_BlankErrorMessage");
			String CustomerDOBYear_BlankErrorMessage_FromWeb = driver.get()findElement(By.xpath("//*[@id='customer_date_of_birthContainer']/div")).getText();
			softAssert.assertEquals(CustomerDOBYear_BlankErrorMessage_FromWeb, CustomerDOBYear_BlankErrorMessage_FromExcel);
			softAssert.assertAll();
			TextToWrite = "Blank customer DOB error message is displayed correctly";
			utilities.Filewriter(TextToWrite);
		
		customerDetails.populatedateOfBirth(dateOfBirth);
		*/
		customerDetails = new CustomerDetailsPage(driver);
		customerDetails.populateCustomerEmail("");
		driver.get().switchTo().activeElement().sendKeys(Keys.TAB);
		
		String Email_BlankErrorMessage_FromExcel = recordset.getField("Email_BlankErrorMessage");
			String Email_BlankErrorMessage_FromWeb = driver.get().findElement(By.xpath("//*[@id='email_addressContainer']/div")).getText();
			softAssert.assertEquals(Email_BlankErrorMessage_FromWeb, Email_BlankErrorMessage_FromExcel);
			softAssert.assertAll();
			TextToWrite = "Blank customer email ID error message is displayed correctly";
			utilities.Filewriter(TextToWrite);
		
		customerDetails.populateCustomerEmail((regressionTestDataArray.get())[14]);
		customerDetails.populateCustomerHouseNumberName("");
		customerDetails.populateCustomerPostcode("");
		//customerDetails.populateCustomerPhoneNumber("");
		customerDetails.clickFindAddressButton();
		
			String HouseNumberName_BlankErrorMessage_FromExcel = recordset.getField("HouseNumberName_BlankErrorMessage");
			String HouseNumberName_BlankErrorMessage_FromWeb = driver.get().findElement(By.xpath("//*[@id='houseNumberNameContainer']/div")).getText();
			softAssert.assertEquals(HouseNumberName_BlankErrorMessage_FromWeb, HouseNumberName_BlankErrorMessage_FromExcel);
			softAssert.assertAll();
			TextToWrite = "Blank house number error message is displayed correctly";
			utilities.Filewriter(TextToWrite);
		
	/*
			String PhoneNumber_BlankErrorMessage_FromExcel = recordset.getField("PhoneNumber_BlankErrorMessage");
			String PhoneNumber_BlankErrorMessage_FromWeb = driver.get()findElement(By.xpath("//div[@id='customer_contact_numberContainer']/div")).getText();
			softAssert.assertEquals(PhoneNumber_BlankErrorMessage_FromWeb, PhoneNumber_BlankErrorMessage_FromExcel);
			softAssert.assertAll();
			TextToWrite = "Blank Phone Number error message is displayed correctly";
			utilities.Filewriter(TextToWrite);
	*/
		customerDetails.clickFloatingToasterPanelClose();
	//	customerDetails.populateCustomerPhoneNumber(regressionTestDataArray[17]);
		customerDetails.populateCustomerHouseNumberName((regressionTestDataArray.get())[11]);
		customerDetails.populateCustomerPostcode((regressionTestDataArray.get())[12]);
		customerDetails.clickFindAddressButton();
		customerDetails.clickFloatingToasterPanelSuccessClose();
	//	TextToWrite = "Customer Details: " + " Title: " + regressionTestDataArray[13] + " First Name: " + regressionTestDataArray[6] + " Last Name: " + 
	//			regressionTestDataArray[7] + " DOB: " + regressionTestDataArray[8] + "." + regressionTestDataArray[9] + "." + regressionTestDataArray[10] + 
	//			" Email: " + regressionTestDataArray[14] + " House Number: " + regressionTestDataArray[11] + " Postcode: " + regressionTestDataArray[12];
		
		TextToWrite = "Customer Details: " +  
				" Email: " + (regressionTestDataArray.get())[14] + " House Number: " + (regressionTestDataArray.get())[11] + " Postcode: " + (regressionTestDataArray.get())[12];
		
		utilities.Filewriter(TextToWrite);
		//customerDetails.clickFloatingToasterPanelSuccessClose();
		//Thread.sleep(3500);
	//Moved to Payment
		/*
		if (regressionTestDataArray[15].equalsIgnoreCase("Today"))
		{
			customerDetails.clickCoverStartDateToday();
		}
		else if (regressionTestDataArray[15].equalsIgnoreCase("Tomorrow"))
		{
			customerDetails.clickCoverStartDateTomorrow();
		}
		else if (regressionTestDataArray[15].equalsIgnoreCase("AnotherDate"))
			//else if (recordset.getField("CoverStartDate").equalsIgnoreCase("AnotherDate"))
			{
				try
				{
					//	Thread.sleep(700);
					customerDetails.clickCoverStartDateAnotherDate();
					if(!driver.get()findElement(By.xpath("//button[@class='react-calendar__navigation__label']")).getText().contains(coverStartDate.substring(0,4)))
					{
						driver.get()findElement(By.xpath("(//div[@class='react-calendar__navigation__arrow-icon'])[2]")).click();
						Thread.sleep(1500);
						String[] parts = coverStartDate.split(",");
						String[] parts1 = parts[0].split(" ");
						builder = new Actions(driver);
						for(int i=0;i<Integer.parseInt(parts1[1]);i++){
								builder.sendKeys(Keys.TAB).perform();
								Thread.sleep(500);
						}
					}
					else{
						System.out.println(CoverStartDate_NumberOfDaysInFuture);
						 builder = new Actions(driver);
						for(int i=0;i<Integer.parseInt(CoverStartDate_NumberOfDaysInFuture)+3;i++){
								builder.sendKeys(Keys.TAB).perform();
								Thread.sleep(500);
						}
						
					}
	
					Thread.sleep(500);
				builder.sendKeys(Keys.ENTER).perform();	
				//utilities.actionClick(driver, coverStartDateElement);
				}
				catch (NoSuchElementException nsee)
				{
					System.out.println("We are in excpetion");
					if (className.equalsIgnoreCase("TEST_2112_QuoteDateOver30daysCurrentDate"))
					{
						softAssert.assertEquals("C", "C");
						utilities.shortFilewriter("Start date greater than 30 days is not allowed");
						softAssert.assertAll();
					}
					else if (className.equalsIgnoreCase("TEST_2161_QuoteDateOver30DaysCurrentDate"))
					{
						softAssert.assertEquals("C", "C");
						utilities.shortFilewriter("Start date greater than 30 days is not allowed");
						softAssert.assertAll();
					}
					else
					{
						try
						{
							customerDetails.clickCoverStartDateToday();
						}
						catch (NoSuchElementException nsee2)
						{
							driver.get()get().switchTo().activeElement().sendKeys(Keys.ESCAPE);
							Thread.sleep(1500);
							customerDetails.clickCoverStartDateTomorrow();
						}
					}
				}
			}
			*/
		//- Moved to Payment
		Thread.sleep(2500);
		if (recordset.getField("PromoCheckerLink").equalsIgnoreCase("Yes"))
		{
			Thread.sleep(800);
			customerDetails.populateCustomerPromotionalCode(recordset.getField("PromotionalCode"));
			TextToWrite = "Promo Code: " + recordset.getField("PromotionalCode");
			utilities.Filewriter(TextToWrite);
		}
	/*	if (recordset.getField("PrivacyPolicyLink").equalsIgnoreCase("Yes"))
		{
			customerDetails.selectPrivacyPolicyLink();
		}
		if (recordset.getField("MarketingOptOutLink").equalsIgnoreCase("Yes"))
		{
			customerDetails.selectMarketingOptOutLink();
		}
		if (recordset.getField("DocumentByPost").equalsIgnoreCase("Yes"))
		{
			customerDetails.clickDocumentByPostTickBox();
			Thread.sleep(2500);
			if (utilities.isElementPresent(By.xpath("//*[@id='floatingToasterPanel']/div/div/div/div"), driver))
			{
				Thread.sleep(1500);
				driver.get()findElement(By.xpath("//*[@id='floatingToasterPanel']/div/div/div/button")).click();
				Thread.sleep(1500);
			}
		}
		*/
		customerDetails.clickGetAQuoteButton();
		Thread.sleep(5000);
		dbConnection.closeConnection();
		return (regressionTestDataArray.get());
	}
}