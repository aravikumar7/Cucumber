
package com.argos.pet.quotebuy.regression.tests;

import org.testng.annotations.Test;

import com.argos.pet.quotebuy.regression.common.code.utilities.TestBase;



public class TC007_QuoteJourney_DogBreed_Test extends TestBase{



	@Test (priority = 0)
	public void initiate_TC007_QuoteJourney_DogBreed_Test() throws Exception
	{
		 int a=1/0;
		 System.out.println(a);
	}
}