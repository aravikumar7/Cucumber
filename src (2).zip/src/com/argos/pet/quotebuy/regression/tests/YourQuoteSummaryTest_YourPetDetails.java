/**
 * 
 */
package com.argos.pet.quotebuy.regression.tests;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import com.argos.pet.quotebuy.regression.common.code.dbconnection.DBConnectionRegressionCommonCode;
import com.argos.pet.quotebuy.regression.common.code.pages.YourQuoteSummaryPage;
import com.argos.pet.quotebuy.regression.common.code.utilities.TestBase;
import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;
import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Recordset;

public class YourQuoteSummaryTest_YourPetDetails extends TestBase{

	YourQuoteSummaryPage yourQuoteSummaryPage;
	PreExistingConditionsTest_YourPetDetails preExistingConditionsTest;
	DBConnectionRegressionCommonCode dbConnection;
	Utilities utilities;
	static String petInjuryIllness;

	public void testYourQuoteSummary() throws FilloException, InterruptedException, IOException
	{
		dbConnection = new DBConnectionRegressionCommonCode();
		yourQuoteSummaryPage = new YourQuoteSummaryPage(driver);
		utilities = new Utilities();
		String  strQuery = "Select * from YourQuoteSummary";
		Recordset recordset = dbConnection.recordset(strQuery);
		recordset.next();
		recordset.moveFirst();
		String GreetingText = yourQuoteSummaryPage.getGreetingText();
		System.out.println(GreetingText);
		String QuoteReferenceNumberStartDate = yourQuoteSummaryPage.getQuoteReferenceNumberStartDate();
		System.out.println(QuoteReferenceNumberStartDate);
		String QuoteValidityDate = yourQuoteSummaryPage.getQuoteValidityDate();
		System.out.println(QuoteValidityDate);
		String PetName = yourQuoteSummaryPage.getPetName();
		System.out.println(PetName);
		String MonthlyPrice = yourQuoteSummaryPage.getMonthlyPrice();
		System.out.println(MonthlyPrice);
		String YearlyPrice = yourQuoteSummaryPage.getYearlyPrice();
		System.out.println(YearlyPrice);
		String CoverDetails = yourQuoteSummaryPage.getCoverDetails();
		System.out.println(CoverDetails);
		String ExcessDetails = yourQuoteSummaryPage.getExcessDetails();
		System.out.println(ExcessDetails);
		String VetDetails = yourQuoteSummaryPage.getVetFees();
		System.out.println(VetDetails);
		String PetDetails = yourQuoteSummaryPage.getPetDetails();
		System.out.println(PetDetails);
		String PetType = yourQuoteSummaryPage.getPetType();
		System.out.println(PetType);
		String PetDOB = yourQuoteSummaryPage.getPetDOB();
		System.out.println(PetDOB);
		String PetSex = yourQuoteSummaryPage.getPetSex();
		System.out.println(PetSex);
		String PetBreed = yourQuoteSummaryPage.getPetBreed();
		System.out.println(PetBreed);
		//tc008_PopulateMoreAboutYourPet = new TC008_PopulateMoreAboutYourPet();
		petInjuryIllness = MoreAboutYourPetTest_YourPetDetails.petInjuryIllness;
		if (petInjuryIllness.equalsIgnoreCase("Yes"))
		{
			yourQuoteSummaryPage.clickPetPreExistingConditionsAddDetailsLink();
			preExistingConditionsTest = new PreExistingConditionsTest_YourPetDetails();
			preExistingConditionsTest.testPreExistingConditions();
			Thread.sleep(2500);
			utilities.waitElement(driver.get().findElement(By.xpath("//*[@id='contentContainer']/div[1]/div/div/h1")), driver);
			Thread.sleep(2500);
		}
		String CustomerFullName = yourQuoteSummaryPage.getCustomerFullName();
		System.out.println(CustomerFullName);
		String CustomerEmailID = yourQuoteSummaryPage.getCustomerEmailID();
		System.out.println(CustomerEmailID);
		String CustomerDOB = yourQuoteSummaryPage.getCustomerDOB();
		System.out.println(CustomerDOB);
		String CustomerPhoneNumber = yourQuoteSummaryPage.getCustomerPhoneNumber();
		System.out.println(CustomerPhoneNumber);
		String CustomerAddress = yourQuoteSummaryPage.getCustomerAddress();
		System.out.println(CustomerAddress);
		yourQuoteSummaryPage.populateCustomerPhoneNumberTextField(recordset.getField("CustomerPhoneNumber"));
		driver.get().switchTo().activeElement().sendKeys(Keys.TAB);
		//yourQuoteSummaryPage.clickAddPhoneNumberButton();
		Thread.sleep(2500);
		if (utilities.isElementPresent(By.xpath("//*[@id='floatingToasterPanel']/div/div/div/div"), driver))
		{
			Thread.sleep(2500);
			driver.get().findElement(By.xpath("//*[@id='floatingToasterPanel']/div/div/div/button")).click();
			Thread.sleep(2500);
		}
		String PetNameAtPriceBreakdown = yourQuoteSummaryPage.getPetNameAtPriceBreakdown();
		System.out.println(PetNameAtPriceBreakdown);
		String CoverType = yourQuoteSummaryPage.getCoverTypeAtPriceBreakdown();
		System.out.println(CoverType);
		String MonthlyPriceAtPriceBreakdown = yourQuoteSummaryPage.getMonthlyPriceAtPriceBreakdown();
		System.out.println(MonthlyPriceAtPriceBreakdown);
		yourQuoteSummaryPage.clickGoToPaymentPageButton();
		dbConnection.closeConnection();

	}
}
