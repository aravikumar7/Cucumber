/**
 * 
 */
package com.argos.pet.quotebuy.regression.tests;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.argos.pet.quotebuy.regression.common.code.dbconnection.DBConnection;
import com.argos.pet.quotebuy.regression.common.code.pages.YourPetDetailsPage;
import com.argos.pet.quotebuy.regression.common.code.utilities.TestBase;
import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;
import com.codoid.products.fillo.Recordset;


/**
 * @author d23747
 *
 */

public class TEST_165_ValidateAgeValidationForNonSelectedBreedDogs_2_Test extends TestBase {

	DBConnection dbConnection;
	Utilities utilities;
	YourPetDetailsPage yourPetDetailsPage;
	TestBase testBase;
	SoftAssert softAssert;
	String[] dobArray;

	@Test (priority = 0)
	public void initiate_TEST_165_ValidateAgeValidationForNonSelectedBreedDogs_2() throws Exception
	{
		String  strQuery = "Select * from PetQuote Where TestClassName = '" + this.getClass().getSimpleName() + "'";
		dbConnection = new DBConnection();
		Recordset recordset = dbConnection.recordset(strQuery);
		recordset.next();
		recordset.moveFirst();
		strQuery = recordset.getField("DOB_FromCoverStartDate");

		{
			try
			{
				testBase = new TestBase();
				softAssert = new SoftAssert();
				utilities = new Utilities();
				yourPetDetailsPage = new YourPetDetailsPage(driver);
				yourPetDetailsPage.setPetName(recordset.getField("PetFullName"));
				yourPetDetailsPage.setPetTypeDog();
			//	utilities.waitElement(driver.get().findElement(By.xpath("//*[@id='breedDogType_1']")), driver);
				yourPetDetailsPage.selectDogBreed();
				yourPetDetailsPage.whatBreedQuestionTextField();
				yourPetDetailsPage.populateBreedType(recordset.getField("DogBreedType"));
				yourPetDetailsPage.selectFromList();
				dobArray = utilities.getDOB(strQuery);
				yourPetDetailsPage.populateDobDay(dobArray[0]);
				yourPetDetailsPage.populateDobMonth(dobArray[1]);
				yourPetDetailsPage.populateDobYear(dobArray[2]);
				System.out.println(dobArray[0]+dobArray[1]+dobArray[2]);
				driver.get().switchTo().activeElement().sendKeys(Keys.TAB);
				//softAssert.assertFalse(utilities.isElementPresent(By.xpath("//*[@id='removePetCopy_1']/text()"), driver));
				softAssert.assertFalse(utilities.isElementPresent(By.xpath("//input[@id='pet1.pet_date_of_birth']/following-sibling::div"), driver));
				softAssert.assertAll();
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
		}
		dbConnection.closeConnection();
	}
}
