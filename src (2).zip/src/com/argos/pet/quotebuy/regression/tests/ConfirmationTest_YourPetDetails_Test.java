/**
 * 
 */
package com.argos.pet.quotebuy.regression.tests;

import com.argos.pet.quotebuy.regression.common.code.pages.ConfirmationPage;
import com.argos.pet.quotebuy.regression.common.code.utilities.TestBase;
import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;


/**
 * @author d23747
 *
 */
public class ConfirmationTest_YourPetDetails_Test extends TestBase {

	ConfirmationPage confirmationPage;
	Utilities utilities;
	
	public void initiateConfirmationTest() throws Exception
	{
		confirmationPage = new ConfirmationPage(driver);
		utilities = new Utilities();
		String testName = this.getClass().getSimpleName();
		String coverType = confirmationPage.getCoverType();
		String policyNumber = confirmationPage.getPolicyNumber();
		String monthlyCost = confirmationPage.getMonthlyCost();
		String policyStartDate = confirmationPage.getPolicyStartDate();
		String TextToWrite = "Test: " + testName + " CoverType: " + coverType + "PolicyNumber: " + policyNumber + "MonthlyCost: " + monthlyCost + "PolicyStartDate: " + policyStartDate;
		utilities.Filewriter(TextToWrite);
	}
}
