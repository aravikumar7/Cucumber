/**
 * 
 */
package com.argos.pet.quotebuy.regression.tests;

import org.openqa.selenium.By;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.argos.pet.quotebuy.regression.common.code.dbconnection.DBConnection;
import com.argos.pet.quotebuy.regression.common.code.pages.YourPetDetailsPage;
import com.argos.pet.quotebuy.regression.common.code.utilities.TestBase;
import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;
import com.codoid.products.fillo.Recordset;


/**
 * @author d23747
 *
 */

public class TEST_145_ValidateSizeOfMongrelIsMandatory_Test extends TestBase {

	DBConnection dbConnection;
	Utilities utilities;
	YourPetDetailsPage yourPetDetailsPage;
	TestBase testBase;
	SoftAssert softAssert;

	@Test (priority = 2)
	public void initiate_TEST_145_ValidateSizeOfMongrelIsMandatory() throws Exception
	{
		String  strQuery = "Select * from PetQuote Where TestClassName = '" + this.getClass().getSimpleName() + "'";
		dbConnection = new DBConnection();
		Recordset recordset = dbConnection.recordset(strQuery);
		recordset.next();
		recordset.moveFirst();
		{
			try
			{
				testBase = new TestBase();
				softAssert = new SoftAssert();
				utilities = new Utilities();
				yourPetDetailsPage = new YourPetDetailsPage(driver);
				yourPetDetailsPage.setPetName(recordset.getField("PetFullName"));
				yourPetDetailsPage.setPetTypeDog();
				yourPetDetailsPage.selectDogMongrel();
		//		utilities.actionWaitClick(driver, driver.get().findElement(By.xpath("//*[@id='mongrel148164']")));
				yourPetDetailsPage.selectFemalePet();
				yourPetDetailsPage.clickNextButton();
		//		String errorText = driver.get().findElement(By.xpath("//div[@class='errors-inner']/ul/li[2]/button")).getText();
				String errorText_0 = driver.get().findElement(By.xpath("//div[@class='pet-details-form-dog']/div/div/div/div/div")).getText();
		//		softAssert.assertTrue(errorText.contains(recordset.getField("ErrorMessageAtTheTop")));
				softAssert.assertEquals(errorText_0, recordset.getField("ErrorMessageAtTheField"));
				Thread.sleep(700);
				softAssert.assertAll();
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
		}
		dbConnection.closeConnection();
	}
}
