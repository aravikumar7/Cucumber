/**
 * 
 */
package com.argos.pet.quotebuy.regression.common.code.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;

import org.openqa.selenium.JavascriptExecutor;

public class EditPetDetailsPage {

	public static ThreadLocal<WebDriver> ldriver;
	Utilities utilities;

	public EditPetDetailsPage (ThreadLocal<WebDriver> driver)
	{
		ldriver = driver;
		PageFactory.initElements(driver.get(), this);
	}

	@FindBy (how = How.XPATH, using = "(//div[text()='Edit pet details'])[1]") WebElement editPetDetailsLink;
	@FindBy (how = How.ID, using = "pet1.pet_name") WebElement petName;
	@FindBy (how = How.ID, using = "radio_dog_pet1") WebElement petTypeDog;
	@FindBy (how = How.ID, using = "radio_cat_pet1") WebElement petTypeCat;
	@FindBy (how = How.ID, using = "radio_rabbit_pet1") WebElement petTypeRabbit;
	@FindBy (how = How.XPATH, using = "//*[@id='pet1.pet_nameContainer']/div") WebElement petNameErrorMessage;
	@FindBy (how = How.XPATH, using = "//*[@id='petDetailsForm_1']/div[1]/div[1]/div/fieldset/label") WebElement petNameDogMessage;
	@FindBy (how = How.XPATH, using = "//*[@id='petDetailsForm_1']/div[1]/div[1]/div/fieldset/label") WebElement petNameCatMessage;
	@FindBy (how = How.XPATH, using = "//*[@id=\'petDetailsForm_1\']/div[1]/div[1]/div/fieldset/div/p") WebElement petNameErrorLongMessage;
	@FindBy (how = How.XPATH, using = "//label[@for='breed_pet1']") WebElement dogBreed;
	@FindBy (how = How.XPATH, using = "//label[@for='crossbreed_pet1']") WebElement dogCrossBreed;
	@FindBy (how = How.XPATH, using = "//label[@for='mongrel_pet1']") WebElement dogMongrel;
	@FindBy (how = How.XPATH, using = "//label[@for='mongrel-smallpet1']") WebElement smallMongrel;
	@FindBy (how = How.XPATH, using = "//label[@for='mongrel-mediumpet1']") WebElement mediumMongrel;
	@FindBy (how = How.XPATH, using = "//label[@for='mongrel-largepet1']") WebElement largeMongrel;
	@FindBy (how = How.ID, using = "moggie_pet1") WebElement moggie;
	@FindBy (how = How.ID, using = "domestic-shorthair_pet1") WebElement domesticShortHair;
	@FindBy (how = How.ID, using = "british-shorthair_pet1") WebElement britishShortHair;
	@FindBy (how = How.ID, using = "cat-crossbreed_pet1") WebElement crossBreed;
	@FindBy (how = How.ID, using = "cat-other_pet1") WebElement catOthers;

	@FindBy (how = How.XPATH, using = "//*[@id='pet1.pet_breed']/div/div[1]/div[1]") WebElement whatBreedQuestion;
	@FindBy (how = How.XPATH, using = "//*[@id='pet1.pet_breed']/div/div[1]/div[1]") WebElement whatBreedQuestionText;
	@FindBy (how = How.XPATH, using = "//*[@id='pet1.dateDayName']") WebElement dobDay;
	@FindBy (how = How.XPATH, using = "//*[@id='pet1.dateMonthName']") WebElement dobMonth;
	@FindBy (how = How.XPATH, using = "//*[@id='pet1.dateYearName']") WebElement dobYear;
	@FindBy (how = How.ID, using = "pet1.pet_date_of_birth") WebElement dob;
	@FindBy (how = How.XPATH, using = "//label[contains(@for,'male_radio_1pet1')]") WebElement malePet;
	@FindBy (how = How.XPATH, using = "//label[contains(@for,'female_radio_1pet1')]") WebElement femalePet;
	@FindBy (how = How.XPATH, using = "//div[text()='Next']//parent::button") WebElement nextButton;

	@FindBy (how = How.ID, using = "pet1.pet_cost") WebElement petCost;
	@FindBy (how = How.XPATH, using = "//*[@id='zeroPetCost_1']") WebElement iDidntPayAnything;
	@FindBy (how = How.XPATH, using = "//label[contains(@for,'neutered_yes_pet1')]") WebElement petNeuteredYes;
	@FindBy (how = How.XPATH, using = "//label[contains(@for,'neutered_no_pet1')]") WebElement petNeuteredNo;
	@FindBy (how = How.XPATH, using = "//label[contains(@for,'health_yes_pet1')]") WebElement petAnyInjuryIllnessYes;
	@FindBy (how = How.XPATH, using = "//label[contains(@for,'health_no_pet1')]") WebElement petAnyInjuryIllnessNo;
	@FindBy (how = How.XPATH, using = "//*[@id='petQuestionsOuterContainer_1']/div[3]/div") WebElement petAnyInjuryIllnessNoTextMessage;
	@FindBy (how = How.XPATH, using = "//img[contains(@src,'pencil')]") WebElement changeAssumptionTopLink;
	@FindBy (how = How.XPATH, using = "//img[contains(@src,'pencil')]") WebElement changeAssumptionBottomLink;
	@FindBy (how = How.ID, using = "pet1.confirm_assumptions") WebElement assumptionCorrectTickBox;
	@FindBy (how = How.XPATH, using = "//button[text()='Save and close']") WebElement saveCloseButton;
	@FindBy (how = How.XPATH, using = "//button[text()='Cancel']") WebElement cancelButton;

	public void clickEditPetDetailsLink()
	{
		//editPetDetailsLink.click();
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", editPetDetailsLink);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", editPetDetailsLink);
	}
	
	public void setPetName(String fullPetName)
	{
		
		petName.sendKeys(Keys.chord(Keys.CONTROL, "a"));
		petName.sendKeys(Keys.BACK_SPACE);
		petName.sendKeys(fullPetName);
	}

	public void setPetTypeDog()
	{
		//petTypeDog.click();
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", petTypeDog);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", petTypeDog);
	}

	public void setPetTypeCat()
	{
	//	petTypeCat.click();
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", petTypeCat);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", petTypeCat);
	}

	public void selectDogBreed()
	{
	//	dogBreed.click();
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", dogBreed);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", dogBreed);
	}

	public void selectDogCrossBreed()
	{
		//dogCrossBreed.click();
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", dogCrossBreed);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", dogCrossBreed);
	}

	public void selectDogMongrel()
	{
		//dogMongrel.click();
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", dogMongrel);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", dogMongrel);
	}

	public void selectSmallMongrel()
	{
		//smallMongrel.click();
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", smallMongrel);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", smallMongrel);
	}

	public void selectMediumMongrel()
	{
		//mediumMongrel.click();
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", mediumMongrel);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", mediumMongrel);
	}

	public void selectLargeMongrel()
	{
		//largeMongrel.click();
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", largeMongrel);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", largeMongrel);
	}

	public void whatBreedQuestionTextField()
	{
		//whatBreedQuestion.click();
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", whatBreedQuestion);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", whatBreedQuestion);
	}

	public void populateBreedType(String dogBreed) throws InterruptedException
	{
		Actions builder = new Actions(ldriver.get());
	/*	((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", ldriver.findElement(By.xpath("//input[contains(@id,'react-select')]")));
		ldriver.findElement(By.xpath("//input[contains(@id,'react-select')]")).sendKeys(Keys.chord(Keys.CONTROL, "a"));
		ldriver.findElement(By.xpath("//input[contains(@id,'react-select')]")).sendKeys(Keys.BACK_SPACE);	
		ldriver.findElement(By.xpath("//input[contains(@id,'react-select')]")).sendKeys(dogBreed);
			//	builder.sendKeys(Keys.ARROW_DOWN).build().perform();
				Thread.sleep(5000);
				builder.sendKeys(Keys.ENTER).perform();
				*/
											
		WebElement breed=ldriver.get().findElement(By.id("pet1.pet_breed"));
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", breed);
		breed.click();
		Thread.sleep(1000);
		WebElement petbreed=ldriver.get().findElement(By.xpath("//div[contains(@class,'react-select__menu-list')]")).findElement(By.xpath(String.format(".//div[text()='%s']", dogBreed)));
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", petbreed);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", petbreed);	
	
	}

	public void selectFromList()
	{
		Actions builder = new Actions(ldriver.get());
		builder.sendKeys(Keys.ENTER).perform();
	}

	public void populateDobDay(String dob_day) throws InterruptedException
	{
		dobDay.clear();
		dobDay.sendKeys(dob_day);
		
	/*	((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", dobDay);
	Thread.sleep(700);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].focus(); arguments[0].blur(); return true", dobDay);
		((JavascriptExecutor) ldriver.get()).executeScript("let input = arguments[0];var setValue = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;setValue.call(input, '" + dob_day + "');var e = new Event('input', { bubbles: true });input.dispatchEvent(e);", dobDay);
		((JavascriptExecutor) ldriver.get()).executeScript("document.getElementById('daySelectDob_1').blur()");
		Thread.sleep(1500);
		*/
	}

	public void populateDobMonth(String dob_month) throws InterruptedException
	{
		dobDay.clear();
		dobMonth.sendKeys(dob_month);
	//	dobYear.sendKeys(Keys.TAB);
		/*((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", dobMonth);
		Thread.sleep(700);
			((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].focus(); arguments[0].blur(); return true", dobMonth);
			((JavascriptExecutor) ldriver.get()).executeScript("let input = arguments[0];var setValue = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;setValue.call(input, '" + dob_month + "');var e = new Event('input', { bubbles: true });input.dispatchEvent(e);", dobMonth);
			((JavascriptExecutor) ldriver.get()).executeScript("document.getElementById('pet1.pet_date_of_birth').blur()");
			Thread.sleep(1500);*/
	}

	public void populateDobYear (String dob_year) throws InterruptedException
	{
		dobYear.clear();
		dobYear.sendKeys(dob_year);
		Thread.sleep(500);
		dobYear.sendKeys(Keys.TAB);
		
		/*Thread.sleep(700);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].focus(); arguments[0].blur(); return true", dobYear);
		((JavascriptExecutor) ldriver.get()).executeScript("let input = arguments[0];var setValue = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;setValue.call(input, '" + dob_year + "');var e = new Event('input', { bubbles: true });input.dispatchEvent(e);", dobYear);
		((JavascriptExecutor) ldriver.get()).executeScript("document.getElementById('pet1.pet_date_of_birth').blur()");
		Thread.sleep(1500);*/
	}

	public void selectMalePet()
	{
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", malePet);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", malePet);
	}

	public void selectFemalePet()
	{
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", femalePet);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", femalePet);
	}
	
	public void populatePetCost(String PetCost)
	{
	//	petCost.sendKeys(Keys.chord(Keys.CONTROL, "a"));
	//	petCost.click();
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", petCost);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", petCost);
		petCost.sendKeys(Keys.BACK_SPACE);
		petCost.sendKeys(Keys.BACK_SPACE);
		petCost.sendKeys(Keys.BACK_SPACE);
		petCost.sendKeys(Keys.BACK_SPACE);
		petCost.sendKeys(PetCost);
	
	}
	
	public void selectNeuteredYes()
	{
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", petNeuteredYes);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", petNeuteredYes);
	}
	
	public void selectNeuteredNo()
	{
		//petNeuteredNo.click();
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", petNeuteredNo);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", petNeuteredNo);

	}
	
	public void selectInjuryIllnessYes()
	{
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", petAnyInjuryIllnessYes);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", petAnyInjuryIllnessYes);
	}
	public void selectInjuryIllnessNo()
	{
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", petAnyInjuryIllnessNo);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", petAnyInjuryIllnessNo);
	}
	
	public void clickSaveCloseButton()
	{
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", saveCloseButton);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", saveCloseButton);
	}
	
	public void clickCancelButton()
	{
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", cancelButton);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", cancelButton);
	}
	public void populatedateOfBirth(String dateOfBirth) throws InterruptedException {
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", dob);
		Thread.sleep(700);
		dob.sendKeys(Keys.chord(Keys.CONTROL, "a"));
		dob.sendKeys(Keys.BACK_SPACE);
		dob.sendKeys(dateOfBirth);
		Thread.sleep(1500);
		dob.sendKeys(Keys.ENTER);
		Thread.sleep(1500);
		dob.sendKeys(Keys.TAB);
		Thread.sleep(1500);
	}

	public void setPetTypeRabbit() {
		petTypeRabbit.click();	
	}
}