/**
 * 
 */
package com.argos.pet.quotebuy.regression.common.code.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * @author d23747
 *
 */
public class YourCoverPage {

	public static ThreadLocal<WebDriver> ldriver;

	public YourCoverPage (ThreadLocal<WebDriver> driver)
	{
		ldriver = driver;
		PageFactory.initElements(driver.get(), this);
	}
	
	@FindBy (how = How.XPATH, using = "(//div[@class='copy'])[1]") WebElement quoteReferenceNumberText;
	@FindBy (how = How.XPATH, using = "(//div[@class='copy'])[2]") WebElement quoteValidityDate;
	@FindBy (how = How.XPATH, using = "//*[@id='chooseProductLevel_1']/div/div[1]/div[2]") WebElement quoteTimeLimitedMonthlyCost;
	@FindBy (how = How.XPATH, using = "//*[@id='chooseProductLevel_1']/div/div[1]/div[3]/div[1]") WebElement quoteTimeLimitedYearlyCost;
	@FindBy (how = How.XPATH, using = "//label[@for='TL']") WebElement chooseTimeLimitedButton;
	
	@FindBy (how = How.XPATH, using = "//*[@id='radio_cover_level_2500_1']") WebElement radio�2500Button;
	@FindBy (how = How.XPATH, using = "//*[@id='radio_cover_level_4000_1']") WebElement radio�4000Button;
	@FindBy (how = How.XPATH, using = "//button[@class='cover-level__incrementer-button plus']") WebElement radioValueButtonplus;
	@FindBy (how = How.XPATH, using = "//button[@class='cover-level__incrementer-button minus']") WebElement radioValueButtonminus;
	@FindBy (how = How.XPATH, using = "//*[@id='chooseProductLevel_1']/div/div[2]/div[2]") WebElement quoteLifetimeMonthlyCost;
	@FindBy (how = How.XPATH, using = "//*[@id='chooseProductLevel_1']/div/div[2]/div[3]/div[1]") WebElement quoteLifetimeYearlyCost;
	@FindBy (how = How.XPATH, using = "//label[@for='LT']") WebElement chooseLifetimeButton;
	@FindBy (how = How.XPATH, using = "//*[@id='radio_cover_level_1000_1']") WebElement radio�1000Button;
	@FindBy (how = How.XPATH, using = "//*[@id='radio_cover_level_4500_1']") WebElement radio�4500Button;
	@FindBy (how = How.XPATH, using = "//*[@id='radio_cover_level_7000_1']") WebElement radio�7000Button;
	@FindBy (how = How.XPATH, using = "//*[@id='radio_cover_level_1000_1']") WebElement radio�1000CatButton;
	@FindBy (how = How.XPATH, using = "//*[@id='radio_cover_level_3500_1']") WebElement radio�3500CatButton;
	@FindBy (how = How.XPATH, using = "//*[@id='radio_cover_level_7000_1']") WebElement radio�7000CatButton;
	
	@FindBy (how = How.XPATH, using = "//label[@for='MB']") WebElement chooseMaxBenefitButton;
	@FindBy (how = How.XPATH, using = "//*[@id='radio_cover_level_2000_1']") WebElement radioMax�2000Button;
	@FindBy (how = How.XPATH, using = "//*[@id='radio_cover_level_5000_1']") WebElement radioMax�5000Button;
	
	@FindBy (how = How.XPATH, using = "(//div[@class='header'])[2]/h2") WebElement priceBreakdownHeading;
	@FindBy (how = How.XPATH, using = "(//div[contains(@class,'pet-name')])[1]") WebElement petName;
	@FindBy (how = How.XPATH, using = "(//div[@class='product-details']/h2)[1]") WebElement coverType;
	@FindBy (how = How.XPATH, using = "(//div[@class='summary-row d-flex justify-content-between'])[1]/div[2]/div[1]") WebElement totalMonthlyCost;
	@FindBy (how = How.XPATH, using = "(//div[@class='summary-row d-flex justify-content-between'])[1]/div[2]/div[1]") WebElement totalYearlyCost;
	@FindBy (how = How.XPATH, using = "//*[@id='priceBreakdown']/div/table/tbody/tr[3]/td[1]") WebElement promotionalCodeText;
	//@FindBy (how = How.XPATH, using = "//button[text()='Continue' and @type='submit']") WebElement reviewButton;
	@FindBy (how = How.XPATH, using = "//button[text()='Go to review']") WebElement reviewButton;
	//@FindBy (how = How.XPATH, using = "//button[@class='btn btn-primary cover-select-cta']") WebElement saveCloseButton;
	@FindBy (how = How.XPATH, using = "//button[text()='Save and Close']") WebElement saveCloseButton;
	@FindBy (how = How.XPATH, using = "//*[@id='chooser_container_1']/button[2]") WebElement cancelButton;
	@FindBy (how = How.XPATH, using = "//button[contains(text(),'Next')]") WebElement nextButton;
	@FindBy (how = How.XPATH, using = "//a[text()='Cover type']") WebElement clickcovertype;
	@FindBy (how = How.XPATH, using = "(//div[@class='price__details']/div)[1]") WebElement monthlyPriceAtPriceBreakdown;
	@FindBy (how = How.XPATH, using = "(//div[@class='price__details']/div)[1]") WebElement yearlyPriceAtPriceBreakdown;
	@FindBy (how = How.XPATH, using = "//*[@id='cpModalBody']/table/tbody/tr[1]/td[1]/div") WebElement monthlyPrice;
	@FindBy (how = How.XPATH, using = "//div[@class='benefits-table']/div/div[contains(text(),'Excess')]") WebElement excess;
	@FindBy (how = How.XPATH, using = "//div[@class='benefits-table']/div/div[contains(text(),'Vet fees')]") WebElement vetFeeLimit;
	@FindBy (how = How.XPATH, using = "//div[@class='benefits-table']/div/div[contains(text(),'Death from illness')]") WebElement deathFromIllness;
	@FindBy (how = How.XPATH, using = "//div[@class='benefits-table']/div/div[contains(text(),'Death from accident')]") WebElement deathFromAccident;
	@FindBy (how = How.XPATH, using = "//div[@class='benefits-table']/div/div[contains(text(),'Finding your pet')]") WebElement findingYourPet;
	@FindBy (how = How.XPATH, using = "//div[@class='benefits-table']/div/div[contains(text(),'Loss by theft or straying')]") WebElement lossByTheftOrStraying;
	@FindBy (how = How.XPATH, using = "//div[@class='benefits-table']/div/div[contains(text(),'Third Party Liability')]") WebElement thirdPartyLiability;
	@FindBy (how = How.XPATH, using = "//div[@class='benefits-table']/div/div[contains(text(),'Hospitalisation/boarding fees')]") WebElement hospitalisationFees;
	@FindBy (how = How.XPATH, using = "//div[@class='benefits-table']/div/div[contains(text(),'Holiday cancellation')]") WebElement holidayCancellation;
	@FindBy (how = How.ID, using = "//button[text()='View all policy features']") WebElement compareBenefitsButton;
	@FindBy (how = How.XPATH, using = "//*[@id='cpModalBody']/button") WebElement closeCompareButton;
	@FindBy (how = How.XPATH, using = "//button[@class='Toastify__close-button']") WebElement closeToaster;

	
	public String getQuoteReferenceNumberText()
	{
		return quoteReferenceNumberText.getText();
	}
	
	public String getQuoteValidityDate()
	{
		return quoteValidityDate.getText();
	}
	
	public String getQuoteTimeLimitedMonthlyCost()
	{
		return quoteTimeLimitedMonthlyCost.getText();
	}
	
	public String getQuoteTimeLimitedYearlyCost()
	{
		return quoteTimeLimitedYearlyCost.getText();
	}
	
	public void clickChooseTimeLimitedButton()
	{
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", chooseTimeLimitedButton);
	}
	
	public void clickRadio�2500Button()
	{
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", radio�2500Button);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", radio�2500Button);
	//	radio�2500Button.click();
	}
	
	public void clickRadio�4000Button()
	{
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", radio�4000Button);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", radio�4000Button);
	//	radio�4000Button.click();
	}
	
	public String getQuoteLifetimeMonthlyCost()
	{
		return quoteLifetimeMonthlyCost.getText();
	}
	

	
	public String getQuoteLifetimeYearlyCost()
	{
		return quoteLifetimeYearlyCost.getText();
	}
	
	public void clickChooseLifetimeButton()
	{
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", chooseLifetimeButton);
	}
	
	public void clickRadio�1000Button()
	{
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", radio�1000Button);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", radio�1000Button);
		//radio�2000Button.click();
	}
	
	public void clickRadio�4500Button()
	{
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", radio�4500Button);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", radio�4500Button);
	//	radio�4500Button.click();
	}
	
	public void clickRadio�7000Button()
	{
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", radio�7000Button);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", radio�7000Button);
		//radio�7000Button.click();
	}
	
	public void clickRadio�1000CatButton()
	{
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", radio�1000CatButton);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", radio�1000CatButton);
		//radio�1000CatButton.click();
	}
	
	public void clickRadio�3500CatButton()
	{
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", radio�3500CatButton);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", radio�3500CatButton);
	//	radio�3500CatButton.click();
	}
	
	public void clickRadio�7000CatButton()
	{
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", radio�7000CatButton);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", radio�7000CatButton);
	//	radio�7000CatButton.click();
	}
	
	public void clickChooseMaxBenefitButton()
	{
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", chooseMaxBenefitButton);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", chooseMaxBenefitButton);
	}
	
	public void clickRadioMax�2000Button()
	{
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", radioMax�2000Button);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", radioMax�2000Button);
	//	radioMax�2000Button.click();
	}
	public void clickRadioMax�5000Button()
	{
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", radioMax�5000Button);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", radioMax�5000Button);
	//	radioMax�5000Button.click();
	}
	
	public String getPriceBreakdownHeading()
	{
		String PriceBreakdownHeading = priceBreakdownHeading.getText();
		return PriceBreakdownHeading;
	}
	
	public String getPetName()
	{
		return petName.getText();
	}
	
	public String getCoverType()
	{
		return coverType.getText();
	}
	
	public String getTotalMonthlyCost()
	{
//	String monthlyToggle=ldriver.findElement(By.xpath("//button[@role='switch']/span[text()='Monthly']")).getAttribute("class");
		String monthlyToggle=ldriver.get().findElement(By.xpath("//button[@role='switch']")).getAttribute("aria-pressed");
		//	if(monthlyToggle=="false") {
			if(monthlyToggle=="true") {
				ldriver.get().findElement(By.xpath("//button[@role='switch']")).click();
		}
			String MonthlyPriceAtPriceBreakdown = monthlyPriceAtPriceBreakdown.getText();
			//return MonthlyPriceAtPriceBreakdownArray[0];
			return MonthlyPriceAtPriceBreakdown;
}
			
	public String getTotalYearlyCost()
	{
//		String yearlyToggle=ldriver.findElement(By.xpath("//button[@role='switch']/span[text()='Yearly']")).getAttribute("class");
			String yearlyToggle=ldriver.get().findElement(By.xpath("//button[@role='switch']")).getAttribute("aria-pressed");
			//if(yearlyToggle=="false") {
			if(yearlyToggle=="false") {	
				ldriver.get().findElement(By.xpath("//button[@role='switch']")).click();
		}
			String YearlyPriceAtPriceBreakdown = yearlyPriceAtPriceBreakdown.getText();
			//return MonthlyPriceAtPriceBreakdownArray[0];
			return YearlyPriceAtPriceBreakdown;
	}
	
	public String getPromotionalCodeText()
	{
		String promotionalCodeTextMessage = promotionalCodeText.getText();
		return promotionalCodeTextMessage;
	}
	
	public void clickCloseToasterButton()
	{
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", closeToaster);
	}
	public void clickReviewButton()
	{
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", reviewButton);
	//	reviewButton.click();
	}
	
	public void clickSaveCloseButton()
	{
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", saveCloseButton);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", saveCloseButton);
		//saveCloseButton.click();
	}
	
	public void clickCancelButton()
	{
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", cancelButton);
		//cancelButton.click();
	}

	
	public void clickChooseTimeLimitedValueButton(Double TimeLimitedValue) throws InterruptedException {
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", radioValueButtonminus);
		while(radioValueButtonminus.isEnabled()){
			((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", radioValueButtonminus);
		}
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", radioValueButtonplus);
			int loop=(int) Math.ceil((TimeLimitedValue/1700.0));
		System.out.println("TL 1"+TimeLimitedValue+":"+loop);
		for(int i=1;i<loop;i++){
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", radioValueButtonplus);
		Thread.sleep(700);
		}
	}
		public void clickChooseLifeTimeValueButton(Double LifeTimeValue) throws InterruptedException {
			((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", radioValueButtonminus);
			while(radioValueButtonminus.isEnabled()){
				((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", radioValueButtonminus);	
			}
			((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", radioValueButtonplus);
			int loop=(int) Math.ceil((LifeTimeValue/1700.0));
			System.out.println("LT 1"+LifeTimeValue+":"+loop);
			for(int i=1;i<loop;i++){
			((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", radioValueButtonplus);
			Thread.sleep(700);
			}
	}
		public void clickChooseMaximumBenefitValueButton(Double MaximumBenefitValue) throws InterruptedException {
			((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", radioValueButtonminus);
			while(radioValueButtonminus.isEnabled()){
				((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", radioValueButtonminus);
				}
			((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", radioValueButtonplus);
			int loop=(int) Math.round((MaximumBenefitValue/1500));
			System.out.println("MB 1"+MaximumBenefitValue+":"+loop);
			for(int i=1;i<loop;i++){
			((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", radioValueButtonplus);
			Thread.sleep(700);
			}
	}

		public void clickNextButton() {
			((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", nextButton);
			((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", nextButton);	
		}

		public void clickCoverType() {
		//	((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", clickcovertype);
		//	((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", clickcovertype);		
		}
		public void closeCompareBenefits()
		{
			((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", closeCompareButton);
			closeCompareButton.click();
		}
		
		public void clickCompareBenefits(){
			compareBenefitsButton.click();
		}
		public String checkMonthlyPrice() {
	//		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", monthlyPrice);
			return monthlyPrice.getText();
		}
		public String checkExcess() {
	//		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", excess);
			return excess.getText();
		}
		public String checkVetFeeLimit() {
	//		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", vetFeeLimit);
			return vetFeeLimit.getText();
		}
		public String checkDeathFromIllness() {
	//		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", deathFromIllness);
			return deathFromIllness.getText();
		}
		public String checkDeathFromAccident() {
	//		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", deathFromAccident);
			return deathFromAccident.getText();
		}
		public String checkFindingYourPet() {
	//		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", findingYourPet);
			return findingYourPet.getText();
		}
		public String checkLossByTheftOrStraying() {
	//		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", lossByTheftOrStraying);
			return lossByTheftOrStraying.getText();
		}
		public String checkThirdPartyLiability() {
	//		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", thirdPartyLiability);
			return thirdPartyLiability.getText();
		}
		public String checkHospitalisationFees() {
	//		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", hospitalisationFees);
			return hospitalisationFees.getText();
		}
		public String checkHolidayCancellation() {
	//		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", holidayCancellation);
			return holidayCancellation.getText();
		}
}
