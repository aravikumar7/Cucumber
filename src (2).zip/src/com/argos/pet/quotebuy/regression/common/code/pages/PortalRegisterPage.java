package com.argos.pet.quotebuy.regression.common.code.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class PortalRegisterPage {

	ThreadLocal<WebDriver> ldriver;

	public PortalRegisterPage(ThreadLocal<WebDriver> driver)
	{
		ldriver = driver;
		PageFactory.initElements(driver.get(), this);
	}

	@FindBy (how = How.XPATH, using ="//*[@id='cookieMessageDismiss']") WebElement continueButton;
	@FindBy (how = How.XPATH, using = "//*[@id='register-tab']") WebElement registerTabButton;
	@FindBy (how = How.XPATH, using = "//*[@id='email_address']") WebElement emailAddress;
	@FindBy (how = How.XPATH, using = "//*[@id='policy_number']") WebElement policyNumber;
	@FindBy (how = How.XPATH, using = "//*[@id='postcode']") WebElement postCode;
	@FindBy (how = How.XPATH, using = "//*[@id='dobDay']") WebElement dobDay;
	@FindBy (how = How.XPATH, using = "//*[@id='dobMonth']") WebElement dobMonth;
	@FindBy (how = How.XPATH, using = "//*[@id='dobYear']") WebElement dobYear;
	@FindBy (how = How.XPATH, using = "//*[@id='password']") WebElement password;
	@FindBy (how = How.XPATH, using = "//*[@id='re_enter_password']") WebElement reEnterPassword;
	@FindBy (how = How.XPATH, using = "//*[@id='contactForm']/div[5]/div/div/label") WebElement useEmailForAllPolicies;
	@FindBy (how = How.XPATH, using = "//*[@id='registerSubmit']") WebElement nextButton;
	@FindBy (how = How.XPATH, using = "/html/body/div[4]/div/div/div[3]/div[1]/button/img") WebElement crossButtonOnConfirmYourRegistrationPopUp;
	@FindBy (how = How.XPATH, using = "//*[text() [contains (., 'Registration successful')]]") WebElement successfulRegistrationMessage;
	@FindBy (how = How.XPATH, using ="//*[@id='policyNumber']") WebElement policyNumberOnNewPopUp;
	@FindBy (how = How.XPATH, using = "//*[text() [contains (., 'Submit policy number')]] [@type='submit']") WebElement submitPolicyNumberButton;

	public void clickContinueButton()
	{
		continueButton.click();
	}
	
	public void setRegisterTabButton()
	{
		registerTabButton.click();
	}
	
	public void setEmailAddress(String EmailID)
	{
		emailAddress.sendKeys(EmailID);
	}
	
	public void setPolicyNumber(String PolicyNumber)
	{
		policyNumber.sendKeys(PolicyNumber);
	}
	
	public void setPostCode(String PostCode)
	{
		postCode.sendKeys(PostCode);
	}
	
	public void setDOBDay(String DOBDay)
	{
		dobDay.sendKeys(DOBDay);
	}
	
	public void setDOBMonth(String DOBMonth)
	{
		dobMonth.sendKeys(DOBMonth);
	}
	
	public void setDOBYear(String DOBYear)
	{
		dobYear.sendKeys(DOBYear);
	}
	
	public void setPassword(String Password)
	{
		password.sendKeys(Password);
	}

	public void setReEnterPassword(String ReEnterPassword)
	{
		reEnterPassword.sendKeys(ReEnterPassword);
	}

	public void setUseEmailForAllPolicies()
	{
		useEmailForAllPolicies.click();
	}
	
	public void setNextButton()
	{
		nextButton.click();
	}
	
	public void setCrossButtonOnConfirmYourRegistrationPopUp()
	{
		crossButtonOnConfirmYourRegistrationPopUp.click();
	}
	
	public String getSuccessfulRegistrationMessage()
	{
		return successfulRegistrationMessage.getText();
	}
	
	public void setPolicyNumberOnNewPopUp(String PolicyNumberOnNewPopUp)
	{
		policyNumberOnNewPopUp.sendKeys(PolicyNumberOnNewPopUp);
	}
	
	public void setSubmitPolicyNumberButton()
	{
		submitPolicyNumberButton.click();
	}
}
