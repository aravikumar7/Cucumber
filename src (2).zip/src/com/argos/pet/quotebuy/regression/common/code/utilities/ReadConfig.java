package com.argos.pet.quotebuy.regression.common.code.utilities;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class ReadConfig
{

	public Properties properties;
	public String envName;
	public String browserName;
	public String url;
	public String chromePath;
	public String iEPath;
	public String fireFoxPath;
	public String logFilePath;
	public String testResultFilePath;
	public String configFilePath;
	public String screenshotPath;
	public String excelPath;


	public ReadConfig() throws IOException
	{
		properties = new Properties();
		FileInputStream fileInputStream = new FileInputStream(System.getProperty("user.dir") + "/src/com/argos/pet/quotebuy/config/config.properties");
		properties.load(fileInputStream);
	}

	public String getTestEnvironmentName()
	{
		String envName = properties.getProperty("TestEnvironmentName");
		return envName;
	}

	public String getBrowserName()
	{
		String browserName = properties.getProperty("Browser");
		return browserName;
	}

	public String getTestEnvironmentURL()
	{
		String url = properties.getProperty("TestEnvironmentURL");
		return url;
	}

	public String getUsername()
	{
		String userName = properties.getProperty("Username");
		return userName;
	}

	public String getPassword()
	{
		String password = properties.getProperty("Password");
		return password;
	}

	public String getChromePath()
	{
		String chromePath = properties.getProperty("chromepath");
		return chromePath;
	}

	public String getIEPath()
	{
		String iEPath = properties.getProperty("iepath");
		return iEPath;
	}

	public String getFireFoxPath()
	{
		String fireFoxPath = properties.getProperty("firefoxpath");
		return fireFoxPath;
	}

	public String getEdgePath()
	{
		String edgePath = properties.getProperty("edgepath");
		return edgePath;
	}

	public String getLogFilePath()
	{
		String logFilePath = properties.getProperty("logfilepath");
		return logFilePath;
	}

	public String getTestResultFilePath()
	{
		String testResultFilePath = properties.getProperty("testResultFilePath");
		return testResultFilePath;
	}

	public String getConfigFilePath()
	{
		String configFilePath = properties.getProperty("ConfigFilePath");
		return configFilePath;
	}

	public String getScreenshotPath()
	{
		String screenshotPath = properties.getProperty("screenshotpath");
		return screenshotPath;
	}

	public String getExcelPath()
	{
		String excelPath = properties.getProperty("ExcelPath");
		return excelPath;
	}
	public String getFirstEmailID()
	{
		String firstEmailID = properties.getProperty("FirstEmailID");
		return firstEmailID;
	}
	
	public String getSecondEmailID()
	{
		String secondEmailID = properties.getProperty("SecondEmailID");
		return secondEmailID;
	}
	
	public String getThirdEmailID()
	{
		String secondEmailID = properties.getProperty("ThirdEmailID");
		return secondEmailID;
	}
	
	public String getFullResultTextFileName()
	{
		String FullResultTextFileName = properties.getProperty("FullResultTextFileName");
		return FullResultTextFileName;
	}
	
	public String getExtentReportFileName()
	{
		String ExtentReportFileName = properties.getProperty("ExtentReportFileName");
		return ExtentReportFileName;
	}
	
	public String getEmailSubject()
	{
		String EmailSubject = properties.getProperty("EmailSubject");
		return EmailSubject;
	}
	
	public String getEmailBody()
	{
		String EmailBody = properties.getProperty("EmailBody");
		return EmailBody;
	}
	
	public String getSendersEmailID()
	{
		String sendersEmailID = properties.getProperty("SendersEmailID");
		return sendersEmailID;
	}
	
	public String getSendersEmailPassword()
	{
		String sendersEmailPassword = properties.getProperty("SendersEmailPassword");
		return sendersEmailPassword;
	}

}