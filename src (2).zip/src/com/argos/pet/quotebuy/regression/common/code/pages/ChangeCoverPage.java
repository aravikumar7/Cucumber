/**
 * 
 */
package com.argos.pet.quotebuy.regression.common.code.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * @author d23747
 *
 */
public class ChangeCoverPage {

	ThreadLocal<WebDriver> ldriver;

	public ChangeCoverPage (ThreadLocal<WebDriver> rdriver)
	{
		ldriver = rdriver;
		PageFactory.initElements(rdriver.get(), this);
	}
	//
	@FindBy (how = How.XPATH, using = "//*[@id='quoteReviewPetBlockContainer_1']/div[1]/div[3]/div[1]/div/div[3]/button/div[2]") WebElement changeCoverButton;
	@FindBy (how = How.XPATH, using = "//*[@id='chooseProductLevel_1']/div/div[1]/button") WebElement chooseTimeLimitedButton;
	@FindBy (how = How.XPATH, using = "//*[@id='radio_cover_level_3000_1']") WebElement radio�3000Button;
	@FindBy (how = How.XPATH, using = "//*[@id='chooseProductLevel_1']/div/div[2]/button") WebElement chooseLifetimeButton;
	@FindBy (how = How.XPATH, using = "//*[@id='radio_cover_level_2500_1']") WebElement radio�2500Button;
	@FindBy (how = How.XPATH, using = "//*[@id='radio_cover_level_5000_1']") WebElement radio�5000Button;
	@FindBy (how = How.XPATH, using = "//*[@id='radio_cover_level_7500_1']") WebElement radio�7500Button;
	@FindBy (how = How.XPATH, using = "//*[@id='radio_cover_level_10000_1']") WebElement radio�10000Button;
	@FindBy (how = How.XPATH, using = "//*[@id='chooseProductLevel_1']/div/div[3]/button") WebElement chooseMaxBenefitButton;
	@FindBy (how = How.XPATH, using = "//*[@id='radio_cover_level_3000_1']") WebElement maxradio�3000Button;
	@FindBy (how = How.XPATH, using = "//*[@id='radio_cover_level_6000_1']") WebElement maxradio�6000Button;
	
	@FindBy (how = How.XPATH, using = "//*[@id='modalSubmit']") WebElement saveCloseButton;
	@FindBy (how = How.XPATH, using = "//*[@id='chooser_container_1']/button[2]") WebElement cancelButton;

	public void clickChangeCoverButton()
	{
		changeCoverButton.click();
	}
	public void clickChooseTimeLimitedButton()
	{
		chooseTimeLimitedButton.click();
	}
	public void clickChooseMaxBenefitButton()
	{
		chooseMaxBenefitButton.click();
	}
	public void clickRadio�3000Button()
	{
		radio�3000Button.click();
	}
	public void clickChooseLifetimeButton()
	{
		chooseLifetimeButton.click();
	}
	public void clickRadio�2500Button()
	{
		radio�2500Button.click();
	}
	public void clickRadio�5000Button()
	{
		radio�5000Button.click();
	}
	public void clickRadio�7500Button()
	{
		radio�7500Button.click();
	}
	public void clickRadio�10000Button()
	{
		radio�7500Button.click();
	}
	public void clickRadioMax�3000Button()
	{
		maxradio�3000Button.click();
	}
	public void clickRadioMax�6000Button()
	{
		maxradio�6000Button.click();
	}
	public void clickSaveCloseButton()
	{
		saveCloseButton.click();
	}
	public void clickCancelButton()
	{
		cancelButton.click();
	}
}
