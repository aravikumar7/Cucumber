/**
 * 
 */
package com.argos.pet.quotebuy.regression.common.code.utilities;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Objects;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import javax.mail.MessagingException;

import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.ProfilesIni;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.SessionId;
import org.testng.ITest;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.log4testng.Logger;
import org.openqa.selenium.Platform;

import com.argos.pet.quotebuy.regression.common.code.dbconnection.DBConnectionRegressionCommonCode;
import com.argos.pet.quotebuy.regression.common.code.utilities.ReadConfig;
import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;
import com.codoid.products.fillo.Recordset;

//import okhttp3.internal.platform.Platform;

/**
 * @author d23747
 *
 */
public class TestBase  extends ExtentTestNGReportBuilder{

	//Created new properties object from java utils
	public Properties properties;
	ReadConfig readConfig;
	Utilities utilities;
	DBConnectionRegressionCommonCode dbConnectionRegressionCommonCode;
	public String TestEnvironmentURL;
	public String Browser;
	public String Username;
	public String Password;
	public String chromepath;
	public String iepath;
	public String firefoxpath;
	public String edgepath;
	public String logfilepath;
//	public static WebDriver driver;
	protected static ThreadLocal<WebDriver> driver=new ThreadLocal<>();
	public String BrowserName;
	public String BrowserVersion;
	public String Device_Name;
	public String Device_Model;
	public String OperatingSystemName;
	public String OperatingSystemVersion;
	public String NameOfProject;
	public static String NameOfTest;
	public String Browserstack_USERNAME;
	public String Browserstack_AUTOMATE_KEY;
	public String BrowserStackTesting;
	public Logger logger;
	String className;
	String TestEnvName;
	String FilePath;
	Boolean mobile=false;
	DateFormat dateFormat = new SimpleDateFormat("ddMMyyyy_HHmmss");
	Calendar cal = Calendar.getInstance();
	
	
		
	public TestBase(){
	
		
		try
		{
			properties = new Properties(); //Instantiating properties object
			FileInputStream fileInputStream = new FileInputStream(System.getProperty("user.dir") + "/src/com/argos/pet/quotebuy/config/config.properties"); //Read config file
			properties.load(fileInputStream); //Loading the config file via properties object
		}
		//Catching exceptions
		catch (FileNotFoundException fnfe)
		{
			fnfe.printStackTrace();
		}
		catch (IOException ioe)
		{
			ioe.printStackTrace();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
	@BeforeSuite
	public void fileDelete() throws IOException {
		readConfig = new ReadConfig();
		TestEnvName=readConfig.getTestEnvironmentName();;
		FilePath = readConfig.getTestResultFilePath() + TestEnvName + ".txt";
		//Files.deleteIfExists(Paths.get(FilePath));
		File f1=new File(FilePath);
		File f2 = new File(readConfig.getTestResultFilePath() + TestEnvName+"_"+dateFormat.format(cal.getTime())+".txt");
		//boolean b = f1.renameTo(f2);
		System.out.println("File Path 1: "+FilePath);
		System.out.println("File Path 2: "+readConfig.getTestResultFilePath() + TestEnvName+"_"+dateFormat.format(cal.getTime())+".txt");
		if(f1.renameTo(f2)){
			System.out.println("Renamed successfully");
		}
		else{
			System.out.println("Rename failed");
		}
	}
	@Parameters ("ClassName")
	@BeforeMethod
	public void setUpMethod(String ClassName) throws Exception {
		
	/*	if(Objects.isNull(driver)){
		DriverManager.setDriver(driver);
			}
*/
			
			
		readConfig = new ReadConfig();
		logger = Logger.getLogger(getClass());
		PropertyConfigurator.configure("Log4j.properties");
		TestEnvironmentURL = readConfig.getTestEnvironmentURL();
		Browser = readConfig.getBrowserName();
		chromepath = readConfig.getChromePath();
		iepath = readConfig.getIEPath();
		firefoxpath = readConfig.getFireFoxPath();
		edgepath = readConfig.getFireFoxPath();
		logfilepath = readConfig.getLogFilePath();
		Username = readConfig.getUsername();
		Password = readConfig.getPassword();

		
		try
		{
			utilities = new Utilities();
			className = utilities.getClassName(ClassName);
			String  strQuery = "Select * from PetQuote where TestClassName = '" + className + "'";
			dbConnectionRegressionCommonCode = new DBConnectionRegressionCommonCode();
			Recordset recordset = dbConnectionRegressionCommonCode.recordset(strQuery);
			recordset.next();
			recordset.moveFirst();

			Device_Name = recordset.getField("Device_Name");
			BrowserName = recordset.getField("BrowserName");
			Device_Model = recordset.getField("Device_Model");
			BrowserVersion = recordset.getField("BrowserVersion");
			OperatingSystemName = recordset.getField("OperatingSystemName");
			OperatingSystemVersion = recordset.getField("OperatingSystemVersion");
			NameOfProject = recordset.getField("NameOfProject");
			NameOfTest = recordset.getField("NameOfTest");
			Browserstack_USERNAME = recordset.getField("Browserstack_USERNAME");
			Browserstack_AUTOMATE_KEY = recordset.getField("Browserstack_AUTOMATE_KEY");
			BrowserStackTesting = recordset.getField("BrowserStackTesting");

			final String URL = "https://" + Browserstack_USERNAME + ":" + Browserstack_AUTOMATE_KEY + "@hub-cloud.browserstack.com/wd/hub";

			
			if (BrowserStackTesting.equalsIgnoreCase("Yes"))
			{
				if (Device_Name.equalsIgnoreCase("Computer"))
				{
					try
					{
//						driver.close();
	//					driver.quit();
						DesiredCapabilities caps = new DesiredCapabilities();
						caps.setCapability("browser", BrowserName);
						caps.setCapability("browser_version", BrowserVersion);
						caps.setCapability("os", OperatingSystemName);
						caps.setCapability("os_version", OperatingSystemVersion);
						caps.setCapability("resolution", "1024x768");
						caps.setCapability("name", NameOfTest);
						caps.setCapability("project", NameOfProject);
						caps.setCapability("build", "1.0");
						caps.setCapability("browserstack.debug", true);
						caps.setCapability("browserstack.networkLogs", true);
						caps.setCapability("browserstack.idleTimeout" , "300");

				//		driver = new RemoteWebDriver(new URL(URL), caps);
						driver.set(new RemoteWebDriver(new URL(URL), caps));
					}
					catch (Exception e)
					{
						e.printStackTrace();
					}
				}
				else
				{
					try
					{
						//driver.close();
						//driver.quit();
						DesiredCapabilities caps = new DesiredCapabilities();
						caps.setCapability("browserName", BrowserName);
						caps.setCapability("device", Device_Model);
					//	caps.setCapability("nativeEvents", false);
					//	caps.setCapability("nativeWebTap",true);
						caps.setCapability("realMobile", "true");
						caps.setCapability("acceptSslCerts",true);
						caps.setCapability("os_version", OperatingSystemVersion);
						caps.setCapability("name", NameOfTest);
						caps.setCapability("project", NameOfProject);
						caps.setCapability("browserstack.appium_version", "1.14.0");
						caps.setCapability("build", "1.0");
						caps.setCapability("browserstack.debug", true);
						caps.setCapability("browserstack.networkLogs", true);
						caps.setCapability("browserstack.idleTimeout" , "300");
						mobile=true;
					//	driver = new RemoteWebDriver(new URL(URL), caps);
						driver.set(new RemoteWebDriver(new URL(URL), caps));
					}
					catch (Exception e)
					{
						e.printStackTrace();
					}
				}
			}
			
			else {
			if (Browser.equalsIgnoreCase("Chrome"))
			{
				ChromeOptions options = new ChromeOptions();
				options.addArguments("--disable-notifications");
				options.addArguments("--ignore-ssl-errors");
			    options.addArguments("--ignore-certificate-errors");
			//    options.addArguments("window-size=600,480");
			//	options.setCapability("javascriptEnabled",true);
			   // options.addArguments("--user-data-dir=C:/Users/d49492/AppData/Local/Google/Chrome/User Data");
			    options.setExperimentalOption("useAutomationExtension", false);
				//options.setExperimentalOption(CapabilityType.ACCEPT_SSL_CERTS, true);
				HashMap<String, Object> chromePrefs = new HashMap<String, Object>();
			    chromePrefs.put("download.prompt_for_download", true);
			    //options.setExperimentalOption("download.prompt_for_download", true);
			    options.setExperimentalOption("prefs", chromePrefs);
				options.addArguments("--incognito");
			//	options.addArguments("--headless");
				System.setProperty("webdriver.chrome.driver", chromepath);
			//	driver = new ChromeDriver(options);
				driver.set(new ChromeDriver(options));
				driver.get().manage().window().maximize();

			}

			else if (Browser.equalsIgnoreCase("Firefox"))
			{
				System.setProperty("webdriver.gecko.driver", firefoxpath);
				FirefoxProfile profile = new ProfilesIni().getProfile("default");
				profile.setAcceptUntrustedCertificates(false);
			//	DesiredCapabilities dc = DesiredCapabilities.firefox();
			//	dc.setCapability(FirefoxDriver.PROFILE, profile);
				//driver = new FirefoxDriver(dc);
				FirefoxOptions options = new FirefoxOptions();
				options.setCapability(FirefoxDriver.PROFILE, profile);				
				driver.set(new FirefoxDriver(options));
				driver.get().manage().window().maximize();
				driver.get().manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
			}

			else if (Browser.equalsIgnoreCase("IE"))
			{ 
				System.setProperty("webdriver.ie.driver", readConfig.getIEPath());
		/*		DesiredCapabilities capability = DesiredCapabilities.internetExplorer();
				capability.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
				capability.setCapability(InternetExplorerDriver.INITIAL_BROWSER_URL, "https://uat33.cardifpinnacle.com/quote");
				capability.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
				capability.setCapability("useAutomationExtension", false);
				capability.setCapability("ignoreProtectedModeSettings'", true);
				capability.setCapability("ignoreZoomSetting", true);
			//	capability.setCapability("nativeEvents", false);
				capability.setCapability("acceptSslCerts", true);
				driver = new InternetExplorerDriver(capability);
			*/					
				
				InternetExplorerOptions options = new InternetExplorerOptions();
				options.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
				options.setCapability(InternetExplorerDriver.INITIAL_BROWSER_URL, "https://uat33.cardifpinnacle.com/quote");
				options.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
				options.setCapability("useAutomationExtension", false);
				options.setCapability("ignoreProtectedModeSettings'", true);
				options.setCapability("ignoreZoomSetting", true);
			//	options.setCapability("nativeEvents", false);
				options.setCapability("acceptSslCerts", true);
				driver.set(new InternetExplorerDriver(options));
				driver.get().manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
			//	driver.navigate().to("https://uat33.cardifpinnacle.com/quote");
				Thread.sleep(2000);
				//////
				String loadPath=System.getProperty("user.dir") + "/Drivers/iebrowserauth.exe";
				Runtime.getRuntime().exec(loadPath);
			/*	String[] cmmm = {"Powershell.exe","-executionpolicy","remotesigned","-File",loadPath};
						    ProcessBuilder processBuilder = new ProcessBuilder(loadPath);
						    Process process = processBuilder.start();
						    try {
								process.waitFor();
							} catch (InterruptedException e) {
								e.printStackTrace();
							}
						   String result = String.valueOf(process.exitValue());
						   System.out.println("Result is : "+result);
			*/
				//////
		
				
				/*Alert alert = driver.switchTo().alert();
				alert.sendKeys("dev");
				driver.switchTo().activeElement().sendKeys(Keys.TAB);
				alert.sendKeys("pPdev22!!");
				alert.accept();*/
			/*	Actions builder = new Actions(driver);
				builder.sendKeys("dev").build().perform();
						Thread.sleep(5000);
				builder.sendKeys(Keys.TAB).build().perform();
				Thread.sleep(5000);
				builder.sendKeys("pPdev22!!").build().perform();
				Thread.sleep(5000);
				builder.sendKeys(Keys.ENTER).build().perform();*/
			/*	String mainWindowHandle = driver.getWindowHandle();

				for (String childWindowHandle : driver.getWindowHandles()) {
				  //If window handle is not main window handle then close it 
				  if(!childWindowHandle.equals(mainWindowHandle)){
				  driver.switchTo().window(childWindowHandle);
				  Actions builder = new Actions(driver);
					builder.sendKeys("dev").build().perform();
							Thread.sleep(500);
					builder.sendKeys(Keys.TAB).build().perform();
					Thread.sleep(500);
					builder.sendKeys("pPdev22!!").build().perform();
					Thread.sleep(500);
					builder.sendKeys(Keys.ENTER).build().perform();
					Thread.sleep(500);
				  }
				} 

				//switch back to main window
				driver.switchTo().window(mainWindowHandle);*/
			
				////////
			//	Robot rb = new Robot();
			//	utilities.robotKeys(rb, "ENTER");
				// Alert alert=driver.switchTo().alert();
				// Thread.sleep(2000);
				// alert.sendKeys("dev");
				// driver.switchTo().activeElement().sendKeys(Keys.TAB);
				// alert.sendKeys("pPdev2!!");
				// alert.accept();
				Thread.sleep(2000);
				
		/*		  Robot rb = new Robot(); 
				  rb.setAutoDelay(500); 
				  //Enter user name by ctrl-v 
				  StringSelection username = new StringSelection("dev");
				  Toolkit.getDefaultToolkit().getSystemClipboard().setContents(username,username);
				  rb.keyPress(KeyEvent.VK_CONTROL); 
				  rb.keyPress(KeyEvent.VK_V);
				  rb.keyRelease(KeyEvent.VK_V); 
				  rb.keyRelease(KeyEvent.VK_CONTROL);
				  
				  //tab to password entry field rb.keyPress(KeyEvent.VK_TAB);
				  rb.keyRelease(KeyEvent.VK_TAB); 
				  Thread.sleep(2000);
				  
				  //Enter password by ctrl-v 
				  StringSelection pwd = new StringSelection("pPdev22!!");
				  Toolkit.getDefaultToolkit().getSystemClipboard().setContents(pwd,null); 
				  rb.keyPress(KeyEvent.VK_CONTROL);
				  rb.keyPress(KeyEvent.VK_V); 
				  rb.keyRelease(KeyEvent.VK_V);
				  rb.keyRelease(KeyEvent.VK_CONTROL);
				  
				  //press enter rb.keyPress(KeyEvent.VK_ENTER);
				  rb.keyRelease(KeyEvent.VK_ENTER);
				  */
				  //wait Thread.sleep(2000);
				 
///////
			}

			else if (Browser.equalsIgnoreCase("Edge"))
			{
				System.setProperty("webdriver.edge.driver", readConfig.getEdgePath());
			/*	DesiredCapabilities capability = DesiredCapabilities.edge();
				//capability.setBrowserName("MicrosoftEdge");
				capability.setCapability("setBinary", readConfig.getEdgePath());
				capability.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
				capability.setCapability("useAutomationExtension", false);
				capability.setCapability("ignoreProtectedModeSettings'", true);
				capability.setCapability("ignoreZoomSetting", true);
				capability.setCapability("nativeEvents", false);
				capability.setCapability("acceptSslCerts", true);
				driver = new EdgeDriver(capability);
				*/
				EdgeOptions options = new EdgeOptions();
				options.setCapability("setBinary", readConfig.getEdgePath());
				options.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
				options.setCapability("useAutomationExtension", false);
				options.setCapability("ignoreProtectedModeSettings'", true);
				options.setCapability("ignoreZoomSetting", true);
				options.setCapability("nativeEvents", false);
				options.setCapability("acceptSslCerts", true);
				driver.set(new EdgeDriver(options));
				
				driver.get().manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
			}

			else
			{
				ChromeOptions options = new ChromeOptions();
				options.addArguments("--disable-notifications");
				options.setExperimentalOption("useAutomationExtension", false);
				//options.addArguments("--incognito");
				System.setProperty("webdriver.chrome.driver", chromepath);
		//		driver = new ChromeDriver(options);
				driver.set(new ChromeDriver(options));
			}
			}
		
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}

		try
		{
			
			driver.get().manage().deleteAllCookies();
			//driver.manage().window().maximize();
			driver.get().manage().timeouts().implicitlyWait(25, TimeUnit.SECONDS);
			driver.get().get("https://" + Username + ":" + Password + "@" + "UAT30.cardifpinnacle.com");
			driver.get().navigate().to("https://" + TestEnvironmentURL);
			//Thread.sleep(700);
			utilities = new Utilities();
			Thread.sleep(700);
			if (utilities.isElementPresent(By.xpath("//*[@id='cookieMessageDismiss']"), driver))
			{
				Thread.sleep(700);
				WebElement cookie=driver.get().findElement(By.xpath("//*[@id='cookieMessageDismiss']"));
				((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", cookie);
				((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", cookie);
			}
		//	Thread.sleep(700);
		//	driver.navigate().refresh();
		//	Thread.sleep(700);
	/*		if(!mobile){
			driver.findElement(By.xpath("(//a[text()='Start a quote'])[1]")).click();
			}
			else{
				driver.findElement(By.xpath("(//a[text()='Start a quote'])[1]")).click();
		//To be uncommented after 4389
		//		driver.findElement(By.xpath("//button[@class='navbar-toggler-btn ']")).click();
		//		driver.findElement(By.xpath("(//a[text()='Dog Insurance'])[2]")).click();
		//		
			}*/
		}

		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	
	@DataProvider (name = "browserStackTestData")
	public Object[][] getData()
	{
		Object[][] testData = new Object[][]
				{
				{"Mobile","Samsung","Samsung Galaxy S10","","9.0","SainsburysPetQuoteBuyBrowserstack_Mobile_Samsung_Samsung Galaxy S10___9.0","SainsburysPetQuoteBuyBrowserstack_TC007_QuoteJourney_DogBreed_Test_Mobile_Samsung_Samsung Galaxy S10___9.0","ravikumararjunan2","F5j7uzENx52b4QG5ybj7"},
				{"Mobile","Samsung","Samsung Galaxy S10","","9.0","SainsburysPetQuoteBuyBrowserstack_Mobile_Samsung_Samsung Galaxy S10___9.0","SainsburysPetQuoteBuyBrowserstack_TC007_QuoteJourney_DogBreed_Test_Mobile_Samsung_Samsung Galaxy S10___9.0","ravikumararjunan2","F5j7uzENx52b4QG5ybj7"}
				};
		return testData;
	}

	@AfterMethod
	public void teadDown() {
		driver.get().manage().deleteAllCookies();
		driver.get().close();
	    driver.get().quit();
	    
	 /*   if(Objects.nonNull(DriverManager.getDriver())){
	    	DriverManager.getDriver().close();
	    	DriverManager.getDriver().quit();
	    	DriverManager.unload();
	    	}*/
	}
	
	@AfterSuite
	public void tearDownSuite() throws IOException, MessagingException {

		utilities = new Utilities();
		//utilities.sendEmail(readConfig.getFirstEmailID(),readConfig.getSecondEmailID(),readConfig.getThirdEmailID(),readConfig.getFullResultTextFileName(),readConfig.getExtentReportFileName(),
			//            readConfig.getEmailSubject(),readConfig.getEmailBody(),readConfig.getSendersEmailID(),readConfig.getSendersEmailPassword());
	//	utilities.sendEmail();
		//utilities.CreateDirectory();
		//utilities.MoveFile();
		//driver.quit();
	}
}