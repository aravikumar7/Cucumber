/**
 * 
 */
package com.argos.pet.quotebuy.regression.common.code.tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.asserts.SoftAssert;

import com.argos.pet.quotebuy.regression.common.code.dbconnection.DBConnectionRegressionCommonCode;
import com.argos.pet.quotebuy.regression.common.code.pages.YourCoverPage;
import com.argos.pet.quotebuy.regression.common.code.utilities.TestBase;
import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;
import com.codoid.products.fillo.Recordset;


/**
 * @author d23747
 *
 */
public class YourCoverTest extends TestBase {

	YourCoverPage yourCoverPage;
	DBConnectionRegressionCommonCode dbConnectionCommonCode;
	Utilities utilities;
	SoftAssert softAssert;
	String className;
	public String ClassName;
	static String CoverType;

	@Parameters ("ClassName")
	public void testYourCover(String ClassName) throws Exception
	{
		yourCoverPage = new YourCoverPage(driver);
		dbConnectionCommonCode = new DBConnectionRegressionCommonCode();
		utilities = new Utilities();
		softAssert = new SoftAssert();
		className = utilities.getClassName(ClassName);
		String  strQuery = "Select * from YourCover where TestClassName = '" + className + "'";
		Recordset recordset = dbConnectionCommonCode.recordset(strQuery);
		recordset.next();
		recordset.moveFirst();
		Thread.sleep(2500);
	//	String quoteReferenceNumber = yourCoverPage.getQuoteReferenceNumberText();
		Thread.sleep(700);
	//	System.out.println(quoteReferenceNumber);
	//	utilities.Filewriter("Quote Reference Number & Quote validity is: " + quoteReferenceNumber);
		CoverType = recordset.getField("CoverType");
		utilities.waitForLoad(driver);
		if (recordset.getField("CoverType").equalsIgnoreCase("TimeLimited"))
		{
			Thread.sleep(1500);
			yourCoverPage.clickChooseTimeLimitedButton();
			//utilities.waitElement(driver.findElement(By.id("radio_cover_level_2500_1")), driver);
			if (recordset.getField("TimeLimitedLevelOfCover").equalsIgnoreCase("�2500"))
			{
				yourCoverPage.clickRadio�2500Button();
			}
			if (recordset.getField("TimeLimitedLevelOfCover").equalsIgnoreCase("�4000"))
			{
				yourCoverPage.clickRadio�4000Button();
			}
		}

		else if (recordset.getField("CoverType").equalsIgnoreCase("Lifetime"))
		{
			yourCoverPage.clickChooseLifetimeButton();
			if (recordset.getField("PetType").equalsIgnoreCase("Dog"))
			{
	//			utilities.waitElement(driver.findElement(By.id("radio_cover_level_2000_1")), driver);
				

				if (recordset.getField("LifetimeLevelOfCover").equalsIgnoreCase("�1000"))
				{
					yourCoverPage.clickRadio�1000Button();
				}

				else if (recordset.getField("LifetimeLevelOfCover").equalsIgnoreCase("�4500"))
				{
					yourCoverPage.clickRadio�4500Button();
				}

				else if (recordset.getField("LifetimeLevelOfCover").equalsIgnoreCase("�7000"))
				{
					yourCoverPage.clickRadio�7000Button();
				}
			}

			else if (recordset.getField("PetType").equalsIgnoreCase("Cat"))
			{
			//	utilities.waitElement(driver.findElement(By.id("radio_cover_level_1000_1")), driver);
				if (recordset.getField("LifetimeLevelOfCover_Cat").equalsIgnoreCase("�1000"))
				{
					yourCoverPage.clickRadio�1000CatButton();
				}

				else if (recordset.getField("LifetimeLevelOfCover_Cat").equalsIgnoreCase("�3500"))
				{
					yourCoverPage.clickRadio�3500CatButton();
				}

				else if (recordset.getField("LifetimeLevelOfCover_Cat").equalsIgnoreCase("�7000"))
				{
					yourCoverPage.clickRadio�7000CatButton();
				}
			}
			else if (recordset.getField("PetType").equalsIgnoreCase("Rabbit"))
			{
				yourCoverPage.clickRadio�1000Button();
			}


		}
		else if (recordset.getField("CoverType").equalsIgnoreCase("MaxBenefit"))
		{
			yourCoverPage.clickChooseMaxBenefitButton();
	//		utilities.waitElement(driver.findElement(By.id("radio_cover_level_2000_1")), driver);
			if (recordset.getField("PetType").equalsIgnoreCase("Dog"))
			{
			
				if (recordset.getField("MaxBenefitOfCover").equalsIgnoreCase("�2000"))
				{
					yourCoverPage.clickRadioMax�2000Button();
				}

				else if (recordset.getField("MaxBenefitOfCover").equalsIgnoreCase("�5000"))
				{
					yourCoverPage.clickRadioMax�5000Button();
				}
			}

			else
			{
				if (recordset.getField("MaxBenefitOfCover").equalsIgnoreCase("�2000"))
				{
					yourCoverPage.clickRadioMax�2000Button();
				}

				else if (recordset.getField("MaxBenefitOfCover").equalsIgnoreCase("�5000"))
				{
					yourCoverPage.clickRadioMax�5000Button();
				}

			}

		}
		
		/*WebElement downloadLink=driver.findElement(By.xpath("//*[@id='chooser_container_1']/div[3]/div/div[1]/div/a"));
		utilities.downloadFile("PolicyDocument1",downloadLink);
		Thread.sleep(1500);
		
		
		
		downloadLink=driver.findElement(By.xpath("//*[@id='chooser_container_1']/div[3]/div/div[2]/div/a"));
		utilities.downloadFile("IPID1",downloadLink);
		Thread.sleep(1000);
		//String output=utilities.validatePDF(driver,downloadLink,coverType);
		
		if(recordset.getField("CoverType").equalsIgnoreCase("TimeLimited")){
			softAssert.assertTrue(utilities.validatePDF(driver,downloadLink,"TimeLimited"));
			}
			else if(recordset.getField("CoverType").equalsIgnoreCase("Lifetime"))
			{
				softAssert.assertTrue(utilities.validatePDF(driver,downloadLink,"Lifetime"));
			}
			else{
				softAssert.assertTrue(utilities.validatePDF(driver,downloadLink,"Maximum Benefit Cover"));
			}
		*/
		//--End
		
		/*
		if (recordset.getField("CheckPromotionalCodeShortMessage").equalsIgnoreCase("Yes"))
		{
			String promotionalCodeShortTextOnWeb = yourCoverPage.getPromotionalCodeText();
			String promotionalCodeShortMessageFromExcel = recordset.getField("PromotionalCodeShortMessage");
			softAssert.assertEquals(promotionalCodeShortTextOnWeb, promotionalCodeShortMessageFromExcel);
			softAssert.assertAll();
		}
		*/
		//utilities.TakePassScreenShot(driver, recordset.getField("TestClassName"));
	//	yourCoverPage.clickReviewButton();
		if (recordset.getField("MultiPet").equalsIgnoreCase("Yes"))
		{
			yourCoverPage.clickNextButton();
		}
		else{
			yourCoverPage.clickReviewButton();
		}
		dbConnectionCommonCode.closeConnection();
	}
}
