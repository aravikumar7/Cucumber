/**
 * 
 */
package com.argos.pet.quotebuy.regression.common.code.tests;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.testng.annotations.Parameters;
import org.testng.asserts.SoftAssert;

import com.argos.pet.quotebuy.regression.common.code.dbconnection.DBConnectionRegressionCommonCode;
import com.argos.pet.quotebuy.regression.common.code.pages.YourPetDetailsPage;
import com.argos.pet.quotebuy.regression.common.code.utilities.TestBase;
import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;
import com.codoid.products.fillo.Recordset;


/**
 * @author d23747
 *
 */
public class MultiPetAssumptionsTest extends TestBase {

	DBConnectionRegressionCommonCode dbConnectionCommonCode;
	Utilities utilities;
	YourPetDetailsPage yourPetDetailsPage;
	SoftAssert softAssert;
	String[] dobArray;
	String className;
	static int numberOfMultiPetsInt;
	public String TextToWrite;
	public String ClassName;

	@Parameters ("ClassName")
	public void initiateMultiPetAssumptionsTest(String ClassName) throws Exception
	{
		utilities = new Utilities();
		className = utilities.getClassName(ClassName);
		numberOfMultiPetsInt = MultiPetTest.numberOfMultiPets;
		String  strQuery = "Select * from MultiPet where TestClassName = '" + className + "'";
		dbConnectionCommonCode = new DBConnectionRegressionCommonCode();
		Recordset recordset = dbConnectionCommonCode.recordset(strQuery);
		recordset.next();
		recordset.moveFirst();
		softAssert = new SoftAssert();
		yourPetDetailsPage = new YourPetDetailsPage(driver);
		if (recordset.getField("MultiPetChangeAssumptionLink_" + (numberOfMultiPetsInt - 1) + "").equalsIgnoreCase("Top"))
		{
			System.out.println("We are in assumption");
			driver.get().findElement(By.xpath("(//img[contains(@src,'pencil')])["+numberOfMultiPetsInt+"]")).click();
			if (recordset.getField("MultiPetDogCatMicrochipped_" + (numberOfMultiPetsInt - 1) + "").equalsIgnoreCase("Yes"))
			{
				driver.get().findElement(By.xpath("//label[@for='pet_microchippedYes']")).click();
				TextToWrite = "Pet" + (numberOfMultiPetsInt) + " Microchipped = Yes";
				utilities.Filewriter(TextToWrite);
			}
			else
			{
				driver.get().findElement(By.xpath("//label[@for='pet_microchippedNo']")).click();
				if (recordset.getField("MultiPetType_" + (numberOfMultiPetsInt -1) + "").equalsIgnoreCase("Dog"))
				{
					String MultiPetDogMicrochippedNoTextMessage = driver.get().findElement(By.xpath("//*[@id='editAssumptions']/div[11]/div/text()")).getText();
					softAssert.assertEquals(MultiPetDogMicrochippedNoTextMessage, recordset.getField("MultiPetDogMicrochippedNoTextMessage_" + (numberOfMultiPetsInt - 1) + ""));
					softAssert.assertAll();
					TextToWrite = "Pet" + (numberOfMultiPetsInt) + " Microchipped = No";
					utilities.Filewriter(TextToWrite);
				}

				else if (recordset.getField("MultiPetType_" + (numberOfMultiPetsInt - 1) + "").equalsIgnoreCase("Cat"))
				{
					String MultiPetCatMicrochippedNoTextMessage = driver.get().findElement(By.xpath("//*[@id='editAssumptions']/div[11]/div/text()")).getText();
					softAssert.assertEquals(MultiPetCatMicrochippedNoTextMessage, recordset.getField("MultiPetCatMicrochippedNoTextMessage_" + (numberOfMultiPetsInt - 1) + ""));
					softAssert.assertAll();
					TextToWrite = "Pet" + (numberOfMultiPetsInt) + " Microchipped = No";
					utilities.Filewriter(TextToWrite);
				}
			}

			if (recordset.getField("MultiPetType_" + (numberOfMultiPetsInt - 1) + "").equalsIgnoreCase("Dog"))
			{
				if (recordset.getField("MultiPetDogWorking_" + (numberOfMultiPetsInt - 1) + "").equalsIgnoreCase("Yes"))
				{
					driver.get().findElement(By.xpath("//label[@for = 'licensed_premisesYes']")).click();
					String MultiPetDogWorking = driver.get().findElement(By.xpath("//*[@id='js-warning-is_working_dog_" + numberOfMultiPetsInt + "']/div")).getText();
					softAssert.assertEquals(MultiPetDogWorking, recordset.getField("MultiPetDogWorkingYesTextMessage_" + (numberOfMultiPetsInt - 1) + ""));
					softAssert.assertAll();
					TextToWrite = "Pet" + (numberOfMultiPetsInt) + " Working = Yes";
					utilities.Filewriter(TextToWrite);
				}
				else
				{
					driver.get().findElement(By.xpath("//label[@for = 'licensed_premisesNo']")).click();
					TextToWrite = "Pet" + (numberOfMultiPetsInt) + " Working = No";
					utilities.Filewriter(TextToWrite);
				}
			}

		/*	if (recordset.getField("MultiPetDogCatFromRescueHome_" + (numberOfMultiPetsInt - 1) + "").equalsIgnoreCase("Yes"))
			{
				driver.get().findElement(By.xpath("//label[@for='rescue_homeYes']")).click();
				TextToWrite = "Pet" + (numberOfMultiPetsInt) + " From Rescue Home = Yes";
				utilities.Filewriter(TextToWrite);
			}
			else
			{
				driver.get().findElement(By.xpath("//label[@for='rescue_homeNo']")).click();
				TextToWrite = "Pet" + (numberOfMultiPetsInt) + " From Rescue Home = No";
				utilities.Filewriter(TextToWrite);
			}
*/
			if (recordset.getField("MultiPetDogCatAddressSameAsPolicyHolder_" + (numberOfMultiPetsInt - 1) + "").equalsIgnoreCase("Yes"))
			{
				driver.get().findElement(By.xpath("//label[@for = 'pet_reside_same_addressYes']")).click();
				TextToWrite = "Pet" + (numberOfMultiPetsInt) + " Lives With Policy Holder = Yes";
				utilities.Filewriter(TextToWrite);
			}
			else
			{
				driver.get().findElement(By.xpath("//label[@for = 'pet_reside_same_addressNo']")).click();
				String MultiPetDogAddressSameAsPolicyHolderNoTextMessage = driver.get().findElement(By.xpath("//*[@id='js-warning-pet_reside_same_address_" + numberOfMultiPetsInt + "']/div")).getText();
				softAssert.assertEquals(MultiPetDogAddressSameAsPolicyHolderNoTextMessage, recordset.getField("MultiPetDogAddressSameAsPolicyHolderNoTextMessage_" + (numberOfMultiPetsInt - 1) + ""));
				softAssert.assertAll();
				TextToWrite = "Pet" + (numberOfMultiPetsInt) + " Lives With Policy Holder = No";
				utilities.Filewriter(TextToWrite);
			}

			if (recordset.getField("MultiPetDogCatVeterinaryNeeds_" + (numberOfMultiPetsInt - 1) + "").equalsIgnoreCase("Yes"))
			{
				driver.get().findElement(By.xpath("//label[@for='iddYes']")).click();
				TextToWrite = "Pet" + (numberOfMultiPetsInt) + " Veterinary Needs = Yes";
				utilities.Filewriter(TextToWrite);
			}
			else
			{
				driver.get().findElement(By.xpath("//label[@for='iddNo']")).click();
				String MultiPetDogVeterinaryNeedsNoTextMessage = driver.get().findElement(By.xpath("//*[@id='js-warning-idd_" + numberOfMultiPetsInt + "']/div")).getText();
				softAssert.assertEquals(MultiPetDogVeterinaryNeedsNoTextMessage, recordset.getField("MultiPetDogVeterinaryNeedsNoTextMessage_" + (numberOfMultiPetsInt - 1) + ""));
				softAssert.assertAll();
				TextToWrite = "Pet" + (numberOfMultiPetsInt) + " Veterinary Needs = No";
				utilities.Filewriter(TextToWrite);
			}

			if (recordset.getField("MultiPetType_" + (numberOfMultiPetsInt - 1) + "").equalsIgnoreCase("Dog"))
			{
				if (recordset.getField("MultiPetDogAlchoholSoldPremises_" + (numberOfMultiPetsInt - 1) + "").equalsIgnoreCase("Yes"))
				{
					driver.get().findElement(By.xpath("//label[@for = 'licensed_premisesYes']")).click();
					String MultiPetDogAlchoholSoldPremisesYesTextMessage = driver.get().findElement(By.xpath("//*[@id='js-warning-licensed_premises_" + numberOfMultiPetsInt + "']/div")).getText();
					softAssert.assertEquals(MultiPetDogAlchoholSoldPremisesYesTextMessage, recordset.getField("MultiPetDogAlchoholSoldPremisesYesTextMessage_" + (numberOfMultiPetsInt - 1) + ""));
					softAssert.assertAll();
					TextToWrite = "Pet" + (numberOfMultiPetsInt) + " From Alchohol Sold Premises = Yes";
					utilities.Filewriter(TextToWrite);
				}
				else
				{
					driver.get().findElement(By.xpath("//label[@for = 'licensed_premisesNo']")).click();
					TextToWrite = "Pet" + (numberOfMultiPetsInt) + " From Alchohol Sold Premises = No";
					utilities.Filewriter(TextToWrite);
				}

				if (recordset.getField("MultiPetDogBadBehaviour_" + (numberOfMultiPetsInt - 1) + "").equalsIgnoreCase("Yes"))
				{
					driver.get().findElement(By.xpath("//label[@for='dog_behaviourYes']")).click();
					String MultiPetDogBadBehaviourYesTextMessage = driver.get().findElement(By.xpath("//*[@id='js-warning-dog_behaviour_" + numberOfMultiPetsInt + "']/div")).getText();
					softAssert.assertEquals(MultiPetDogBadBehaviourYesTextMessage, recordset.getField("MultiPetDogBadBehaviourYesTextMessage_" + (numberOfMultiPetsInt - 1) + ""));
					softAssert.assertAll();
					TextToWrite = "Pet" + (numberOfMultiPetsInt) + " Bad Behaviour = Yes";
					utilities.Filewriter(TextToWrite);
				}
				else
				{
					driver.get().findElement(By.xpath("//label[@for='dog_behaviourNo']")).click();
					TextToWrite = "Pet" + (numberOfMultiPetsInt) + " Bad Behaviour = No";
					utilities.Filewriter(TextToWrite);
				}
			}
			((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//div[text()='Save and close']")));
			((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//div[text()='Save and close']")));
	}


		else if (recordset.getField("MultiPetChangeAssumptionLink_" + (numberOfMultiPetsInt - 1) + "").equalsIgnoreCase("Bottom"))
		{
			//driver.get().findElement(By.xpath("//*[@id='assumptionsAccept_" + numberOfMultiPetsInt + "']/button/div")).click();
			
		WebElement	changeAssumption=driver.get().findElement(By.xpath("(//img[@src='/img/svg-icons/pencil.svg'])[" + numberOfMultiPetsInt + "]"));
			((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", changeAssumption);
			((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", changeAssumption);
			
			if (recordset.getField("MultiPetDogCatMicrochipped_" + (numberOfMultiPetsInt - 1) + "").equalsIgnoreCase("Yes"))
			{
				WebElement dogCatMicrochippedYes=driver.get().findElement(By.xpath("//label[@for='pet_microchippedYes']"));
				((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", dogCatMicrochippedYes);
				((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", dogCatMicrochippedYes);
				
				//driver.get().findElement(By.xpath("//*[@id='pet_microchipped_Yes_" + numberOfMultiPetsInt + "']")).click();
				TextToWrite = "Pet" + (numberOfMultiPetsInt) + " Microchipped = Yes";
				utilities.Filewriter(TextToWrite);
			}
			else
			{
			/*	driver.get().findElement(By.xpath("//*[@id='pet_microchipped_No_" + numberOfMultiPetsInt + "']")).click();
			//	if (recordset.getField("MultiPetType_" + (numberOfMultiPetsInt -1) + "").equalsIgnoreCase("Dog"))
				{*/
					WebElement dogCatMicrochippedNo=driver.get().findElement(By.xpath("//label[@for='pet_microchippedNo']"));
					((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", dogCatMicrochippedNo);
					((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", dogCatMicrochippedNo);
					
					String MultiPetDogMicrochippedNoTextMessage = driver.get().findElement(By.xpath("//mark[contains(text(),'microchipped')]//parent::span//parent::div/following-sibling::div[2]/div")).getText();
					softAssert.assertEquals(MultiPetDogMicrochippedNoTextMessage, recordset.getField("MultiPetDogMicrochippedNoTextMessage_" + (numberOfMultiPetsInt - 1) + ""));
					softAssert.assertAll();
					TextToWrite = "Pet" + (numberOfMultiPetsInt) + " Microchipped = No";
					utilities.Filewriter(TextToWrite);
				}

				/*else if (recordset.getField("MultiPetType_" + (numberOfMultiPetsInt - 1) + "").equalsIgnoreCase("Cat"))
				{
					WebElement dogCatMicrochippedYes=driver.get().findElement(By.xpath("//label[@for='pet_microchippedYes']"));
					((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", dogCatMicrochippedYes);
					((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", dogCatMicrochippedYes);
					
					String MultiPetDogMicrochippedNoTextMessage = driver.get().findElement(By.xpath("//mark[contains(text(),'microchipped')]//parent::span//parent::div/following-sibling::div[2]/div")).getText();
					String MultiPetCatMicrochippedNoTextMessage = driver.get().findElement(By.xpath("//*[@id='js-warning-pet_microchipped_" + numberOfMultiPetsInt + "']/div")).getText();
					softAssert.assertEquals(MultiPetCatMicrochippedNoTextMessage, recordset.getField("MultiPetCatMicrochippedNoTextMessage_" + (numberOfMultiPetsInt - 1) + ""));
					softAssert.assertAll();
					TextToWrite = "Pet" + (numberOfMultiPetsInt) + " Microchipped = No";
					utilities.Filewriter(TextToWrite);
				}
			}*/

			if (recordset.getField("MultiPetType_" + (numberOfMultiPetsInt - 1) + "").equalsIgnoreCase("Dog"))
			{
				if (recordset.getField("MultiPetDogWorking_" + (numberOfMultiPetsInt - 1) + "").equalsIgnoreCase("Yes"))
				{
				
					WebElement dogWorkingYes=driver.get().findElement(By.xpath("//label[@for='is_working_dogYes']"));
					((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", dogWorkingYes);
					((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", dogWorkingYes);
					
				//	driver.get().findElement(By.xpath("//*[@id='is_working_dog_Yes_" + numberOfMultiPetsInt + "']")).click();
					String MultiPetDogWorking = driver.get().findElement(By.xpath("//span[contains(text(),'Is he a ')]//parent::span//parent::div/following-sibling::div[2]/div")).getText();
					softAssert.assertEquals(MultiPetDogWorking, recordset.getField("MultiPetDogWorkingYesTextMessage_" + (numberOfMultiPetsInt - 1) + ""));
					softAssert.assertAll();
					TextToWrite = "Pet" + (numberOfMultiPetsInt) + " Working = Yes";
					utilities.Filewriter(TextToWrite);
				}
				else
				{
					WebElement dogWorkingNo=driver.get().findElement(By.xpath("//label[@for='is_working_dogNo']"));
					((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", dogWorkingNo);
					((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", dogWorkingNo);
			//driver.get().findElement(By.xpath("//*[@id='is_working_dog_No_" + numberOfMultiPetsInt + "']")).click();
					TextToWrite = "Pet" + (numberOfMultiPetsInt) + " Working = No";
					utilities.Filewriter(TextToWrite);
				}
			}
			/* 
			if (recordset.getField("MultiPetDogCatFromRescueHome_" + (numberOfMultiPetsInt - 1) + "").equalsIgnoreCase("Yes"))
			{
				WebElement dogCatFromRescueHomeYes=driver.get().findElement(By.xpath("//label[@for='rescue_homeYes']"));
				((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", dogCatFromRescueHomeYes);
				((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", dogCatFromRescueHomeYes);
			
				
			//	driver.get().findElement(By.xpath("//*[@id='rescue_home_Yes_" + numberOfMultiPetsInt + "']")).click();
				TextToWrite = "Pet" + (numberOfMultiPetsInt) + " From Rescue Home = Yes";
				utilities.Filewriter(TextToWrite);
			}
			else
			{
			  WebElement dogCatFromRescueHomeNo=driver.get().findElement(By.xpath("//label[@for='rescue_homeNo']"));
				((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", dogCatFromRescueHomeNo);
				((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", dogCatFromRescueHomeNo);
				
				//driver.get().findElement(By.xpath("//*[@id='rescue_home_No_" + numberOfMultiPetsInt + "']")).click();
				TextToWrite = "Pet" + (numberOfMultiPetsInt) + " From Rescue Home = No";
				utilities.Filewriter(TextToWrite);
			}
			*/

			if (recordset.getField("MultiPetDogCatAddressSameAsPolicyHolder_" + (numberOfMultiPetsInt - 1) + "").equalsIgnoreCase("Yes"))
			{
				WebElement dogCatAddressSameAsPolicyHolderYes=driver.get().findElement(By.xpath("//label[@for = 'pet_reside_same_addressYes']"));
				((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", dogCatAddressSameAsPolicyHolderYes);
				((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", dogCatAddressSameAsPolicyHolderYes);
			
				
			//	driver.get().findElement(By.xpath("//*[@id='pet_reside_same_address_Yes_" + numberOfMultiPetsInt + "']")).click();
				TextToWrite = "Pet" + (numberOfMultiPetsInt) + " Lives With Policy Holder = Yes";
				utilities.Filewriter(TextToWrite);
			}
			else
			{
				WebElement dogCatAddressSameAsPolicyHolderNo=driver.get().findElement(By.xpath("//label[@for = 'pet_reside_same_addressNo']"));
				((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", dogCatAddressSameAsPolicyHolderNo);
				((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", dogCatAddressSameAsPolicyHolderNo);
			
				//driver.get().findElement(By.xpath("//*[@id='pet_reside_same_address_No_" + numberOfMultiPetsInt + "']")).click();
				String MultiPetDogAddressSameAsPolicyHolderNoTextMessage = driver.get().findElement(By.xpath("//span[contains(text(),' permanently?')]//parent::span//parent::div/following-sibling::div[2]/div")).getText();
				softAssert.assertEquals(MultiPetDogAddressSameAsPolicyHolderNoTextMessage, recordset.getField("MultiPetDogAddressSameAsPolicyHolderNoTextMessage_" + (numberOfMultiPetsInt - 1) + ""));
				softAssert.assertAll();
				TextToWrite = "Pet" + (numberOfMultiPetsInt) + " Lives With Policy Holder = No";
				utilities.Filewriter(TextToWrite);
			}

			if (recordset.getField("MultiPetDogCatVeterinaryNeeds_" + (numberOfMultiPetsInt - 1) + "").equalsIgnoreCase("Yes"))
			{
				WebElement dogCatVeterinaryNeedsYes=driver.get().findElement(By.xpath("//label[@for='iddYes']"));
				((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", dogCatVeterinaryNeedsYes);
				((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", dogCatVeterinaryNeedsYes);
			
				TextToWrite = "Pet" + (numberOfMultiPetsInt) + " Veterinary Needs = Yes";
				utilities.Filewriter(TextToWrite);
			}
			else
			{	
				WebElement dogCatVeterinaryNeedsNo=driver.get().findElement(By.xpath("//label[@for='iddNo']"));
				((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", dogCatVeterinaryNeedsNo);
				((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", dogCatVeterinaryNeedsNo);
				String MultiPetDogVeterinaryNeedsNoTextMessage = driver.get().findElement(By.xpath("//span[contains(text(),'re you looking for a policy ')]//parent::span//parent::div/following-sibling::div[2]/div")).getText();
				
				softAssert.assertEquals(MultiPetDogVeterinaryNeedsNoTextMessage, recordset.getField("MultiPetDogVeterinaryNeedsNoTextMessage_" + (numberOfMultiPetsInt - 1) + ""));
				softAssert.assertAll();
				TextToWrite = "Pet" + (numberOfMultiPetsInt) + " Veterinary Needs = No";
				utilities.Filewriter(TextToWrite);
			}

			if (recordset.getField("MultiPetType_" + (numberOfMultiPetsInt - 1) + "").equalsIgnoreCase("Dog"))
			{
				if (recordset.getField("MultiPetDogAlchoholSoldPremises_" + (numberOfMultiPetsInt - 1) + "").equalsIgnoreCase("Yes"))
				{
					
					WebElement dogAlchoholSoldPremisesYes=driver.get().findElement(By.xpath("//label[@for = 'licensed_premisesYes']"));
					((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", dogAlchoholSoldPremisesYes);
					((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", dogAlchoholSoldPremisesYes);
					String MultiPetDogAlchoholSoldPremisesYesTextMessage = driver.get().findElement(By.xpath("//span[contains(text(),'Do you or family members take')]//parent::span//parent::div/following-sibling::div[2]")).getText();
				
					softAssert.assertEquals(MultiPetDogAlchoholSoldPremisesYesTextMessage, recordset.getField("MultiPetDogAlchoholSoldPremisesYesTextMessage_" + (numberOfMultiPetsInt - 1) + ""));
					softAssert.assertAll();
					TextToWrite = "Pet" + (numberOfMultiPetsInt) + " From Alchohol Sold Premises = Yes";
					utilities.Filewriter(TextToWrite);
				}
				else
				{
					WebElement dogAlchoholSoldPremisesNo=driver.get().findElement(By.xpath("//label[@for = 'licensed_premisesNo']"));
					((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", dogAlchoholSoldPremisesNo);
					((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", dogAlchoholSoldPremisesNo);
					TextToWrite = "Pet" + (numberOfMultiPetsInt) + " From Alchohol Sold Premises = No";
					utilities.Filewriter(TextToWrite);
				}

				if (recordset.getField("MultiPetDogBadBehaviour_" + (numberOfMultiPetsInt - 1) + "").equalsIgnoreCase("Yes"))
				{
					
				WebElement dogBadBehaviourYes=driver.get().findElement(By.xpath("//label[@for='dog_behaviourYes']"));
					((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", dogBadBehaviourYes);
					((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", dogBadBehaviourYes);
					String MultiPetDogBadBehaviourYesTextMessage = driver.get().findElement(By.xpath("//span[text()='Has anyone ever ']//parent::span//parent::div/following-sibling::div[2]")).getText();
					softAssert.assertEquals(MultiPetDogBadBehaviourYesTextMessage, recordset.getField("MultiPetDogBadBehaviourYesTextMessage_" + (numberOfMultiPetsInt - 1) + ""));
					softAssert.assertAll();
					TextToWrite = "Pet" + (numberOfMultiPetsInt) + " Bad Behaviour = Yes";
					utilities.Filewriter(TextToWrite);
				}
				else
				{
					WebElement dogBadBehaviourNo=driver.get().findElement(By.xpath("//label[@for='dog_behaviourNo']"));
					((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", dogBadBehaviourNo);
					((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", dogBadBehaviourNo);
			
			//		driver.get().findElement(By.xpath("//*[@id='dog_behaviour_No_" + numberOfMultiPetsInt + "']")).click();
					TextToWrite = "Pet" + (numberOfMultiPetsInt - 1) + " Bad Behaviour = No";
					utilities.Filewriter(TextToWrite);
				}
			}
			((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//button[text()='Save and close']")));
			((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//button[text()='Save and close']")));
		}
		else
		{
			((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//*[@for='pet"+numberOfMultiPetsInt+".confirm_assumptions']")));
			Thread.sleep(700);
			driver.get().findElement(By.xpath("//*[@for='pet"+numberOfMultiPetsInt+".confirm_assumptions']")).click();
			
		}
	//	driver.get().findElement(By.xpath("//div[text()='Next']//parent::button")).click();
//		((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//div[text()='Save and close']")));
//		((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//div[text()='Save and close']")));
				
		
//		((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//form[@id='editAssumptions']/button[@type='submit']")));
//((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//form[@id='editAssumptions']/button[@type='submit']")));
		dbConnectionCommonCode.closeConnection();
	}	
}