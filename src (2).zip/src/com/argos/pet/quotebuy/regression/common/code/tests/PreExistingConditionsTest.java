/**
 * 
 */
package com.argos.pet.quotebuy.regression.common.code.tests;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Parameters;

import com.argos.pet.quotebuy.regression.common.code.dbconnection.DBConnectionRegressionCommonCode;
import com.argos.pet.quotebuy.regression.common.code.pages.PreExistingConditionsPage;
import com.argos.pet.quotebuy.regression.common.code.utilities.TestBase;
import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;
import com.codoid.products.fillo.Recordset;


/**
 * @author d23747
 *
 */
public class PreExistingConditionsTest extends TestBase {

	PreExistingConditionsPage preExistingConditionsPage;
	DBConnectionRegressionCommonCode dbConnectionCommonCode;
	Utilities utilities;
	String className;
	Actions actions;
	public String TextToWrite;
	public String ClassName;

	@Parameters ("ClassName")
	public void testPreExistingConditions(String ClassName) throws Exception
	{
		preExistingConditionsPage = new PreExistingConditionsPage(driver);
		dbConnectionCommonCode = new DBConnectionRegressionCommonCode();
		utilities = new Utilities();
		actions = new Actions(driver.get());
		className = utilities.getClassName(ClassName);
		String strQuery = "Select * from PreExistingConditions where TestClassName = '" + className + "'";
		Recordset recordset = dbConnectionCommonCode.recordset(strQuery);
		recordset.next();
		recordset.moveFirst();
		preExistingConditionsPage.setPreExistingInjuryDetails(recordset.getField("PreExistingInjuryDetails"));
		preExistingConditionsPage.setVetPostCodeTextField(recordset.getField("VetPostCode"));
		preExistingConditionsPage.clickVetPostCodeSerchButton();
		WebDriverWait wait = new WebDriverWait(driver.get(),10);

		wait.until(new ExpectedCondition<Boolean>() {
		    public Boolean apply(WebDriver driver) {
		        WebElement button = driver.findElement(By.id("pageLoadingCoverAnimation"));
		        String enabled = button.getAttribute("class");
		        if(enabled.equals("hide")) 
		            return true;
		        else
		            return false;
		    }
		});
		boolean addressError=driver.get().findElements(By.xpath("//div[@class='checkbox-title']")).size()>0;
		
		if(addressError){
			preExistingConditionsPage.setVetPostCodeTextField(recordset.getField("VetPostCodeValid"));
			preExistingConditionsPage.clickVetPostCodeSerchButton();
			wait.until(new ExpectedCondition<Boolean>() {
			    public Boolean apply(WebDriver driver) {
			        WebElement button = driver.findElement(By.id("pageLoadingCoverAnimation"));
			        String enabled = button.getAttribute("class");
			        if(enabled.equals("hide")) 
			            return true;
			        else
			            return false;
			    }
			});
		//	if (driver.findElement(By.xpath("//*[@id='vetSearchError']/p")).getText().equalsIgnoreCase(recordset.getField("VetPostCodeNotFound")))
			boolean addressError1=driver.get().findElements(By.xpath("//div[@class='checkbox-title']")).size()>0;
			
			if(addressError1){
			
			//if (driver.findElement(By.xpath("//div[@class='checkbox-title']")).getText().equalsIgnoreCase("Can't find your vet?"))
			//	{
				Thread.sleep(1500);
				preExistingConditionsPage.clickProvideVetDetailsLaterTickBox();
				preExistingConditionsPage.clickSaveCloseButton();
				TextToWrite = "Vet Post Code Not Found Hence Details To Be Provided Later";
				utilities.Filewriter(TextToWrite);
			}
			//}
			else
			{
				Thread.sleep(1500);
				Actions builder = new Actions(driver.get());
				driver.get().switchTo().activeElement().sendKeys(Keys.TAB);
				Thread.sleep(1000);
				driver.get().switchTo().activeElement().sendKeys(Keys.ENTER);	
				Thread.sleep(1000);
				builder.sendKeys(Keys.ARROW_DOWN).build().perform();
					Thread.sleep(1000);
					builder.sendKeys(Keys.ARROW_DOWN).build().perform();
						Thread.sleep(1000);
						builder.sendKeys(Keys.ENTER).build().perform();
						
				preExistingConditionsPage.clickSaveCloseButton();
				TextToWrite = "Pet 1 Pre Existing Injury: " + recordset.getField("PreExistingInjuryDetails") + " Vet Post Code: " + recordset.getField("VetPostCode");
				utilities.Filewriter(TextToWrite);
			}
		//}
		}
		else
		{
			Thread.sleep(1500);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//div[@id='vet_selector']")));
			Actions builder = new Actions(driver.get());
			driver.get().switchTo().activeElement().sendKeys(Keys.TAB);
			Thread.sleep(1000);
			driver.get().switchTo().activeElement().sendKeys(Keys.ENTER);	
			Thread.sleep(1000);
			builder.sendKeys(Keys.ARROW_DOWN).build().perform();
				Thread.sleep(1000);
				builder.sendKeys(Keys.ARROW_DOWN).build().perform();
					Thread.sleep(1000);
					builder.sendKeys(Keys.ENTER).build().perform();
			
			
			preExistingConditionsPage.clickSaveCloseButton();
			TextToWrite = "Pet 1 Pre Existing Injury: " + recordset.getField("PreExistingInjuryDetails") + " Vet Post Code: " + recordset.getField("VetPostCode");
			utilities.Filewriter(TextToWrite);
		}
		dbConnectionCommonCode.closeConnection();
	}
}
