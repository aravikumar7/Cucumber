package com.argos.pet.quotebuy.regression.common.code.utilities;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.BufferedInputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Calendar;
import java.util.Date;
import java.util.Formatter;

import javax.imageio.ImageIO;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.asserts.SoftAssert;

import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.Screenshot;
import ru.yandex.qatools.ashot.shooting.ShootingStrategies;

import com.argos.pet.quotebuy.regression.common.code.dbconnection.DBConnectionRegressionCommonCode;
import com.argos.pet.quotebuy.regression.common.code.tests.CustomerDetailsTest;
import com.argos.pet.quotebuy.regression.common.code.tests.YourPetDetailsTest;
import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Recordset;


public class Utilities {

	ReadConfig readConfig;
	TestBase testBase;
	DBConnectionRegressionCommonCode dbConnectionCommonCode;
	Utilities utilities;
	SoftAssert softAssert;
	public String TestEnvName;
	public String FilePath;
	public String TextToWrite = null;
	DateFormat dateFormat = new SimpleDateFormat("ddMMyyyy_HHmmss");
	DateFormat dateFormat2 = new SimpleDateFormat("ddMMyyyy");
	Calendar cal = Calendar.getInstance();
	String date = dateFormat2.format(cal.getTime());
	String[] dateArray;
	String[] dobArray;
	String[] uniqueTestDataArray;
	String[] multiPetUniqueTestDataArray;
	String[] regressionTestDataArray;
	public String className;
	public String PetType;
	public String TypeOfPet;
	public String Risk;
	public String HighRiskReason;
	public String ClassName;
	public String[] editCoverArray;
	public String path;
	
	public boolean isElementPresent(By by, ThreadLocal<WebDriver> driver) {
		try 
		{
			driver.get().findElement(by);
			return true;
		}
		catch (NoSuchElementException e)
		{
			return false;
		}
	}

	public String Filewriter(String TextToWrite) throws Exception
	{
		try
		{
			readConfig = new ReadConfig();
			TestEnvName = readConfig.getTestEnvironmentName();
			FilePath = readConfig.getTestResultFilePath() + TestEnvName + ".txt";
			File file = new File(FilePath);
			if (!file.exists())
			{
				file.createNewFile();
			}
			FileWriter fw = new FileWriter(file.getAbsoluteFile(), true);
			BufferedWriter bw = new BufferedWriter(fw);
			bw.newLine();

			//TextToWrite = TextToWrite + " Environment: " + TestEnvName;
			bw.write(TextToWrite);
			bw.close();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return FilePath;
	}
	
	public String shortFilewriter(String TextToWrite) throws Exception
	{
		try
		{
			readConfig = new ReadConfig();
			TestEnvName = readConfig.getTestEnvironmentName();
			FilePath = readConfig.getTestResultFilePath() + TestEnvName + "_shortFile.csv";
			File file = new File(FilePath);
			if (!file.exists())
			{
				file.createNewFile();
			}
			FileWriter fw = new FileWriter(file.getAbsoluteFile(), true);
			BufferedWriter bw = new BufferedWriter(fw);
			bw.newLine();

			bw.write(TextToWrite);
			bw.close();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return FilePath;
	}

	// Takes pass transaction screen shot
	public void TakePassScreenShot(WebDriver driver, String testName) throws Exception
	{
		try
		{
			readConfig = new ReadConfig();
		/*	String TestEnvName = readConfig.getTestEnvironmentName();
			String PassScreenshotPath = readConfig.getScreenshotPath() + date + "/" + TestEnvName + "/Pass/";
			File ScreenshotFile = new File(PassScreenshotPath + testName + "_" + "Pass_" + dateFormat.format(cal.getTime()) + ".jpeg");
			PassScreenshotPath = ScreenshotFile.getAbsolutePath();
			File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(scrFile, new File(PassScreenshotPath));*/
			String TestEnvName = readConfig.getTestEnvironmentName();
			File file=new File(System.getProperty("user.dir") + "/Screenshots/"+date+"/" +TestEnvName+"/Pass");
			if(!file.exists()){
				try{
					file.mkdirs();
				}
				catch(SecurityException se){
					System.out.println("Error");
				}
			}
			Screenshot fpScreenshot = new AShot().shootingStrategy(ShootingStrategies.viewportPasting(1000)).takeScreenshot(driver);
			String PassScreenshotPath=System.getProperty("user.dir") + "/Screenshots/"+date+"/" +TestEnvName+"/Pass/"+testName +  "_" + "Pass_" + dateFormat.format(cal.getTime()) + ".jpeg";
			ImageIO.write(fpScreenshot.getImage(),"JPEG",new File(PassScreenshotPath));
			
			
		
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	// Takes fail transaction screen shot
	public String TakeFailScreenShot(WebDriver driver, String testName) throws Exception
	{
		readConfig = new ReadConfig();
		/*String TestEnvName = readConfig.getTestEnvironmentName();
		String FailScreenshotPath = readConfig.getScreenshotPath() + date + "/" + TestEnvName + "/Fail/";
		File ScreenshotFile = new File(FailScreenshotPath + testName + "_" + "Fail_" + dateFormat.format(cal.getTime()) + ".jpeg");
		FailScreenshotPath = ScreenshotFile.getAbsolutePath();
		File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(scrFile, new File(FailScreenshotPath));*/
		String TestEnvName = readConfig.getTestEnvironmentName();
		File file=new File(System.getProperty("user.dir") + "/Screenshots/"+date+"/" +TestEnvName+"/Fail");
		if(!file.exists()){
			try{
				file.mkdirs();
			}
			catch(SecurityException se){
				System.out.println("Error");
			}
		}
		Screenshot fpScreenshot = new AShot().shootingStrategy(ShootingStrategies.viewportPasting(1000)).takeScreenshot(driver);
		String FailScreenshotPath=System.getProperty("user.dir") + "/Screenshots/"+date+"/" +TestEnvName+"/Fail/"+testName + "_" + "Fail_" + dateFormat.format(cal.getTime()) + ".jpeg";
		ImageIO.write(fpScreenshot.getImage(),"JPEG",new File(FailScreenshotPath));
		
		return FailScreenshotPath;
	}

	public Wait<WebDriver> waitElement(WebElement eleWebElement, ThreadLocal<WebDriver> driver) throws InterruptedException
	{
		//WebDriverWait wait = new WebDriverWait(driver, 20);
		//Wait<WebDriver> waiting = new FluentWait<WebDriver>(driver).
			//	withTimeout(20, TimeUnit.SECONDS).
				//pollingEvery(5, TimeUnit.SECONDS).ignoring(NoSuchElementException.class);
		//waiting.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id='breedDogType_1']"))));
		
		Wait<WebDriver> wait = new FluentWait<WebDriver>(driver.get()).withTimeout(Duration.ofSeconds(20))
		        .pollingEvery(Duration.ofMillis(600)).ignoring(NoSuchElementException.class);
		wait.until(ExpectedConditions.visibilityOf(eleWebElement));
		return wait;
	}

	public void actionWaitClick(WebDriver driver, WebElement actionWebElement)
	{
		Actions actions = new Actions(driver);
		WebDriverWait wait = new WebDriverWait(driver, 15);
		actionWebElement = wait.until(ExpectedConditions.visibilityOf(actionWebElement));
		actions.click(actionWebElement).build();
	}

	public void actionPopulate(WebDriver driver, WebElement actionWebElement, String stringToPopulate) throws InterruptedException
	{
		Actions actions = new Actions(driver);
		WebDriverWait wait1 = new WebDriverWait(driver, 10);
		WebElement elementBreed = wait1.until(ExpectedConditions.elementToBeClickable(actionWebElement));
		//actions.sendKeys(elementBreed, stringToPopulate).perform();
		actions.sendKeys(stringToPopulate).perform();
/*		actions.sendKeys(elementBreed, "Af").perform();
		Thread.sleep(3000);
		actions.sendKeys(elementBreed,Keys.ARROW_DOWN).perform();
		Thread.sleep(3000);
		actions.sendKeys(elementBreed,Keys.ARROW_DOWN).perform();
		Thread.sleep(3000);
		actions.click().perform();
		Thread.sleep(3000);
		actions.sendKeys(elementBreed,Keys.TAB).perform();
*/		//actions.sendKeys("Af").perform();
		
		//actions.sendKeys(Keys.ARROW_DOWN).perform();
	//	Thread.sleep(5000);
		//actions.sendKeys(Keys.ARROW_DOWN).perform();
		//Thread.sleep(5000);
		//actions.click().perform();
		
	}

	public void actionClick(WebDriver driver, WebElement actionWebElement)
	{
		Actions actions = new Actions(driver);
		actions.click(actionWebElement).build().perform();
	}

	public String getCoverStartDate(String CoverStartDate_NumberOfDaysInFuture) throws FilloException
	{
		int coverStartDate = 0;

		if (!(CoverStartDate_NumberOfDaysInFuture == null))
		{
			coverStartDate = Integer.parseInt(CoverStartDate_NumberOfDaysInFuture);
		}
		else
		{
			CoverStartDate_NumberOfDaysInFuture = "7";
		}

		cal.add(Calendar.DAY_OF_MONTH, coverStartDate);
		SimpleDateFormat sdf = new SimpleDateFormat("MMMM d, yyyy");
		String newDate = sdf.format(cal.getTime());
		return newDate;
	}

	public String[] getDOB(String DOB_FromCoverStartDate) throws FilloException, FileNotFoundException
	{
		int dob_FromCoverStartDate = 0;
		if (!(DOB_FromCoverStartDate == null))
		{
			dob_FromCoverStartDate = Integer.parseInt(DOB_FromCoverStartDate);
		}
		else
		{
			DOB_FromCoverStartDate = "-90";
		}

		
		cal.add(Calendar.DATE, dob_FromCoverStartDate);
		int DOB_Days = cal.get(Calendar.DAY_OF_MONTH);
		String DOB_Day = String.valueOf(DOB_Days);
		int DOB_Day_Length = DOB_Day.length();
		if (DOB_Day_Length == 1)
		{
	        String leftPaddedDOB_Day = StringUtils.leftPad("" + DOB_Day, 2, "0");
	        DOB_Day = leftPaddedDOB_Day;
		}
	
		int DOB_Months = cal.get(Calendar.MONTH)+1;
		String DOB_Month = String.valueOf(DOB_Months);
		int DOB_Month_Length = DOB_Month.length();
		if (DOB_Month_Length == 1)
		{
	        String leftPaddedDOB_Month = StringUtils.leftPad("" + DOB_Month, 2, "0");
	        DOB_Month = leftPaddedDOB_Month;
		}
	
		int DOB_Years = cal.get(Calendar.YEAR);
		String DOB_Year = String.valueOf(DOB_Years);

		dobArray = new String[3];
		dobArray[0] = DOB_Day;
		dobArray[1] = DOB_Month;
		dobArray[2] = DOB_Year;
		cal.add(Calendar.DATE, -dob_FromCoverStartDate);
		return dobArray;
	}
	
	
	public String[] getUniqueTestData() throws FilloException, IOException
	{
		dbConnectionCommonCode = new DBConnectionRegressionCommonCode();
		String randomString = RandomStringUtils.randomNumeric(3);
		int randomInt = Integer.valueOf(randomString);
		String stringRandomQuery = "Select * from UniqueData where ID = " + randomInt + "";
		Recordset recordset = dbConnectionCommonCode.recordset(stringRandomQuery);
		recordset.next();
		recordset.moveFirst();
		
		uniqueTestDataArray = new String[18];
		uniqueTestDataArray[0] = recordset.getField("PetFullName");
		uniqueTestDataArray[1] = recordset.getField("DogBreedType");
		uniqueTestDataArray[2] = recordset.getField("DogCrossBreedType");
		uniqueTestDataArray[3] = recordset.getField("DogSize");
		uniqueTestDataArray[4] = recordset.getField("CatBreed");
		uniqueTestDataArray[5] = recordset.getField("DOB_FromCoverStartDate");
		uniqueTestDataArray[6] = recordset.getField("CustomerFirstName");
		uniqueTestDataArray[7] = recordset.getField("CustomerLastName");
		uniqueTestDataArray[8] = recordset.getField("CustomerDOBDay");
		uniqueTestDataArray[9] = recordset.getField("CustomerDOBMonth");
		uniqueTestDataArray[10] = recordset.getField("CustomerDOBYear");
		uniqueTestDataArray[11] = recordset.getField("HouseNumberName");
		uniqueTestDataArray[12] = recordset.getField("Postcode");
		uniqueTestDataArray[13] = recordset.getField("Title");
		uniqueTestDataArray[14] = recordset.getField("Email");
		uniqueTestDataArray[15] = recordset.getField("CoverStartDate");
		uniqueTestDataArray[16] = recordset.getField("CoverStartDate_NumberOfDaysInFuture");
		uniqueTestDataArray[17] = recordset.getField("RabbitBreed");
		dbConnectionCommonCode.closeConnection();
		return uniqueTestDataArray;
	}
	
	public String getNextMonth()
	{
		Formatter formatter;
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.MONTH, 1);
		formatter = new Formatter();
		formatter.format("%tB", cal);
		String nextMonth = formatter.toString();
		formatter.close();
		return nextMonth;
	}
	
	@Parameters ("ClassName")
	public String getClassName(String ClassName) throws Exception
	{
		if (ClassName.equalsIgnoreCase("TC007_QuoteJourney_DogBreed_Test"))
		{
			className = "TC007_QuoteJourney_DogBreed_Test";
		}
		else if (ClassName.equalsIgnoreCase("TC002_QuoteJourney_DogCrossBreed_Test"))
		{
			className = "TC002_QuoteJourney_DogCrossBreed_Test";
		}
		else if (ClassName.equalsIgnoreCase("TC003_QuoteJourney_DogSmallMongrel_Test"))
		{
			className = "TC003_QuoteJourney_DogSmallMongrel_Test";
		}
		else if (ClassName.equalsIgnoreCase("TC004_QuoteJourney_DogMediumMongrel_Test"))
		{
			className = "TC004_QuoteJourney_DogMediumMongrel_Test";
		}
		else if (ClassName.equalsIgnoreCase("TC005_QuoteJourney_DogLargeMongrel_Test"))
		{
			className = "TC005_QuoteJourney_DogLargeMongrel_Test";
		}
		else if (ClassName.equalsIgnoreCase("TC006_QuoteJourney_CatBreed_Test"))
		{
			className = "TC006_QuoteJourney_CatBreed_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_227_ValidateCoverStartDate_Test"))
		{
			className = "TEST_227_ValidateCoverStartDate_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_209_ValidateCustomerAgeValidation_Test"))
		{
			className = "TEST_209_ValidateCustomerAgeValidation_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_209_ValidateCustomerAgeValidation_2_Test"))
		{
			className = "TEST_209_ValidateCustomerAgeValidation_2_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_209_ValidateCustomerAgeValidation_3_Test"))
		{
			className = "TEST_209_ValidateCustomerAgeValidation_3_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_209_ValidateCustomerAgeValidation_4_Test"))
		{
			className = "TEST_209_ValidateCustomerAgeValidation_4_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_209_ValidateCustomerAgeValidation_5_Test"))
		{
			className = "TEST_209_ValidateCustomerAgeValidation_5_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_785_ValidateChangeAssumptionsForMultipet_Test"))
		{
			className = "TEST_785_ValidateChangeAssumptionsForMultipet_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_473_ValidateCostOfPet_Test"))
		{
			className = "TEST_473_ValidateCostOfPet_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_137_ValidateTypeOfDogQuestionIsMandatory_Test"))
		{
			className = "TEST_137_ValidateTypeOfDogQuestionIsMandatory_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_145_ValidateSizeOfMongrelIsMandatory_Test"))
		{
			className = "TEST_145_ValidateSizeOfMongrelIsMandatory_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_146_ValidateDOBQuestionForDogs_Test"))
		{
			className = "TEST_146_ValidateDOBQuestionForDogs_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_147_ValidateDOBIsMandatoryForDogs_Test"))
		{
			className = "TEST_147_ValidateDOBIsMandatoryForDogs_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_149_ValidateDogSexFieldIsMandatory_Test"))
		{
			className = "TEST_149_ValidateDogSexFieldIsMandatory_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_151_ValidateCatNameIsMandatory_Test"))
		{
			className = "TEST_151_ValidateCatNameIsMandatory_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_152_ValidateCatNameInputFormattingRestrictions_Test"))
		{
			className = "TEST_152_ValidateCatNameInputFormattingRestrictions_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_152_ValidateCatNameInputFormattingRestrictions_2_Test"))
		{
			className = "TEST_152_ValidateCatNameInputFormattingRestrictions_2_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_152_ValidateCatNameInputFormattingRestrictions_3_Test"))
		{
			className = "TEST_152_ValidateCatNameInputFormattingRestrictions_3_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_152_ValidateCatNameInputFormattingRestrictions_4_Test"))
		{
			className = "TEST_152_ValidateCatNameInputFormattingRestrictions_4_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_152_ValidateCatNameInputFormattingRestrictions_5_Test"))
		{
			className = "TEST_152_ValidateCatNameInputFormattingRestrictions_5_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_152_ValidateCatNameInputFormattingRestrictions_6_Test"))
		{
			className = "TEST_152_ValidateCatNameInputFormattingRestrictions_6_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_152_ValidateCatNameInputFormattingRestrictions_7_Test"))
		{
			className = "TEST_152_ValidateCatNameInputFormattingRestrictions_7_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_154_ValidateCatBreedIsMandatory_Test"))
		{
			className = "TEST_154_ValidateCatBreedIsMandatory_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_156_ValidateDOBIsMandatoryForCats_Test"))
		{
			className = "TEST_156_ValidateDOBIsMandatoryForCats_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_158_ValidateCatSexFieldIsMandatory_Test"))
		{
			className = "TEST_158_ValidateCatSexFieldIsMandatory_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_165_ValidateAgeValidationForNonSelectedBreedDogs_Test"))
		{
			className = "TEST_165_ValidateAgeValidationForNonSelectedBreedDogs_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_165_ValidateAgeValidationForNonSelectedBreedDogs_2_Test"))
		{
			className = "TEST_165_ValidateAgeValidationForNonSelectedBreedDogs_2_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_165_ValidateAgeValidationForNonSelectedBreedDogs_3_Test"))
		{
			className = "TEST_165_ValidateAgeValidationForNonSelectedBreedDogs_3_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_165_ValidateAgeValidationForNonSelectedBreedDogs_4_Test"))
		{
			className = "TEST_165_ValidateAgeValidationForNonSelectedBreedDogs_4_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_165_ValidateAgeValidationForNonSelectedBreedDogs_5_Test"))
		{
			className = "TEST_165_ValidateAgeValidationForNonSelectedBreedDogs_5_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_166_ValidateAgeValidationForSelectedBreedDogs_Test"))
		{
			className = "TEST_166_ValidateAgeValidationForSelectedBreedDogs_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_166_ValidateAgeValidationForSelectedBreedDogs_2_Test"))
		{
			className = "TEST_166_ValidateAgeValidationForSelectedBreedDogs_2_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_166_ValidateAgeValidationForSelectedBreedDogs_3_Test"))
		{
			className = "TEST_166_ValidateAgeValidationForSelectedBreedDogs_3_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_166_ValidateAgeValidationForSelectedBreedDogs_4_Test"))
		{
			className = "TEST_166_ValidateAgeValidationForSelectedBreedDogs_4_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_166_ValidateAgeValidationForSelectedBreedDogs_5_Test"))
		{
			className = "TEST_166_ValidateAgeValidationForSelectedBreedDogs_5_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_167_ValidateAgeValidationForNonSelectedCrossbreedDogs_Test"))
		{
			className = "TEST_167_ValidateAgeValidationForNonSelectedCrossbreedDogs_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_167_ValidateAgeValidationForNonSelectedCrossbreedDogs_2_Test"))
		{
			className = "TEST_167_ValidateAgeValidationForNonSelectedCrossbreedDogs_2_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_167_ValidateAgeValidationForNonSelectedCrossbreedDogs_3_Test"))
		{
			className = "TEST_167_ValidateAgeValidationForNonSelectedCrossbreedDogs_3_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_167_ValidateAgeValidationForNonSelectedCrossbreedDogs_4_Test"))
		{
			className = "TEST_167_ValidateAgeValidationForNonSelectedCrossbreedDogs_4_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_168_ValidateAgeValidationForSelectedCrossbreedDogs_Test"))
		{
			className = "TEST_168_ValidateAgeValidationForSelectedCrossbreedDogs_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_168_ValidateAgeValidationForSelectedCrossbreedDogs_2_Test"))
		{
			className = "TEST_168_ValidateAgeValidationForSelectedCrossbreedDogs_2_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_168_ValidateAgeValidationForSelectedCrossbreedDogs_3_Test"))
		{
			className = "TEST_168_ValidateAgeValidationForSelectedCrossbreedDogs_3_Test";
		}
		
		else if (ClassName.equalsIgnoreCase("TEST_129_SmokeTestingPetDetails"))
		{
			className = "TEST_129_SmokeTestingPetDetails";
		}
		else if (ClassName.equalsIgnoreCase("TEST_131_ValidateTypeOfPetIsMandatory_Test"))
		{
			className = "TEST_131_ValidateTypeOfPetIsMandatory_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_134_ValidateDogNameIsMandatory_Test"))
		{
			className = "TEST_134_ValidateDogNameIsMandatory_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_139_ValidateTypeOfBreedQuestionIsMandatory_Test"))
		{
			className = "TEST_139_ValidateTypeOfBreedQuestionIsMandatory_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_140_ValidateIneligibleBreed_Test"))
		{
			className = "TEST_140_ValidateIneligibleBreed_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_142_ValidateTypeOfCrossBreedQuestionIsMandatory_Test"))
		{
			className = "TEST_142_ValidateTypeOfCrossBreedQuestionIsMandatory_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_143_ValidateIneligibleCrossbreedSelection_Test"))
		{
			className = "TEST_143_ValidateIneligibleCrossbreedSelection_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_185_SmokeTestingCustomerDetails_Test"))
		{
			className = "TEST_185_SmokeTestingCustomerDetails_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_188_ValidateCustomerTitleIsMandatory_Test"))
		{
			className = "TEST_188_ValidateCustomerTitleIsMandatory_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_200_ValidateCustomerNameIsMandatory_Test"))
		{
			className = "TEST_200_ValidateCustomerNameIsMandatory_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_203_ValidateCustomerLastNameIsMandatory_Test"))
		{
			className = "TEST_203_ValidateCustomerLastNameIsMandatory_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_207_ValidateCustomerDOBIsMandatory_Test"))
		{
			className = "TEST_207_ValidateCustomerDOBIsMandatory_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_211_ValidateCustomerEmailIsMandatory_Test"))
		{
			className = "TEST_211_ValidateCustomerEmailIsMandatory_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_219_ValidateCustomerPostCodeIsMandatory_Test"))
		{
			className = "TEST_219_ValidateCustomerPostCodeIsMandatory_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_220_ValidateCustomerPostCodeValidaton_1_Test"))
		{
			className = "TEST_220_ValidateCustomerPostCodeValidaton_1_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_220_ValidateCustomerPostCodeValidaton_2_Test"))
		{
			className = "TEST_220_ValidateCustomerPostCodeValidaton_2_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_220_ValidateCustomerPostCodeValidaton_3_Test"))
		{
			className = "TEST_220_ValidateCustomerPostCodeValidaton_3_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_220_ValidateCustomerPostCodeValidaton_4_Test"))
		{
			className = "TEST_220_ValidateCustomerPostCodeValidaton_4_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_220_ValidateCustomerPostCodeValidaton_5_Test"))
		{
			className = "TEST_220_ValidateCustomerPostCodeValidaton_5_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_225_ValidateCoverStartDateToday_Test"))
		{
			className = "TEST_225_ValidateCoverStartDateToday_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_226_ValidateCoverStartDateTomorrow_Test"))
		{
			className = "TEST_226_ValidateCoverStartDateTomorrow_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_232_ValidateGetQuotePage_Test"))
		{
			className = "TEST_232_ValidateGetQuotePage_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_235_SmokeTestingQuoteSelectionPage_Test"))
		{
			className = "TEST_235_SmokeTestingQuoteSelectionPage_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_291_SmokeTestingMultipletDetails_Test"))
		{
			className = "TEST_291_SmokeTestingMultipletDetails_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_296_ValidateDogNameForMultipetIsMandatory_Test"))
		{
			className = "TEST_296_ValidateDogNameForMultipetIsMandatory_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_299_TypeOfDogMandatoryForMultiplet_Test"))
		{
			className = "TEST_299_TypeOfDogMandatoryForMultiplet_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_302_ValidateTypeOfBreedIsMandatoryFoMultipet_Test"))
		{
			className = "TEST_302_ValidateTypeOfBreedIsMandatoryFoMultipet_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_303_ValidateIneligibleBreedSelectionForMultipet_Test"))
		{
			className = "TEST_303_ValidateIneligibleBreedSelectionForMultipet_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_308_ValidateSizeOfMongrelIsMandatoryForMultipet_Test"))
		{
			className = "TEST_308_ValidateSizeOfMongrelIsMandatoryForMultipet_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_309_ValidateDOBForMultipet_Test"))
		{
			className = "TEST_309_ValidateDOBForMultipet_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_332_ValidateDOBIsMandatoryForMultipet_Test"))
		{
			className = "TEST_332_ValidateDOBIsMandatoryForMultipet_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_375_ValidateDogSexIsMandatoryForMultipet_Test"))
		{
			className = "TEST_375_ValidateDogSexIsMandatoryForMultipet_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_399_ValidateFinalConfirmationPage_Test"))
		{
			className = "TEST_399_ValidateFinalConfirmationPage_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_407_ValidateDeletePetButtonInPetDetailsSectionForMultipet_Test"))
		{
			className = "TEST_407_ValidateDeletePetButtonInPetDetailsSectionForMultipet_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_417_ValidateCustomerHouseNumberIsMandatory_Test"))
		{
			className = "TEST_417_ValidateCustomerHouseNumberIsMandatory_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_427_ValidatePromoCodeIsAccepted_Test"))
		{
			className = "TEST_427_ValidatePromoCodeIsAccepted_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_429_ValidateNectarPromoCodeIsAccepted_Test"))
		{
			className = "TEST_429_ValidateNectarPromoCodeIsAccepted_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_437_ValidateAllEligibleProductsDisplayed_Test"))
		{
			className = "TEST_437_ValidateAllEligibleProductsDisplayed_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_440_ValidateAllCoverSectionsAreDisplayed_TimeLimited_Test"))
		{
			className = "TEST_440_ValidateAllCoverSectionsAreDisplayed_TimeLimited_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_444_ValidateAllCoverSectionsAreDisplayed_LifeTime_Test"))
		{
			className = "TEST_444_ValidateAllCoverSectionsAreDisplayed_LifeTime_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_486_487_ValidatePremiumForMultipetDiscountsAppliedForMultipets_Test"))
		{
			className = "TEST_486_487_ValidatePremiumForMultipetDiscountsAppliedForMultipets_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_488_ValidateMultipetDiscountRemovedWhenPetsAreRemoved_Test"))
		{
			className = "TEST_488_ValidateMultipetDiscountRemovedWhenPetsAreRemoved_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_450_ValidatePriceBreakdownSectionAtBottomOfQuoteResultsPage_Test"))
		{
			className = "TEST_450_ValidatePriceBreakdownSectionAtBottomOfQuoteResultsPage_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_584_ValidateModifingfPetTypeModifiesQuoteValues_Test"))
		{
			className = "TEST_584_ValidateModifingfPetTypeModifiesQuoteValues_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_585_ValidateModifyingDogBreedToNonSelectedChangesQuoteResult_Test"))
		{
			className = "TEST_585_ValidateModifyingDogBreedToNonSelectedChangesQuoteResult_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_586_ValidateModifyingDogBreedToViciousChangesQuoteResult_Test"))
		{
			className = "TEST_586_ValidateModifyingDogBreedToViciousChangesQuoteResult_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_587_ValidateModifyingCatBreedChangesQuoteResult_Test"))
		{
			className = "TEST_587_ValidateModifyingCatBreedChangesQuoteResult_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_588_ValidateModifyingCatSexFromMaleToFemaleChangesQuoteResult_Test"))
		{
			className = "TEST_587_ValidateModifyingCatBreedChangesQuoteResult_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_589_ValidateModifyingCatSexFromFemaleToMaleChangesQuoteResult_Test"))
		{
			className = "TEST_589_ValidateModifyingCatSexFromFemaleToMaleChangesQuoteResult_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_590_ValidateModifyingDogSexFromMaleToFemaleChangesQuoteResult_Test"))
		{
			className = "TEST_590_ValidateModifyingDogSexFromMaleToFemaleChangesQuoteResult_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_591_ValidateModifyingDogSexFromFemaleToMaleChangesQuoteResult_Test"))
		{
			className = "TEST_591_ValidateModifyingDogSexFromFemaleToMaleChangesQuoteResult_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_592_ValidateModifyingDogNeuteredYesToNoChangesQuoteResult_Test"))
		{
			className = "TEST_592_ValidateModifyingDogNeuteredYesToNoChangesQuoteResult_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_593_ValidateModifyingDogNeuteredNoToYesChangesQuoteResult_Test"))
		{
			className = "TEST_593_ValidateModifyingDogNeuteredNoToYesChangesQuoteResult_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_594_ValidateModifyingCatNeuteredYesToNoChangesQuoteResult_Test"))
		{
			className = "TEST_594_ValidateModifyingCatNeuteredYesToNoChangesQuoteResult_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_595_ValidateModifyingCatNeuteredNoToYesChangesQuoteResult_Test"))
		{
			className = "TEST_595_ValidateModifyingCatNeuteredNoToYesChangesQuoteResult_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_598_ValidateContinueWithoutProductSelection_Test"))
		{
			className = "TEST_598_ValidateContinueWithoutProductSelection_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_618_ValidateModifyingCatPriceHigherToLowerChangesQuoteResult_Test"))
		{
			className = "TEST_618_ValidateModifyingCatPriceHigherToLowerChangesQuoteResult_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_619_ValidateModifyingCatPriceLowerToHigherChangesQuoteResult_Test"))
		{
			className = "TEST_619_ValidateModifyingCatPriceLowerToHigherChangesQuoteResult_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_620_ValidateModifyingDogPriceHigherToLowerChangesQuoteResult_Test"))
		{
			className = "TEST_620_ValidateModifyingDogPriceHigherToLowerChangesQuoteResult_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_622_ValidateModifyingDogPriceLowerToHigherChangesQuoteResult_Test"))
		{
			className = "TEST_622_ValidateModifyingDogPriceLowerToHigherChangesQuoteResult_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_643_SmokeTestReviewPage_Test"))
		{
			className = "TEST_643_SmokeTestReviewPage_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_650_ValidateRemovePetUnderPetDetailsForMultipet_Test"))
		{
			className = "TEST_650_ValidateRemovePetUnderPetDetailsForMultipet_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_215_ValidateCustomerPhoneNumberIsMandatory_Test"))
		{
			className = "TEST_215_ValidateCustomerPhoneNumberIsMandatory_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_489_ValidateMultipetDiscountAppliedForAlliancePolicy_Test"))
		{
			className = "TEST_489_ValidateMultipetDiscountAppliedForAlliancePolicy_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_674_ValidateMultipetDiscountAppliedForAlliancePolicy_Test"))
		{
			className = "TEST_674_ValidateMultipetDiscountAppliedForAlliancePolicy_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_678_ValidatePriceBreakdownInQuoteReview_Test"))
		{
			className = "TEST_678_ValidatePriceBreakdownInQuoteReview_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_694_ValidateSaveCloseButtonInQuoteReview_Test"))
		{
			className = "TEST_694_ValidateSaveCloseButtonInQuoteReview_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_719_ValidateUpdatedTypeOfDogInQuoteReview_Test"))
		{
			className = "TEST_719_ValidateUpdatedTypeOfDogInQuoteReview_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_720_ValidateUpdatedCatBreedInQuoteReview_Test"))
		{
			className = "TEST_720_ValidateUpdatedCatBreedInQuoteReview_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_733_ValidateChangeWhenPetDOBIsChangedInEditPetDetails_Test"))
		{
			className = "TEST_733_ValidateChangeWhenPetDOBIsChangedInEditPetDetails_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_715_ValidateSaveCloseButtonWhenAllDetailsAreBlankInEditPetDetails_Test"))
		{
			className = "TEST_715_ValidateSaveCloseButtonWhenAllDetailsAreBlankInEditPetDetails_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_717_ValidateCancelButtonInEditPetDetails_Test"))
		{
			className = "TEST_717_ValidateCancelButtonInEditPetDetails_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_813_814_821_ValidatePreMedicalInputBoxForHighRiskWithPreExisting_Test"))
		{
			className = "TEST_813_814_821_ValidatePreMedicalInputBoxForHighRiskWithPreExisting_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_816_ValidateFindVetButtonInAddVetForHighRiskWithPreExisting_Test"))
		{
			className = "TEST_816_ValidateFindVetButtonInAddVetForHighRiskWithPreExisting_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_818_ValidateHouseNumberIsManadatoryWithValidPostcode_Test"))
		{
			className = "TEST_818_ValidateHouseNumberIsManadatoryWithValidPostcode_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_767_ValidateAllFieldsInQuoteRetrieveAreMandatory_Test"))
		{
			className = "TEST_767_ValidateAllFieldsInQuoteRetrieveAreMandatory_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_768_ValidateQuoteSelectedForValidQuoteReferenceNumberEmailID_Test"))
		{
			className = "TEST_768_ValidateQuoteSelectedForValidQuoteReferenceNumberEmailID_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_777_ValidatePolicyPurchaseViaQuoteRetrieval_Test"))
		{
			className = "TEST_777_ValidatePolicyPurchaseViaQuoteRetrieval_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2091_SBCardholderLoyaltyScorePresentGetDoubleNectarpointsScoreBucket2_Test"))
		{
			className = "TEST_2091_SBCardholderLoyaltyScorePresentGetDoubleNectarpointsScoreBucket2_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2090_SBCardholderLoyaltyScorePresentGetDoubleNectarpointsScoreBucket1_Test"))
		{
			className = "TEST_2090_SBCardholderLoyaltyScorePresentGetDoubleNectarpointsScoreBucket1_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2091_SBCardholderLoyaltyScorePresentGetDoubleNectarpointsScoreBucket2_Test"))
		{
			className = "TEST_2091_SBCardholderLoyaltyScorePresentGetDoubleNectarpointsScoreBucket2_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2092_SBCardholderLoyaltyScorePresentGetDoubleNectarpointsScoreBucket3_Test"))
		{
			className = "TEST_2092_SBCardholderLoyaltyScorePresentGetDoubleNectarpointsScoreBucket3_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2093_SBCardholderLoyaltyScorePresentGetDoubleNectarpointsScoreBucket4_Test"))
		{
			className = "TEST_2093_SBCardholderLoyaltyScorePresentGetDoubleNectarpointsScoreBucket4_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2094_NonSBCardholderNoLoyaltyScorePresentGetDoubleNectarpoints_Test"))
		{
			className = "TEST_2094_NonSBCardholderNoLoyaltyScorePresentGetDoubleNectarpoints_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2095_NonCardholder_Test"))
		{
			className = "TEST_2095_NonCardholder_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2096_PreExistingHighRisk_Test"))
		{
			className = "TEST_2096_PreExistingHighRisk_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2097_PreExistingLowRisk_Test"))
		{
			className = "TEST_2097_PreExistingLowRisk_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2098_NotDisclosedPreExistingHighRisk_Test"))
		{
			className = "TEST_2098_NotDisclosedPreExistingHighRisk_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2099_NotDisclosedPreExistingLowRisk_Test"))
		{
			className = "TEST_2099_NotDisclosedPreExistingLowRisk_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2100_EligibleForTPL_Test"))
		{
			className = "TEST_2100_EligibleForTPL_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2101_IneligibleForTPLForDangerous_Test"))
		{
			className = "TEST_2101_IneligibleForTPLForDangerous_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2102_EligibleBreedWithVicious_Test"))
		{
			className = "TEST_2102_EligibleBreedWithVicious_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2103_IneligibleForTPLVicious_Test"))
		{
			className = "TEST_2103_IneligibleForTPLVicious_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2104_UnderAge_Test"))
		{
			className = "TEST_2104_UnderAge_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2106_On56thDay_Test"))
		{
			className = "TEST_2106_On56thDay_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2107_OverageNormalDog_Test"))
		{
			className = "TEST_2107_OverageNormalDog_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2108_8thBirthdayNormalDog_Test"))
		{
			className = "TEST_2108_8thBirthdayNormalDog_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2109_DayBefore8thBirthdayNormalDog_Test"))
		{
			className = "TEST_2109_DayBefore8thBirthdayNormalDog_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2110_5thBirthdaySelectDog_Test"))
		{
			className = "TEST_2110_5thBirthdaySelectDog_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2111_Daybefore5thBirthdaySelectDog_Test"))
		{
			className = "TEST_2111_Daybefore5thBirthdaySelectDog_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2112_QuoteDateOver30daysCurrentDate_Test"))
		{
			className = "TEST_2112_QuoteDateOver30daysCurrentDate_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2113_PolicyHolderUnder18_Test"))
		{
			className = "TEST_2113_PolicyHolderUnder18_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2114_PolicyHolder18thBirthday_Test"))
		{
			className = "TEST_2114_PolicyHolder18thBirthday_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2115_PolicyHolderMaxageOver100_Test"))
		{
			className = "TEST_2115_PolicyHolderMaxageOver100_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2119_FloorPremium_Test"))
		{
			className = "TEST_2119_FloorPremium_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2121_CeilingPremium_Test"))
		{
			className = "TEST_2121_CeilingPremium_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2122_OverlapRisks_TimeLimited�3000_Test"))
		{
			className = "TEST_2122_OverlapRisks_TimeLimited�3000_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2122_OverlapRisks_LifeTime�2500_Test"))
		{
			className = "TEST_2122_OverlapRisks_LifeTime�2500_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2122_OverlapRisks_LifeTime�5000_Test"))
		{
			className = "TEST_2122_OverlapRisks_LifeTime�5000_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2122_OverlapRisks_LifeTime�7500_Test"))
		{
			className = "TEST_2122_OverlapRisks_LifeTime�7500_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2123_DesignerCrossbreedsCheckSameResultThroughEachBreedlist1_Test"))
		{
			className = "TEST_2123_DesignerCrossbreedsCheckSameResultThroughEachBreedlist_Test1";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2220_DesignerCrossbreedsCheckSameResultThroughEachBreedlist2_Test"))
		{
			className = "TEST_2220_DesignerCrossbreedsCheckSameResultThroughEachBreedlist2_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2124_MultiPetQuote_Test"))
		{
			className = "TEST_2124_MultiPetQuote_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2125_BackbookNBCustomerOnPippaWithNoCurrentMultiPet_Test"))
		{
			className = "TEST_2125_BackbookNBCustomerOnPippaWithNoCurrentMultiPet_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2126_BackbookCustomerGiveMultipetYetToMigrateNotOnPippa_Test"))
		{
			className = "TEST_2126_BackbookCustomerGiveMultipetYetToMigrateNotOnPippa_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2127_BackbookNBCustomerOnPippaWithCurrentMultipet_Test"))
		{
			className = "TEST_2127_BackbookNBCustomerOnPippaWithCurrentMultipet_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2128_WrongFormatOfExistingPolicyNumberHUCPolicyNo_Test"))
		{
			className = "TEST_2128_WrongFormatOfExistingPolicyNumberHUCPolicyNo_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2129_WrongFormatOfExistingPolicyNumberRandom_Test"))
		{
			className = "TEST_2129_WrongFormatOfExistingPolicyNumberRandom_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2130_StaffDiscountEMP10_Test"))
		{
			className = "TEST_2130_StaffDiscountEMP10_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2131_NectarPOINTSof�25CheckPromoUID_Test"))
		{
			className = "TEST_2131_NectarPOINTSof�25CheckPromoUID_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2132_NectarPOINTSOf�25CheckNectarCardNumberIsMandatory_Test"))
		{
			className = "TEST_2132_NectarPOINTSOf�25CheckNectarCardNumberIsMandatory_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2134_InvalidNectarCard_Test"))
		{
			className = "TEST_2134_InvalidNectarCard_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2135_NectarCardMultipet_Test"))
		{
			className = "TEST_2135_NectarCardMultipet_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2136_ValidateInputsFormatPurchasePriceOnlyAllowsNumbers_Test"))
		{
			className = "TEST_2136_ValidateInputsFormatPurchasePriceOnlyAllowsNumbers_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2137_FirstThreeLettersBringsUpAllBreedsWithThoseThreeLetters_Test"))
		{
			className = "TEST_2137_FirstThreeLettersBringsUpAllBreedsWithThoseThreeLetters_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2138_RiskyParentPugCross_Test"))
		{
			className = "TEST_2138_RiskyParentPugCross_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2139_NotRiskingParentJackRussell_Test"))
		{
			className = "TEST_2139_NotRiskingParentJackRussell_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2140_DangerousDogWithoutTPLandExclude_Test"))
		{
			className = "TEST_2140_DangerousDogWithoutTPLandExclude_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2141_DangerousDogWithoutTPLButNotExclude_Test"))
		{
			className = "TEST_2141_DangerousDogWithoutTPLButNotExclude_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2348_CensusPostcodeDataProvidedToPriceAScottishPostCodeCorrectly_Test"))
		{
			className = "TEST_2348_CensusPostcodeDataProvidedToPriceAScottishPostCodeCorrectly_Test";
		}

		else if (ClassName.equalsIgnoreCase("TEST_2142_SBCardHolderLoyaltyScorePresentScoreBucket1_Test"))
		{
			className = "TEST_2142_SBCardHolderLoyaltyScorePresentScoreBucket1_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2143_SBCardHolderLoyaltyScorePresentScoreBucket2_Test"))
		{
			className = "TEST_2143_SBCardHolderLoyaltyScorePresentScoreBucket2_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2144_SBCardHolderLoyaltyScorePresentScoreBucket3_Test"))
		{
			className = "TEST_2144_SBCardHolderLoyaltyScorePresentScoreBucket3_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2145_SBCardHolderLoyaltyScorePresentScoreBucket4_Test"))
		{
			className = "TEST_2145_SBCardHolderLoyaltyScorePresentScoreBucket4_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2146_NonSBCardHolderNoLoyaltyScorePresent_Test"))
		{
			className = "TEST_2146_NonSBCardHolderNoLoyaltyScorePresent_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2095_NonCardholder_Test"))
		{
			className = "TEST_2095_NonCardholder_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2147_NonCardHolder_Test"))
		{
			className = "TEST_2147_NonCardHolder_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2148_PreExistingHighRisk_Test"))
		{
			className = "TEST_2148_PreExistingHighRisk_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2149_PreExistingLowRisk_Test"))
		{
			className = "TEST_2149_PreExistingLowRisk_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2150_NotDisclosedPreExistingHighRisk_Test"))
		{
			className = "TEST_2150_NotDisclosedPreExistingHighRisk_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2151_NotDisclosedPreExistingLowRisk_Test"))
		{
			className = "TEST_2151_NotDisclosedPreExistingLowRisk_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2156_Underage_Test"))
		{
			className = "TEST_2156_Underage_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2157_On56thDay_Test"))
		{
			className = "TEST_2157_On56thDay_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2158_10thBirthdayCat_Test"))
		{
			className = "TEST_2158_10thBirthdayCat_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2159_DayBefore10thBirthdayCat_Test"))
		{
			className = "TEST_2159_DayBefore10thBirthdayCat_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2161_QuoteDateOver30DaysCurrentDate_Test"))
		{
			className = "TEST_2161_QuoteDateOver30DaysCurrentDate_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2162_PolicyHolderUnder18_Test"))
		{
			className = "TEST_2162_PolicyHolderUnder18_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2163_PolicyHolder18thBirthday_Test"))
		{
			className = "TEST_2163_PolicyHolder18thBirthday_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2164_PolicyHoldermaxageOver100_Test"))
		{
			className = "TEST_2164_PolicyHoldermaxageOver100_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2168_FloorPremium_Test"))
		{
			className = "TEST_2168_FloorPremium_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2169_CeilingPremium_Test"))
		{
			className = "TEST_2169_CeilingPremium_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2170_OverlapRisks_TimeLimited�3000_Test"))
		{
			className = "TEST_2170_OverlapRisks_TimeLimited�3000_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2170_OverlapRisks_LifeTime�2500_Test"))
		{
			className = "TEST_2170_OverlapRisks_LifeTime�2500_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2170_OverlapRisks_LifeTime�5000_Test"))
		{
			className = "TEST_2170_OverlapRisks_LifeTime�5000_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2170_OverlapRisks_LifeTime�7500_Test"))
		{
			className = "TEST_2170_OverlapRisks_LifeTime�7500_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2171_MultiPetQuote_Test"))
		{
			className = "TEST_2171_MultiPetQuote_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2172_BackbookNBcustomerOnPippaWithNoCurrentMultipet_Test"))
		{
			className = "TEST_2172_BackbookNBcustomerOnPippaWithNoCurrentMultipet_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2173_BackbookCustomerGiveMultipetYetToMigrateNotOnPippa_Test"))
		{
			className = "TEST_2173_BackbookCustomerGiveMultipetYetToMigrateNotOnPippa_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2175_BackbookNBCustomerOnPippaWithCurrentMultipet_Test"))
		{
			className = "TEST_2175_BackbookNBCustomerOnPippaWithCurrentMultipet_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2176_WrongFormatOfExistingPolicyNumberHUCPolicyNo_Test"))
		{
			className = "TEST_2176_WrongFormatOfExistingPolicyNumberHUCPolicyNo_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2177_WrongFormatOfExistingPolicyNumberRandom_Test"))
		{
			className = "TEST_2177_WrongFormatOfExistingPolicyNumberRandom_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2178_StaffDiscountEMP10_Test"))
		{
			className = "TEST_2178_StaffDiscountEMP10_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2179_NectarPOINTSof�25checkPromoUID_Test"))
		{
			className = "TEST_2179_NectarPOINTSof�25checkPromoUID_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2180_NectarPOINTSof�25CheckNectarCardNumberIsMandatory_Test"))
		{
			className = "TEST_2180_NectarPOINTSof�25CheckNectarCardNumberIsMandatory_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2181_InvalidNectarCard_Test"))
		{
			className = "TEST_2181_InvalidNectarCard_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2183_NectarPointsMultipet_Test"))
		{
			className = "TEST_2183_NectarPointsMultipet_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2347_CensusPostcodeDataProvidedToPriceAScottishPostCodeCorrectly_Test"))
		{
			className = "TEST_2347_CensusPostcodeDataProvidedToPriceAScottishPostCodeCorrectly_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_2569_CatCrossbreedNotADogCrossbreed_Test"))
		{
			className = "TEST_2569_CatCrossbreedNotADogCrossbreed_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_150_ValidateRabbitNameIsMandatory_Test"))
		{
			className = "TEST_150_ValidateRabbitNameIsMandatory_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_651_ValidateModifyingRabbitBreedChangesQuoteResult_Test"))
		{
			className = "TEST_651_ValidateModifyingRabbitBreedChangesQuoteResult_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_652_ValidateModifyingRabbitSexFromMaleToFemaleChangesQuoteResult_Test"))
		{
			className = "TEST_652_ValidateModifyingRabbitSexFromMaleToFemaleChangesQuoteResult_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_653_ValidateModifyingRabbitSexFromFemaleToMaleChangesQuoteResult_Test"))
		{
			className = "TEST_653_ValidateModifyingRabbitSexFromFemaleToMaleChangesQuoteResult_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_654_ValidateModifyingRabbitNeuteredYesToNoChangesQuoteResult_Test"))
		{
			className = "TEST_654_ValidateModifyingRabbitNeuteredYesToNoChangesQuoteResult_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_655_ValidateModifyingRabbitNeuteredNoToYesChangesQuoteResult_Test"))
		{
			className = "TEST_655_ValidateModifyingRabbitNeuteredNoToYesChangesQuoteResult_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_656_ValidateModifyingRabbitPriceHigherToLowerChangesQuoteResult_Test"))
		{
			className = "TEST_656_ValidateModifyingRabbitPriceHigherToLowerChangesQuoteResult_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_657_ValidateModifyingRabbitPriceLowerToHigherChangesQuoteResult_Test"))
		{
			className = "TEST_657_ValidateModifyingRabbitPriceLowerToHigherChangesQuoteResult_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_721_ValidateUpdatedRabbitBreedInQuoteReview_Test"))
		{
			className = "TEST_721_ValidateUpdatedRabbitBreedInQuoteReview_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_155_ValidateRabbitBreedIsMandatory_Test"))
		{
			className = "TEST_155_ValidateRabbitBreedIsMandatory_Test";
		}
		else if (ClassName.equalsIgnoreCase("TEST_157_ValidateDOBIsMandatoryForRabbits_Test"))
		{
			className = "TEST_157_ValidateDOBIsMandatoryForRabbits_Test";
		}
		return className;
	}

	
	@Parameters ("ClassName")
	public String[] getPetTestDataFromExcel(String ClassName) throws Exception
	{
		utilities = new Utilities();
		className = utilities.getClassName(ClassName);
		String  strQuery = "Select * from PetQuote where TestClassName = '" + className + "'";
		dbConnectionCommonCode = new DBConnectionRegressionCommonCode();
		Recordset recordset = dbConnectionCommonCode.recordset(strQuery);
		recordset.next();
		recordset.moveFirst();
		PetType = recordset.getField("PetType");
		TypeOfPet = recordset.getField("TypeOfPet");
		Risk = recordset.getField("Risk");
		HighRiskReason = recordset.getField("HighRiskReason");
		if (Risk.equalsIgnoreCase("Low"))
		{
			uniqueTestDataArray = utilities.getUniqueTestData();
			TextToWrite = "Low Risk Pet";
			utilities.Filewriter(TextToWrite);
		}
		else if (Risk.equalsIgnoreCase("High"))
		{
			if (PetType.equalsIgnoreCase("Dog"))
			{
				if (TypeOfPet.equalsIgnoreCase("Breed"))
				{
					if (HighRiskReason.equalsIgnoreCase("Code_0"))
					{
						uniqueTestDataArray = utilities.getHigh_Risk_Dogs_Breed_Code_0();
						TextToWrite = "High_Risk_Dogs_Breed_Code_0";
						utilities.Filewriter(TextToWrite);
					}
					else if (HighRiskReason.equalsIgnoreCase("Code_35"))
					{
						uniqueTestDataArray = utilities.getHigh_Risk_Dogs_Breed_Code_35();
						TextToWrite = "High_Risk_Dogs_Breed_Code_35";
						utilities.Filewriter(TextToWrite);
					}
					else if (HighRiskReason.equalsIgnoreCase("Code_83"))
					{
						uniqueTestDataArray = utilities.getHigh_Risk_Dogs_Breed_Code_83();
						TextToWrite = "High_Risk_Dogs_Breed_Code_83";
						utilities.Filewriter(TextToWrite);
					}
					else if (HighRiskReason.equalsIgnoreCase("10k"))
					{
						uniqueTestDataArray = utilities.getHigh_Risk_Dogs_Breed_Code_10();
						TextToWrite = "High_Risk_Dogs_Breed_Code_10k";
						utilities.Filewriter(TextToWrite);
					}
				}
				else if (TypeOfPet.equalsIgnoreCase("Crossbreed"))
				{
					/*if (HighRiskReason.equalsIgnoreCase("Code_0"))
					{
						uniqueTestDataArray = utilities.getHigh_Risk_Dogs_CrossBreed_Code_0();
						TextToWrite = "High_Risk_Dogs_CrossBreed_Code_0";
						utilities.Filewriter(TextToWrite);
					}
					else if (HighRiskReason.equalsIgnoreCase("Code_35"))
					{
						uniqueTestDataArray = utilities.getHigh_Risk_Dogs_CrossBreed_Code_35();
						TextToWrite = "High_Risk_Dogs_CrossBreed_Code_35";
						utilities.Filewriter(TextToWrite);
					}
					else if (HighRiskReason.equalsIgnoreCase("Code_83"))
					{
						uniqueTestDataArray = utilities.getHigh_Risk_Dogs_CrossBreed_Code_83();
						TextToWrite = "High_Risk_Dogs_CrossBreed_Code_83";
						utilities.Filewriter(TextToWrite);
					}*/
					uniqueTestDataArray = utilities.getUniqueTestData();
				}
				else if (TypeOfPet.equalsIgnoreCase("Mongrel"))
				{
					uniqueTestDataArray = utilities.getUniqueTestData();
				}
			}
			else if (PetType.equalsIgnoreCase("Cat"))
			{
				if (HighRiskReason.equalsIgnoreCase("Code_35"))
				{
					uniqueTestDataArray = utilities.getHigh_Risk_Cats_Code_35();
					TextToWrite = "High_Risk_Cats_Code_35";
					utilities.Filewriter(TextToWrite);
				}
				else if (HighRiskReason.equalsIgnoreCase("Code_83"))
				{
					uniqueTestDataArray = utilities.getHigh_Risk_Cats_Code_83();
					TextToWrite = "High_Risk_Cats_Code_83";
					utilities.Filewriter(TextToWrite);
				}
				else if (HighRiskReason.equalsIgnoreCase("Code_0"))
				{
					uniqueTestDataArray = utilities.getUniqueTestData();
					TextToWrite = "Low_Risk_Cats";
					utilities.Filewriter(TextToWrite);
				}
			}
		}
		dbConnectionCommonCode.closeConnection();
		return uniqueTestDataArray;
	}
	
	@Parameters ("ClassName")
	public String[] getMultiPetTestDataFromExcel(String ClassName, int numberOfMultiPetsInt) throws Exception
	{
		utilities = new Utilities();
		className = utilities.getClassName(ClassName);
		String  strQuery = "Select * from MultiPet where TestClassName = '" + className + "'";
		dbConnectionCommonCode = new DBConnectionRegressionCommonCode();
		Recordset recordset = dbConnectionCommonCode.recordset(strQuery);
		recordset.next();
		recordset.moveFirst();
		numberOfMultiPetsInt = numberOfMultiPetsInt - 1;
		if (recordset.getField("MultiPetRisk_" + numberOfMultiPetsInt + "").equalsIgnoreCase("Low"))
		{
			multiPetUniqueTestDataArray = utilities.getUniqueTestData();
			TextToWrite = "Low Risk Multi Pet Number " + numberOfMultiPetsInt;
			utilities.Filewriter(TextToWrite);
		}
		else if (recordset.getField("MultiPetRisk_" + numberOfMultiPetsInt + "").equalsIgnoreCase("High"))
		{
			if (recordset.getField("MultiPetType_" + numberOfMultiPetsInt + "").equalsIgnoreCase("Dog"))
			{
				if (recordset.getField("MultiPetTypeOfDog_" + numberOfMultiPetsInt + "").equalsIgnoreCase("Breed"))
				{
					if (recordset.getField("MultiPetHighRiskReason_" + numberOfMultiPetsInt + "").equalsIgnoreCase("Code_0"))
					{
						multiPetUniqueTestDataArray = utilities.getHigh_Risk_Dogs_Breed_Code_0();
						TextToWrite = "HighRisk_Dogs_Breed_Code_0 Multi Pet Number " + numberOfMultiPetsInt;
						utilities.Filewriter(TextToWrite);
					}
					else if (recordset.getField("MultiPetHighRiskReason_" + numberOfMultiPetsInt + "").equalsIgnoreCase("Code_35"))
					{
						multiPetUniqueTestDataArray = utilities.getHigh_Risk_Dogs_Breed_Code_35();
						TextToWrite = "High_Risk_Dogs_Breed_Code_35 Multi Pet Number " + numberOfMultiPetsInt;
						utilities.Filewriter(TextToWrite);
					}
					else if (recordset.getField("MultiPetHighRiskReason_" + numberOfMultiPetsInt + "").equalsIgnoreCase("Code_83"))
					{
						multiPetUniqueTestDataArray = utilities.getHigh_Risk_Dogs_Breed_Code_83();
						TextToWrite = "High_Risk_Dogs_Breed_Code_83 Multi Pet Number " + numberOfMultiPetsInt;
						utilities.Filewriter(TextToWrite);
					}
				}
				else if (recordset.getField("MultiPetTypeOfDog_" + numberOfMultiPetsInt + "").equalsIgnoreCase("Crossbreed"))
				{
					/*if (recordset.getField("MultiPetHighRiskReason_" + numberOfMultiPetsInt + "").equalsIgnoreCase("Code_0"))
					{
						multiPetUniqueTestDataArray = utilities.getHigh_Risk_Dogs_CrossBreed_Code_0();
						TextToWrite = "High_Risk_Dogs_CrossBreed_Code_0 Multi Pet Number " + numberOfMultiPetsInt;
						utilities.Filewriter(TextToWrite);
					}
					else if (recordset.getField("MultiPetHighRiskReason_" + numberOfMultiPetsInt + "").equalsIgnoreCase("Code_35"))
					{
						multiPetUniqueTestDataArray = utilities.getHigh_Risk_Dogs_CrossBreed_Code_35();
						TextToWrite = "High_Risk_Dogs_CrossBreed_Code_35 Multi Pet Number " + numberOfMultiPetsInt;
						utilities.Filewriter(TextToWrite);
					}
					else if (recordset.getField("MultiPetHighRiskReason_" + numberOfMultiPetsInt + "").equalsIgnoreCase("Code_83"))
					{
						multiPetUniqueTestDataArray = utilities.getHigh_Risk_Dogs_CrossBreed_Code_83();
						TextToWrite = "High_Risk_Dogs_CrossBreed_Code_83 Multi Pet Number " + numberOfMultiPetsInt;
						utilities.Filewriter(TextToWrite);
					}*/
					multiPetUniqueTestDataArray = utilities.getUniqueTestData();
				}
				else if (recordset.getField("MultiPetTypeOfDog_" + numberOfMultiPetsInt + "").equalsIgnoreCase("Mongrel"))
				{
					multiPetUniqueTestDataArray = utilities.getUniqueTestData();
				}
			}
			else if (recordset.getField("MultiPetType_" + numberOfMultiPetsInt + "").equalsIgnoreCase("Cat"))
			{
				if (recordset.getField("MultiPetHighRiskReason_" + numberOfMultiPetsInt + "").equalsIgnoreCase("Code_35"))
				{
					multiPetUniqueTestDataArray = utilities.getHigh_Risk_Cats_Code_35();
					TextToWrite = "High_Risk_Cats_Code_35 Multi Pet Number " + numberOfMultiPetsInt;
					utilities.Filewriter(TextToWrite);
				}
				else if (recordset.getField("MultiPetHighRiskReason_" + numberOfMultiPetsInt + "").equalsIgnoreCase("Code_83"))
				{
					multiPetUniqueTestDataArray = utilities.getHigh_Risk_Cats_Code_83();
					TextToWrite = "High_Risk_Cats_Code_83 Multi Pet Number " + numberOfMultiPetsInt;
					utilities.Filewriter(TextToWrite);
				}
				else if (recordset.getField("MultiPetHighRiskReason_" + numberOfMultiPetsInt + "").equalsIgnoreCase("Code_0"))
				{
					multiPetUniqueTestDataArray = utilities.getUniqueTestData();
					TextToWrite = "Low_Risk_Cats " + numberOfMultiPetsInt;
					utilities.Filewriter(TextToWrite);
				}
			}
		}
		dbConnectionCommonCode.closeConnection();
		return multiPetUniqueTestDataArray;
	}
	
	public String[] getHigh_Risk_Dogs_Breed_Code_0() throws FilloException, IOException
	{
		dbConnectionCommonCode = new DBConnectionRegressionCommonCode();
		String randomString = RandomStringUtils.randomNumeric(3);
		int randomInt = Integer.valueOf(randomString);
		String stringRandomQuery = "Select * from HighRisk_Code_0_DogsBreed where ID = " + randomInt + "";
		Recordset recordset = dbConnectionCommonCode.recordset(stringRandomQuery);
		recordset.next();
		recordset.moveFirst();
		
		uniqueTestDataArray = new String[17];
		uniqueTestDataArray[0] = recordset.getField("PetFullName");
		uniqueTestDataArray[1] = recordset.getField("DogBreedType");
		uniqueTestDataArray[5] = recordset.getField("DOB_FromCoverStartDate");
		uniqueTestDataArray[6] = recordset.getField("CustomerFirstName");
		uniqueTestDataArray[7] = recordset.getField("CustomerLastName");
		uniqueTestDataArray[8] = recordset.getField("CustomerDOBDay");
		uniqueTestDataArray[9] = recordset.getField("CustomerDOBMonth");
		uniqueTestDataArray[10] = recordset.getField("CustomerDOBYear");
		uniqueTestDataArray[11] = recordset.getField("HouseNumberName");
		uniqueTestDataArray[12] = recordset.getField("Postcode");
		uniqueTestDataArray[13] = recordset.getField("Title");
		uniqueTestDataArray[14] = recordset.getField("Email");
		uniqueTestDataArray[15] = recordset.getField("CoverStartDate");
		uniqueTestDataArray[16] = recordset.getField("CoverStartDate_NumberOfDaysInFuture");
		dbConnectionCommonCode.closeConnection();
		return uniqueTestDataArray;
	}
	
	public String[] getHigh_Risk_Dogs_CrossBreed_Code_0() throws FilloException, IOException
	{
		dbConnectionCommonCode = new DBConnectionRegressionCommonCode();
		String randomString = RandomStringUtils.randomNumeric(3);
		int randomInt = Integer.valueOf(randomString);
		String stringRandomQuery = "Select * from HighRisk_Code_0_DogsCrossbreed where ID = " + randomInt + "";
		Recordset recordset = dbConnectionCommonCode.recordset(stringRandomQuery);
		recordset.next();
		recordset.moveFirst();
		
		uniqueTestDataArray = new String[17];
		uniqueTestDataArray[0] = recordset.getField("PetFullName");
		uniqueTestDataArray[2] = recordset.getField("DogCrossBreedType");
		uniqueTestDataArray[5] = recordset.getField("DOB_FromCoverStartDate");
		uniqueTestDataArray[6] = recordset.getField("CustomerFirstName");
		uniqueTestDataArray[7] = recordset.getField("CustomerLastName");
		uniqueTestDataArray[8] = recordset.getField("CustomerDOBDay");
		uniqueTestDataArray[9] = recordset.getField("CustomerDOBMonth");
		uniqueTestDataArray[10] = recordset.getField("CustomerDOBYear");
		uniqueTestDataArray[11] = recordset.getField("HouseNumberName");
		uniqueTestDataArray[12] = recordset.getField("Postcode");
		uniqueTestDataArray[13] = recordset.getField("Title");
		uniqueTestDataArray[14] = recordset.getField("Email");
		uniqueTestDataArray[15] = recordset.getField("CoverStartDate");
		uniqueTestDataArray[16] = recordset.getField("CoverStartDate_NumberOfDaysInFuture");
		dbConnectionCommonCode.closeConnection();
		return uniqueTestDataArray;
	}
	
	public String[] getHigh_Risk_Dogs_Breed_Code_35() throws FilloException, IOException
	{
		dbConnectionCommonCode = new DBConnectionRegressionCommonCode();
		String randomString = RandomStringUtils.randomNumeric(3);
		int randomInt = Integer.valueOf(randomString);
		String stringRandomQuery = "Select * from HighRisk_Code_35_DogsBreed_Age where ID = " + randomInt + "";
		Recordset recordset = dbConnectionCommonCode.recordset(stringRandomQuery);
		recordset.next();
		recordset.moveFirst();
		
		uniqueTestDataArray = new String[17];
		uniqueTestDataArray[0] = recordset.getField("PetFullName");
		uniqueTestDataArray[1] = recordset.getField("DogBreedType");
		uniqueTestDataArray[5] = recordset.getField("DOB_FromCoverStartDate");
		uniqueTestDataArray[6] = recordset.getField("CustomerFirstName");
		uniqueTestDataArray[7] = recordset.getField("CustomerLastName");
		uniqueTestDataArray[8] = recordset.getField("CustomerDOBDay");
		uniqueTestDataArray[9] = recordset.getField("CustomerDOBMonth");
		uniqueTestDataArray[10] = recordset.getField("CustomerDOBYear");
		uniqueTestDataArray[11] = recordset.getField("HouseNumberName");
		uniqueTestDataArray[12] = recordset.getField("Postcode");
		uniqueTestDataArray[13] = recordset.getField("Title");
		uniqueTestDataArray[14] = recordset.getField("Email");
		uniqueTestDataArray[15] = recordset.getField("CoverStartDate");
		uniqueTestDataArray[16] = recordset.getField("CoverStartDate_NumberOfDaysInFuture");
		dbConnectionCommonCode.closeConnection();
		return uniqueTestDataArray;
	}
	
	public String[] getHigh_Risk_Dogs_Breed_Code_83() throws FilloException, IOException
	{
		dbConnectionCommonCode = new DBConnectionRegressionCommonCode();
		String randomString = RandomStringUtils.randomNumeric(3);
		int randomInt = Integer.valueOf(randomString);
		String stringRandomQuery = "Select * from HighRisk_Code_83_DogsBreed_Age where ID = " + randomInt + "";
		Recordset recordset = dbConnectionCommonCode.recordset(stringRandomQuery);
		recordset.next();
		recordset.moveFirst();
		
		uniqueTestDataArray = new String[17];
		uniqueTestDataArray[0] = recordset.getField("PetFullName");
		uniqueTestDataArray[1] = recordset.getField("DogBreedType");
		uniqueTestDataArray[5] = recordset.getField("DOB_FromCoverStartDate");
		uniqueTestDataArray[6] = recordset.getField("CustomerFirstName");
		uniqueTestDataArray[7] = recordset.getField("CustomerLastName");
		uniqueTestDataArray[8] = recordset.getField("CustomerDOBDay");
		uniqueTestDataArray[9] = recordset.getField("CustomerDOBMonth");
		uniqueTestDataArray[10] = recordset.getField("CustomerDOBYear");
		uniqueTestDataArray[11] = recordset.getField("HouseNumberName");
		uniqueTestDataArray[12] = recordset.getField("Postcode");
		uniqueTestDataArray[13] = recordset.getField("Title");
		uniqueTestDataArray[14] = recordset.getField("Email");
		uniqueTestDataArray[15] = recordset.getField("CoverStartDate");
		uniqueTestDataArray[16] = recordset.getField("CoverStartDate_NumberOfDaysInFuture");
		dbConnectionCommonCode.closeConnection();
		return uniqueTestDataArray;
	}
	public String[] getHigh_Risk_Dogs_Breed_Code_10() throws FilloException, IOException
	{
		dbConnectionCommonCode = new DBConnectionRegressionCommonCode();
		String randomString = RandomStringUtils.randomNumeric(3);
		int randomInt = Integer.valueOf(randomString);
		String stringRandomQuery = "Select * from HighRisk_10k_DogsBreed where ID = " + randomInt + "";
		Recordset recordset = dbConnectionCommonCode.recordset(stringRandomQuery);
		recordset.next();
		recordset.moveFirst();
		
		uniqueTestDataArray = new String[17];
		uniqueTestDataArray[0] = recordset.getField("PetFullName");
		uniqueTestDataArray[1] = recordset.getField("DogBreedType");
		uniqueTestDataArray[5] = recordset.getField("DOB_FromCoverStartDate");
		uniqueTestDataArray[6] = recordset.getField("CustomerFirstName");
		uniqueTestDataArray[7] = recordset.getField("CustomerLastName");
		uniqueTestDataArray[8] = recordset.getField("CustomerDOBDay");
		uniqueTestDataArray[9] = recordset.getField("CustomerDOBMonth");
		uniqueTestDataArray[10] = recordset.getField("CustomerDOBYear");
		uniqueTestDataArray[11] = recordset.getField("HouseNumberName");
		uniqueTestDataArray[12] = recordset.getField("Postcode");
		uniqueTestDataArray[13] = recordset.getField("Title");
		uniqueTestDataArray[14] = recordset.getField("Email");
		uniqueTestDataArray[15] = recordset.getField("CoverStartDate");
		uniqueTestDataArray[16] = recordset.getField("CoverStartDate_NumberOfDaysInFuture");
		dbConnectionCommonCode.closeConnection();
		return uniqueTestDataArray;
	}
	public String[] getHigh_Risk_Dogs_CrossBreed_Code_35() throws FilloException, IOException
	{
		dbConnectionCommonCode = new DBConnectionRegressionCommonCode();
		String randomString = RandomStringUtils.randomNumeric(3);
		int randomInt = Integer.valueOf(randomString);
		String stringRandomQuery = "Select * from HighRisk_Code_35_DogsCross_Age where ID = " + randomInt + "";
		Recordset recordset = dbConnectionCommonCode.recordset(stringRandomQuery);
		recordset.next();
		recordset.moveFirst();
		
		uniqueTestDataArray = new String[17];
		uniqueTestDataArray[0] = recordset.getField("PetFullName");
		uniqueTestDataArray[2] = recordset.getField("DogCrossBreedType");
		uniqueTestDataArray[5] = recordset.getField("DOB_FromCoverStartDate");
		uniqueTestDataArray[6] = recordset.getField("CustomerFirstName");
		uniqueTestDataArray[7] = recordset.getField("CustomerLastName");
		uniqueTestDataArray[8] = recordset.getField("CustomerDOBDay");
		uniqueTestDataArray[9] = recordset.getField("CustomerDOBMonth");
		uniqueTestDataArray[10] = recordset.getField("CustomerDOBYear");
		uniqueTestDataArray[11] = recordset.getField("HouseNumberName");
		uniqueTestDataArray[12] = recordset.getField("Postcode");
		uniqueTestDataArray[13] = recordset.getField("Title");
		uniqueTestDataArray[14] = recordset.getField("Email");
		uniqueTestDataArray[15] = recordset.getField("CoverStartDate");
		uniqueTestDataArray[16] = recordset.getField("CoverStartDate_NumberOfDaysInFuture");
		dbConnectionCommonCode.closeConnection();
		return uniqueTestDataArray;
	}
	
	public String[] getHigh_Risk_Dogs_CrossBreed_Code_83() throws FilloException, IOException
	{
		dbConnectionCommonCode = new DBConnectionRegressionCommonCode();
		String randomString = RandomStringUtils.randomNumeric(3);
		int randomInt = Integer.valueOf(randomString);
		String stringRandomQuery = "Select * from HighRisk_Code_83_DogsCross_Age where ID = " + randomInt + "";
		Recordset recordset = dbConnectionCommonCode.recordset(stringRandomQuery);
		recordset.next();
		recordset.moveFirst();
		
		uniqueTestDataArray = new String[17];
		uniqueTestDataArray[0] = recordset.getField("PetFullName");
		uniqueTestDataArray[2] = recordset.getField("DogCrossBreedType");
		uniqueTestDataArray[5] = recordset.getField("DOB_FromCoverStartDate");
		uniqueTestDataArray[6] = recordset.getField("CustomerFirstName");
		uniqueTestDataArray[7] = recordset.getField("CustomerLastName");
		uniqueTestDataArray[8] = recordset.getField("CustomerDOBDay");
		uniqueTestDataArray[9] = recordset.getField("CustomerDOBMonth");
		uniqueTestDataArray[10] = recordset.getField("CustomerDOBYear");
		uniqueTestDataArray[11] = recordset.getField("HouseNumberName");
		uniqueTestDataArray[12] = recordset.getField("Postcode");
		uniqueTestDataArray[13] = recordset.getField("Title");
		uniqueTestDataArray[14] = recordset.getField("Email");
		uniqueTestDataArray[15] = recordset.getField("CoverStartDate");
		uniqueTestDataArray[16] = recordset.getField("CoverStartDate_NumberOfDaysInFuture");
		dbConnectionCommonCode.closeConnection();
		return uniqueTestDataArray;
	}
	
	public String[] getHigh_Risk_Cats_Code_35() throws FilloException, IOException
	{
		dbConnectionCommonCode = new DBConnectionRegressionCommonCode();
		String randomString = RandomStringUtils.randomNumeric(3);
		int randomInt = Integer.valueOf(randomString);
		String stringRandomQuery = "Select * from HighRisk_Code_35_Cats_Age where ID = " + randomInt + "";
		Recordset recordset = dbConnectionCommonCode.recordset(stringRandomQuery);
		recordset.next();
		recordset.moveFirst();
		
		uniqueTestDataArray = new String[17];
		uniqueTestDataArray[0] = recordset.getField("PetFullName");
		uniqueTestDataArray[4] = recordset.getField("CatBreed");
		uniqueTestDataArray[5] = recordset.getField("DOB_FromCoverStartDate");
		uniqueTestDataArray[6] = recordset.getField("CustomerFirstName");
		uniqueTestDataArray[7] = recordset.getField("CustomerLastName");
		uniqueTestDataArray[8] = recordset.getField("CustomerDOBDay");
		uniqueTestDataArray[9] = recordset.getField("CustomerDOBMonth");
		uniqueTestDataArray[10] = recordset.getField("CustomerDOBYear");
		uniqueTestDataArray[11] = recordset.getField("HouseNumberName");
		uniqueTestDataArray[12] = recordset.getField("Postcode");
		uniqueTestDataArray[13] = recordset.getField("Title");
		uniqueTestDataArray[14] = recordset.getField("Email");
		uniqueTestDataArray[15] = recordset.getField("CoverStartDate");
		uniqueTestDataArray[16] = recordset.getField("CoverStartDate_NumberOfDaysInFuture");
		dbConnectionCommonCode.closeConnection();
		return uniqueTestDataArray;
	}
	
	public String[] getHigh_Risk_Cats_Code_83() throws FilloException, IOException
	{
		dbConnectionCommonCode = new DBConnectionRegressionCommonCode();
		String randomString = RandomStringUtils.randomNumeric(3);
		int randomInt = Integer.valueOf(randomString);
		String stringRandomQuery = "Select * from HighRisk_Code_83_Cats_Age where ID = " + randomInt + "";
		Recordset recordset = dbConnectionCommonCode.recordset(stringRandomQuery);
		recordset.next();
		recordset.moveFirst();
		
		uniqueTestDataArray = new String[17];
		uniqueTestDataArray[0] = recordset.getField("PetFullName");
		uniqueTestDataArray[4] = recordset.getField("CatBreed");
		uniqueTestDataArray[5] = recordset.getField("DOB_FromCoverStartDate");
		uniqueTestDataArray[6] = recordset.getField("CustomerFirstName");
		uniqueTestDataArray[7] = recordset.getField("CustomerLastName");
		uniqueTestDataArray[8] = recordset.getField("CustomerDOBDay");
		uniqueTestDataArray[9] = recordset.getField("CustomerDOBMonth");
		uniqueTestDataArray[10] = recordset.getField("CustomerDOBYear");
		uniqueTestDataArray[11] = recordset.getField("HouseNumberName");
		uniqueTestDataArray[12] = recordset.getField("Postcode");
		uniqueTestDataArray[13] = recordset.getField("Title");
		uniqueTestDataArray[14] = recordset.getField("Email");
		uniqueTestDataArray[15] = recordset.getField("CoverStartDate");
		uniqueTestDataArray[16] = recordset.getField("CoverStartDate_NumberOfDaysInFuture");
		dbConnectionCommonCode.closeConnection();
		return uniqueTestDataArray;
	}
	
	public String[] editCover(String petType, ThreadLocal<WebDriver> driver, String className) throws Exception
	{
		utilities = new Utilities();
		softAssert = new SoftAssert();
		String str=driver.get().findElement(By.xpath("(//span[@class='summary'])[1]")).getText();
		String[] parts = str.split("�");
		
		String petTypeOnWebsite = parts[0];
		softAssert.assertEquals(petTypeOnWebsite, petType);
		String monthlyPremium = driver.get().findElement(By.xpath("(//h3[@class='product-details__sub-heading'])[1]")).getText();
		String yearlyPremium = driver.get().findElement(By.xpath("(//p[@class='product-details__sub-heading-info'])[1]")).getText().split(" ")[0];
		String coverType = driver.get().findElement(By.xpath("(//h2[@class='product-details__heading product-details__heading--primary'])[1]")).getText();
		String excess = driver.get().findElement(By.xpath("(//h3[@class='product-details__sub-heading'])[1]")).getText();
		String vetFees = driver.get().findElement(By.xpath("(//h3[@class='product-details__sub-heading'])[2]")).getText();
		TextToWrite = "Test: " + className + "	Monthly premium is: " + monthlyPremium + "Yearly premium is: " + yearlyPremium + "	Cover type is: " + coverType + "	Excess is: " + excess + "	Vet fees is: " + vetFees;
		editCoverArray = new String[5];
		editCoverArray[0] = monthlyPremium;
		editCoverArray[1] = yearlyPremium;
		editCoverArray[2] = coverType;
		editCoverArray[3] = excess;
		editCoverArray[4] = vetFees;
		utilities.Filewriter(TextToWrite);
		return editCoverArray;
	}
	
	@Parameters ("ClassName")
	public String[] getRegressionTestData(String ClassName) throws Exception
	{
		utilities = new Utilities();
		className = utilities.getClassName(ClassName);
		String  strQuery = "Select * from RegressionData where TestClassName = '" + className + "'";
		dbConnectionCommonCode = new DBConnectionRegressionCommonCode();
		Recordset recordset = dbConnectionCommonCode.recordset(strQuery);
		recordset.next();
		recordset.moveFirst();
		regressionTestDataArray = new String[19];
	//	regressionTestDataArray=new ThreadLocal<String[]>();
	 
		regressionTestDataArray[0] = recordset.getField("PetFullName");
		regressionTestDataArray[1] = recordset.getField("DogBreedType");
		regressionTestDataArray[2] = recordset.getField("DogCrossBreedType");
		regressionTestDataArray[3] = recordset.getField("DogSize");
		regressionTestDataArray[4] = recordset.getField("CatBreed");
		regressionTestDataArray[5] = recordset.getField("DOB_FromCoverStartDate");
		regressionTestDataArray[6] = recordset.getField("CustomerFirstName");
		regressionTestDataArray[7] = recordset.getField("CustomerLastName");
		regressionTestDataArray[8] = recordset.getField("CustomerDOBDay");
		regressionTestDataArray[9] = recordset.getField("CustomerDOBMonth");
		regressionTestDataArray[10] = recordset.getField("CustomerDOBYear");
		regressionTestDataArray[11] = recordset.getField("HouseNumberName");
		regressionTestDataArray[12] = recordset.getField("Postcode");
		regressionTestDataArray[13] = recordset.getField("Title");
		regressionTestDataArray[14] = recordset.getField("Email");
		regressionTestDataArray[15] = recordset.getField("CoverStartDate");
		regressionTestDataArray[16] = recordset.getField("CoverStartDate_NumberOfDaysInFuture");
		regressionTestDataArray[17] = recordset.getField("CustomerPhoneNumber");
		regressionTestDataArray[18] = recordset.getField("RabbitBreed");
		
		dbConnectionCommonCode.closeConnection();
		return regressionTestDataArray;
	}

	
	//Ravi ++
		public String loadPolicy() throws IOException {
			String loadPath=System.getProperty("user.dir") + "/Drivers/pippa_WebLoad.ps1";
			String pippaScreenshotPath =  System.getProperty("user.dir") + "\\Screenshots\\" + date + "\\" + TestEnvName + "\\Pippa\\"+className+"_";
			String filePath = System.getProperty("user.dir") + "\\Results\\"+className+"_";
			
			String[] cmmm = {"Powershell.exe","-executionpolicy","remotesigned","-File",loadPath,pippaScreenshotPath,filePath};
					    ProcessBuilder processBuilder = new ProcessBuilder(cmmm);
					    Process process = processBuilder.start();
					    try {
							process.waitFor();
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					   String result = String.valueOf(process.exitValue());
					   return result;
		}

		
		/*public String searchPolicy(String policyNumber,String policyStartDate,String monthlyCost,String petFullName,String coverType,String breedType,String petDob ) throws IOException, FilloException, ParseException{
			String result=null;
			try{    
				String pattern = "dd/MM/yyyy";
				DateFormat df = new SimpleDateFormat(pattern);
				uniqueTestDataArray = YourPetDetailsTest.uniqueTestDataArray;
				System.out.println("DOB "+uniqueTestDataArray[5]);
				if(petDob.length()==0){
				dobArray = getDOB(uniqueTestDataArray[5]);
				//petDob=dobArray[0] + "/" + dobArray[1] + "/" + dobArray[2];
				petDob=dobArray;
				}
				else{
					Date petDobtemp = new SimpleDateFormat("dd MMM yyyy").parse(petDob);          
					petDob = df.format(petDobtemp);	
				}
				if(breedType.length()==0){
					breedType=uniqueTestDataArray[1];
				}
				String Policy=policyNumber;
			    String coverStartDate=policyStartDate;
			    String Premium= monthlyCost.substring(1, monthlyCost.length()).trim();
			    String CustomerForenameWeb=uniqueTestDataArray[6];
			    String CustomerSurnameWeb=uniqueTestDataArray[7];
			   	String CustomerAddress1TextWeb=uniqueTestDataArray[11];
			    String CustomerDOB=uniqueTestDataArray[8] + "/" + uniqueTestDataArray[9] + "/" + uniqueTestDataArray[10];
			    String CustomerPostCodeTextWeb=CustomerDetailsTest.postCode;
			    String CustomerEmailTextWeb=uniqueTestDataArray[14];
			    String PetNameTextWeb=petFullName;
			    String PetDOBTextWeb=petDob;
			    String PetBreedTextWeb=breedType;
			    String PetCoverTypeTextWeb=coverType;
			    String PetAddress1TextWeb=CustomerDetailsTest.CustomerHouseNumberName;
			    String PetPostCodeTextWeb=CustomerDetailsTest.postCode;
		
			    
				Date coverStartDatetemp = new SimpleDateFormat("dd MMM yyyy").parse(coverStartDate);          
				String coverStartDateNew = df.format(coverStartDatetemp);	
				String pippaScreenshotPath =  System.getProperty("user.dir") + "\\Screenshots\\" + date + "\\" + TestEnvName + "\\Pippa\\"+className+"_";
				//String filePath = readConfig.getTestResultFilePath();
				String filePath = System.getProperty("user.dir") + "\\Results\\"+className+"_";
				String searchPath=System.getProperty("user.dir") + "/Drivers/pippa_SearchPolicy.ps1";
				
				//System.out.println("Screenshot path : "+ pippaScreenshotPath);
				
				
				
				
				
				String[] cmmm = {"Powershell.exe","-executionpolicy","remotesigned","-File",searchPath, Policy, Premium,coverStartDateNew,CustomerForenameWeb,CustomerSurnameWeb,CustomerAddress1TextWeb,CustomerDOB,		    		
			             		CustomerPostCodeTextWeb,CustomerEmailTextWeb,PetNameTextWeb,PetDOBTextWeb,PetBreedTextWeb,PetCoverTypeTextWeb,PetAddress1TextWeb,PetPostCodeTextWeb,pippaScreenshotPath,filePath };
			    ProcessBuilder processBuilder = new ProcessBuilder(cmmm);
			    Process process = processBuilder.start();
			    process.waitFor();
			    result = String.valueOf(process.exitValue());
			}catch( IOException ex ){
			    System.out.println("IOException");

			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			return result;
		}
		*/
		@Parameters ("ClassName")
		public void downloadFile(String documentName,WebElement downloadLink) throws Exception{
			utilities = new Utilities();
			readConfig = new ReadConfig();
			String pattern = "MMddyyyy_HHmmss";
			DateFormat df = new SimpleDateFormat(pattern);
			Date today = Calendar.getInstance().getTime();        
			String todayAsString = df.format(today);
			path=System.getProperty("user.dir") + "\\Documents\\"+className+"_"+documentName+"_"+todayAsString+".pdf";
			StringSelection file = new StringSelection(path);
			downloadLink.sendKeys(Keys.chord(Keys.ALT , Keys.ENTER));
			Thread.sleep(2000);
			Robot robot = new Robot();
			Toolkit.getDefaultToolkit().getSystemClipboard().setContents(file, null);

			robot.setAutoDelay(500); 

			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_V);

			robot.keyRelease(KeyEvent.VK_CONTROL);
			robot.keyRelease(KeyEvent.VK_V);

			robot.setAutoDelay(2000);

			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);
		}
		
		public Boolean validatePDF(WebDriver driver,WebElement downloadLink,String coverType) throws IOException{ 	
			 
			PDDocument doc=null;
			PDDocument docBase=null;
			String text=null;
			String textBase=null;
			String coverSamplePDF = System.getProperty("user.dir") + "\\Files\\SB-Insurance-Product-Information-Document-"+coverType+".pdf";
			try {
				doc = PDDocument.load(new File(path));
		        PDFTextStripper pdfStripper = new PDFTextStripper();
		        text = pdfStripper.getText(doc);
		        
		        docBase = PDDocument.load(new File(coverSamplePDF));
		        PDFTextStripper pdfStripperBase = new PDFTextStripper();
		        textBase = pdfStripperBase.getText(docBase);
			} catch (IOException e) {
				e.printStackTrace();
			} finally {
			    doc.close();
			    docBase.close();
			} 
			if(text.equals(textBase))
			{
				return true;
			}
			else{
				return false;
			}
		}
		
		public String validatePDF(WebDriver driver,WebElement downloadLink) throws IOException{ 	

			PDDocument doc=null;
			String text=null;
			try {
				doc = PDDocument.load(new File(path));
				PDFTextStripper pdfStripper = new PDFTextStripper();
				text = pdfStripper.getText(doc);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				doc.close();
			} 
			return text;
		}
		public void robotKeys(Robot robot, String keys) throws AWTException{
			
			switch(keys)
	        {
	        	case "TAB":
	        		robot.keyPress(KeyEvent.VK_TAB);
	        		robot.keyRelease(KeyEvent.VK_TAB);
	        		break;
	        	case "ENTER":
	        		robot.keyPress(KeyEvent.VK_ENTER);
	        		robot.keyRelease(KeyEvent.VK_ENTER);
	        		break;
            
	        	case "0":
	        		robot.keyPress(KeyEvent.VK_0);
	        		robot.keyRelease(KeyEvent.VK_0);
	        		break;
	            case "1":
	        		robot.keyPress(KeyEvent.VK_1);
	        		robot.keyRelease(KeyEvent.VK_1);
	        		break;
	            case "2":
	        		robot.keyPress(KeyEvent.VK_2);
	        		robot.keyRelease(KeyEvent.VK_2);
	        		break;
	            case "3":
	        		robot.keyPress(KeyEvent.VK_3);
	        		robot.keyRelease(KeyEvent.VK_3);
	        		break;
	            case "4":
	        		robot.keyPress(KeyEvent.VK_4);
	        		robot.keyRelease(KeyEvent.VK_4);
	        		break;
	            case "5":
	        		robot.keyPress(KeyEvent.VK_5);
	        		robot.keyRelease(KeyEvent.VK_5);
	        		break;
	            case "6":
	        		robot.keyPress(KeyEvent.VK_6);
	        		robot.keyRelease(KeyEvent.VK_6);
	        		break;
	            case "7":
	        		robot.keyPress(KeyEvent.VK_7);
	        		robot.keyRelease(KeyEvent.VK_7);
	        		break;
	            case "8":
	        		robot.keyPress(KeyEvent.VK_8);
	        		robot.keyRelease(KeyEvent.VK_8);
	        		break;
	            case "9":
	        		robot.keyPress(KeyEvent.VK_9);
	        		robot.keyRelease(KeyEvent.VK_9);
	        		break;

	            default:
	                System.out.println("You have entered wrong value");
	                return;
	        }
		}
		//--
	
		public void waitForLoad(ThreadLocal<WebDriver> driver) {
		//    new WebDriverWait(driver, 30).until(ExpectedConditions.jsReturnsValue("return document.readyState").equals("complete"));
		    WebDriverWait wait = new WebDriverWait(driver.get(), 30);
		    wait.until(ExpectedConditions.jsReturnsValue("return document.readyState==\"complete\";"));
		}
		
	public void onTestFailure()
	{
		softAssert = new SoftAssert();
		softAssert.assertEquals(7, 8);
		softAssert.assertAll();
	}
}
