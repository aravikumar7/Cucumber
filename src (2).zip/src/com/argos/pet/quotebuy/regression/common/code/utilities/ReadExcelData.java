/**
 * 
 */
package com.argos.pet.quotebuy.regression.common.code.utilities;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;

/**
 * @author d23747
 *
 */
public class ReadExcelData {

	public void readExcelData() {

		Fillo fillo = new Fillo();
		try
		{
			Connection connection = fillo.getConnection(System.getProperty("user.dir") + "/Files/SainsburysPetQuoteBuyTestData_v0.2.xlsx");
			String strQuery = "Select * from PetQuote";
			Recordset rs = connection.executeQuery(strQuery);
			while (rs.next())
			{
				String slNo = rs.getField("Sl_No");
				String baseURL = rs.getField("BaseURL");
				System.out.println(slNo + "  " + baseURL);
			}

			System.out.println(rs.getCount());
			rs.close();
			connection.close();
		}
		catch (FilloException fe)
		{
			fe.printStackTrace();
		}
	}
}