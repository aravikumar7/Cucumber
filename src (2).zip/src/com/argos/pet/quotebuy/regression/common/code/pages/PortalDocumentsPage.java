package com.argos.pet.quotebuy.regression.common.code.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class PortalDocumentsPage {

	public static ThreadLocal<WebDriver> ldriver;

	public PortalDocumentsPage (ThreadLocal<WebDriver> driver)
	{
		ldriver = driver;
		PageFactory.initElements(driver.get(), this);
	}
	
	@FindBy (how = How.XPATH, using = "//*[@id='search']") WebElement searchTextField;
	@FindBy (how = How.XPATH, using = "//*[text() [contains (., 'Insurance Policy Information Document - Lifetime')]]") WebElement insurancePolicyInformationDocumentLifetime;
	@FindBy (how = How.XPATH, using = "//*[text() [contains (., 'Insurance Policy Information Document - Time Limited')]]") WebElement insurancePolicyInformationDocumentTimeLimited;
	@FindBy (how = How.XPATH, using = "//*[text() [contains (., 'Argos Pet Insurance Policy Document')]]") WebElement argosPetInsurancePolicyDocument;
	@FindBy (how = How.XPATH, using = "//*[text() [contains (., 'Bank Pet Insurance Policy Document')]]") WebElement bankPetInsurancePolicyDocument;
	@FindBy (how = How.XPATH, using = "//*[@id='root']/div[3]/div[2]/main/div[2]/div/button") WebElement button;
	@FindBy (how = How.XPATH, using = "//*[text() [contains (., 'Advance Notice')]]") WebElement advanceNoticeLink;
	@FindBy (how = How.XPATH, using = "//*[text()[contains (., 'Download document')]] //following:: *[text() [contains (., 'Certificate of Insurance')]]") WebElement certificateOfInsuranceLink;
	@FindBy (how = How.XPATH, using = "//*[text() [contains (., 'Your Welcome Pack')]]") WebElement yourWelComePack;
	
	
	public void setSearchTextField(String SearchTextField)
	{
		searchTextField.sendKeys(SearchTextField);
	}
	
	public void setInsurancePolicyInformationDocumentLifetime()
	{
		insurancePolicyInformationDocumentLifetime.click();
	}
	
	public void setInsurancePolicyInformationDocumentTimeLimited()
	{
		insurancePolicyInformationDocumentTimeLimited.click();
	}
	
	public void setArgosPetInsurancePolicyDocument()
	{
		argosPetInsurancePolicyDocument.click();
	}
	
	public void setBankPetInsurancePolicyDocument()
	{
		bankPetInsurancePolicyDocument.click();
	}
	
	public void setButton()
	{
		button.click();
	}
	
	public void setAdvanceNoticeLink()
	{
		advanceNoticeLink.click();
	}
	
	public void setCertificateOfInsuranceLink()
	{
		certificateOfInsuranceLink.click();
	}
	
	public void setYourWelComePack()
	{
		yourWelComePack.click();
	}
}
