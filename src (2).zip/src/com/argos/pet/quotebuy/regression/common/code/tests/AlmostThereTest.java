/**
 * 
 */
package com.argos.pet.quotebuy.regression.common.code.tests;

//import org.quartz.utils.DBConnectionManager;
import org.testng.annotations.Parameters;

import com.argos.pet.quotebuy.regression.common.code.dbconnection.DBConnectionRegressionCommonCode;
import com.argos.pet.quotebuy.regression.common.code.pages.AlmostTherePage;
import com.argos.pet.quotebuy.regression.common.code.utilities.TestBase;
import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;
import com.codoid.products.fillo.Recordset;


/**
 * @author d23747
 *
 */
public class AlmostThereTest extends TestBase {

	AlmostTherePage almostTherePage;
	DBConnectionRegressionCommonCode dbConnectionCommonCode;
	Utilities utilities;
	String className;
	public String ClassName;

	@Parameters ("ClassName")
	public void initiateAlmostThereTest(String ClassName) throws Exception
	{
		almostTherePage = new AlmostTherePage(driver);
		dbConnectionCommonCode = new DBConnectionRegressionCommonCode();
		utilities = new Utilities();
		className = utilities.getClassName(ClassName);
		String  strQuery = "Select * from AlmostThere where TestClassName = '" + className + "'";
		Recordset recordset = dbConnectionCommonCode.recordset(strQuery);
		recordset.next();
		recordset.moveFirst();
		Thread.sleep(3000);
		if (recordset.getField("BuyNowButton").equalsIgnoreCase("Top"))
		{
			almostTherePage.clickBuyNowTopButton();
		}
		else
		{
			almostTherePage.clickBuyNowBottomButton();
		}
		dbConnectionCommonCode.closeConnection();
	}
}
