/**
 * 
 */
package com.argos.pet.quotebuy.regression.common.code.tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Parameters;
import org.testng.asserts.SoftAssert;

import com.argos.pet.quotebuy.regression.common.code.dbconnection.DBConnectionRegressionCommonCode;
import com.argos.pet.quotebuy.regression.common.code.pages.PortalDocumentsPage;
import com.argos.pet.quotebuy.regression.common.code.utilities.TestBase;
import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;
import com.codoid.products.fillo.Recordset;


public class PortalDocumentsTest extends TestBase {

	Utilities utilities;
	DBConnectionRegressionCommonCode dbConnectionCommonCode;
	PortalDocumentsPage portalDocumentsPage;
	SoftAssert softAssert;
	ReadPDF readPDF;
	String className;
	public String ClassName;
	static String CoverType;
	public static String[][] policyInformation;

	@Parameters ("ClassName")
	public void initiatePortalDocumentsTest(String ClassName) throws Exception
	{
		utilities = new Utilities();
		softAssert = new SoftAssert();
		portalDocumentsPage = new PortalDocumentsPage(driver);
		readPDF = new ReadPDF();
		className = utilities.getClassName(ClassName);
		policyInformation = ConfirmationTest.policyDetails;
		String  strQuery = "Select * from MultiPet where TestClassName = '" + className + "'";
		dbConnectionCommonCode = new DBConnectionRegressionCommonCode();
		Recordset recordset = dbConnectionCommonCode.recordset(strQuery);
		recordset.next();
		recordset.moveFirst();
		CoverType = YourCoverTest.CoverType;
		String PetName = policyInformation[0][0];
		String PetCover = policyInformation[0][1];
		String PolicyNumber = policyInformation[0][2];
		Thread.sleep(3800);


		//Check Advance Notice
		WebElement downloadLink = driver.get().findElement(By.xpath("//*[@id='root']/div[3]/div[2]/main/div[3]/div/div/div/div/div[2]/div/div/div/div[1]/div[4]/div[1]/div/div[2]/a"));
		utilities.downloadFile("AdvanceNotice", downloadLink);
		Thread.sleep(2500);
		String ContentsOfPDF = utilities.validatePDF(driver.get(), downloadLink);
		softAssert.assertEquals(ContentsOfPDF.contains(PetName), true);
		softAssert.assertEquals(ContentsOfPDF.contains(PetCover), true);
		softAssert.assertEquals(ContentsOfPDF.contains(PolicyNumber), true);
		//softAssert.assertAll();
		Thread.sleep(3800);

		//Check Certificate of Insurance
		downloadLink = driver.get().findElement(By.xpath("//*[@id='root']/div[3]/div[2]/main/div[3]/div/div/div/div/div[2]/div/div/div/div[1]/div[4]/div[2]/div/div[2]/a"));
		utilities.downloadFile("CertificateOfInsurance", downloadLink);
		Thread.sleep(3800);
		ContentsOfPDF = utilities.validatePDF(driver.get(), downloadLink);
		softAssert.assertEquals(ContentsOfPDF.contains(PetName), true);
		softAssert.assertEquals(ContentsOfPDF.contains(PetCover), true);
		softAssert.assertEquals(ContentsOfPDF.contains(PolicyNumber), true);
		//softAssert.assertAll();
		Thread.sleep(3800);

		//Check Your Welcome Pack
		downloadLink = driver.get().findElement(By.xpath("//*[@id='root']/div[3]/div[2]/main/div[3]/div/div/div/div/div[2]/div/div/div/div[1]/div[4]/div[3]/div/div[2]/a"));
		utilities.downloadFile("YourWelcomePack", downloadLink);
		Thread.sleep(3800);
		ContentsOfPDF = utilities.validatePDF(driver.get(), downloadLink);
		softAssert.assertEquals(ContentsOfPDF.contains(PetName), true);
		softAssert.assertEquals(ContentsOfPDF.contains(PetCover), true);
		softAssert.assertEquals(ContentsOfPDF.contains(PolicyNumber), true);
		Thread.sleep(3800);
		//softAssert.assertAll();
	}
}