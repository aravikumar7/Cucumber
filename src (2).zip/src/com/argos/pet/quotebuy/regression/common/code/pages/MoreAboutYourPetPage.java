package com.argos.pet.quotebuy.regression.common.code.pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class MoreAboutYourPetPage {

	ThreadLocal<WebDriver> ldriver;

	public MoreAboutYourPetPage(ThreadLocal<WebDriver> driver)
	{
		ldriver = driver;
		PageFactory.initElements(driver.get(), this);
	}

	@FindBy (how = How.ID, using = "pet1.pet_cost") WebElement petCost;
	@FindBy (how = How.XPATH, using = "//*[@id='zeroPetCost_1']") WebElement iDidntPayAnything;
	@FindBy (how = How.XPATH, using = "//label[contains(@for,'neutered_yes_pet1')]") WebElement petNeuteredYes;
	@FindBy (how = How.XPATH, using = "//label[contains(@for,'neutered_no_pet1')]") WebElement petNeuteredNo;
	@FindBy (how = How.XPATH, using = "//label[contains(@for,'health_yes_pet1')]") WebElement petAnyInjuryIllnessYes;
	@FindBy (how = How.XPATH, using = "//label[contains(@for,'health_no_pet1')]") WebElement petAnyInjuryIllnessNo;
	@FindBy (how = How.XPATH, using = "//*[@id='petQuestionsOuterContainer_1']/div[3]/div") WebElement petAnyInjuryIllnessNoTextMessage;
	@FindBy (how = How.XPATH, using = "//img[contains(@src,'pencil')]") WebElement changeAssumptionTopLink;
	@FindBy (how = How.XPATH, using = "//img[contains(@src,'pencil')]") WebElement changeAssumptionBottomLink;
	@FindBy (how = How.ID, using = "pet1.confirm_assumptions") WebElement assumptionCorrectTickBox;
	@FindBy (how = How.XPATH, using = "//*[@id='morePetSubmitButton_1']") WebElement savePetButton;
	@FindBy (how = How.XPATH, using = "//button[contains(@type,'submit')]") WebElement nextButton;

	public void enterPetCost(String CostOfThePet)
	{
		petCost.sendKeys(Keys.BACK_SPACE);
		petCost.sendKeys(CostOfThePet);
	}
	
	public void selectIDidntPayAnything()
	{
		iDidntPayAnything.click();
	}
	
	public void selectPetNeuteredYesRadioButton()
	{
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", petNeuteredYes);
	}
	
	public void selectPetNeuteredNoRadioButton()
	{
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", petNeuteredNo);
	}
	
	public void selectPetAnyInjuryIllnessYesRadioButton()
	{
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", petAnyInjuryIllnessYes);
	}
	
	public void selectPetAnyInjuryIllnessNoRadioButton()
	{
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", petAnyInjuryIllnessNo);
	}
	
	public String getPetAnyInjuryIllnessNoTextMessage()
	{
		String PetAnyInjuryIllnessNoTextMessage = petAnyInjuryIllnessNoTextMessage.getText();
		return PetAnyInjuryIllnessNoTextMessage;
	}
	
	public void selectChangeAssumptionTopLink()
	{
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", changeAssumptionTopLink);
	}
	
	public void selectChangeAssumptionBottomLink()
	{
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", changeAssumptionBottomLink);
	}
	
	public void selectAssumptionCorrectTickBox()
	{
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", assumptionCorrectTickBox);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", assumptionCorrectTickBox);
	}
	
	public void clickSavePetButton()
	{
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", savePetButton);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", savePetButton);
	}
	
	public void clickNextButton()
	{
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", nextButton);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", nextButton);
		//nextButton.click();
	}
	
}
