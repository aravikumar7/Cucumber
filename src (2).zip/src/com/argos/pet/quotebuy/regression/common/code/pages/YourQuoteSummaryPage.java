/**
 * 
 */
package com.argos.pet.quotebuy.regression.common.code.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * @author d23747
 *
 */
public class YourQuoteSummaryPage {

	ThreadLocal<WebDriver> ldriver;

	public YourQuoteSummaryPage(ThreadLocal<WebDriver> driver)
	{
		ldriver = driver;
		PageFactory.initElements(driver.get(), this);
	}
	
	@FindBy (how = How.XPATH, using = "//*[@id='contentContainer']/div[1]/div/div/div[2]") WebElement greetingText;
	@FindBy (how = How.XPATH, using = "//div[@class='quote__top']/div[2]/div[2]") WebElement quoteReferenceNumberValidityDate;
	@FindBy (how = How.XPATH, using = "//div[@class='quote__top']/div[2]/div[2]") WebElement quoteStartDate;
	@FindBy (how = How.XPATH, using = "//div[text()='Change start date']") WebElement changeCoverStartDate;
	@FindBy (how = How.XPATH, using = "(//div[contains(@class,'pet-name')])[1]") WebElement petName;
	@FindBy (how = How.XPATH, using = "(//h3[@class='product-details__sub-heading'])[1]") WebElement monthlyPrice;
	@FindBy (how = How.XPATH, using = "(//p[@class='product-details__sub-heading-info'])[1]") WebElement yearlyPrice;
	@FindBy (how = How.XPATH, using = "(//h2[@class='product-details__heading product-details__heading--primary'])[1]") WebElement coverDetails;
	@FindBy (how = How.XPATH, using = "(//h3[@class='product-details__sub-heading'])[1]") WebElement excessDetails;
	@FindBy (how = How.XPATH, using = "(//h3[@class='product-details__sub-heading'])[2]") WebElement vetFees;
	//@FindBy (how = How.XPATH, using = "//*[@id='quoteReviewPetBlockContainer_1']/div[1]/div[3]/div[1]/div/div[3]/button/div[2]/strong") WebElement changeCoverLink;
	@FindBy (how = How.XPATH, using = "(//div[text()='Change cover'])[1]") WebElement changeCoverLink;
	@FindBy (how = How.XPATH, using = "//*[@id='quoteReviewPetBlockContainer_1']/div[1]/div[3]/div[2]/div/div[1]/div") WebElement petDetails;
	@FindBy (how = How.XPATH, using = "//*[@id='quoteReviewPetBlockContainer_1']/div[1]/div[3]/div[2]/div/div[1]/div") WebElement petType;
	@FindBy (how = How.XPATH, using = "//*[@id='quoteReviewPetBlockContainer_1']/div[1]/div[3]/div[2]/div/div[2]/table/tbody/tr[2]/td[2]") WebElement petDOB;
	@FindBy (how = How.XPATH, using = "//*[@id='quoteReviewPetBlockContainer_1']/div[1]/div[3]/div[2]/div/div[2]/table/tbody/tr[3]/td[2]") WebElement petSex;
	@FindBy (how = How.XPATH, using = "(//span[@class='summary'])[1]") WebElement petBreed;
	//@FindBy (how = How.XPATH, using = "(//div[@class='get-information-row__info']/button)[1]") WebElement petPreExistingConditionsAddDetailsLink;
	@FindBy (how = How.XPATH, using = "(//div[contains(@class,'get-information-row__info')]/button)[1]") WebElement petPreExistingConditionsAddDetailsLink;
	@FindBy (how = How.XPATH, using = "//*[@id='addAnotherPetBtn']") WebElement addAnotherPetButton;
	@FindBy (how = How.XPATH, using = "//*[@id='quoteReviewUserBlockContainer']/div/div[1]/div/div[1]") WebElement customerFullName;
	@FindBy (how = How.XPATH, using = "//*[@id='quoteReviewUserBlockContainer']/div/div[1]/div/div[2]") WebElement customerEmailID;
	@FindBy (how = How.XPATH, using = "//*[@id='quoteReviewUserBlockContainer']/div/div[2]/div/div/div[1]/div[2]") WebElement customerDOB;
	@FindBy (how = How.XPATH, using = "//*[@id='quoteReviewUserBlockContainer']/div/div[2]/div/div/div[2]/div[2]") WebElement customerPhoneNumber;
	@FindBy (how = How.XPATH, using = "//*[@id='quoteReviewUserBlockContainer']/div/div[2]/div/div/div[3]/div[2]") WebElement customerAddress;
	@FindBy (how = How.XPATH, using = "//*[@id='userPhoneNumber']") WebElement customerPhoneNumberTextField;
	@FindBy (how = How.XPATH, using = "//*[@id='submitPhoneNumber']") WebElement addPhoneNumberButton;
	@FindBy (how = How.XPATH, using = "//*[@id='existingPolicyReview']/div/div/button") WebElement existingPolicyLink;
	@FindBy (how = How.XPATH, using = "//*[@id='existingPolicyInput']") WebElement existingPolicyTextField;
	@FindBy (how = How.XPATH, using = "//*[@id='submitExistingPolicy']") WebElement existingPolicyAddButton;
	@FindBy (how = How.XPATH, using = "//*[@id='floatingToasterPanel']/div/div/div/div") WebElement existingPolicySuccess;
	@FindBy (how = How.XPATH, using = "//*[@id='documentation_distribution_by_post']") WebElement documentByPostButton;
	@FindBy (how = How.XPATH, using = "//*[@id='toasterPanel']/div/div/div/div") WebElement multiPetDiscount;
	//@FindBy (how = How.XPATH, using = "//*[@id='floatingToasterPanel']/div/div/div/button/img") WebElement floatingToasterPanelClose;
	@FindBy (how = How.XPATH, using = "//*[@id='sidebar']/div[1]/div/div/table/tbody/tr[3]/td[1]") WebElement multiPetDiscountTextAtSideBar;
	@FindBy (how = How.XPATH, using = "//*[@id='sidebar']/div[1]/div/div/table/tbody/tr[3]/td[2]") WebElement appliedTextAtSideBar;
	@FindBy (how = How.XPATH, using = "(//div[@class='pet-name'])[1]") WebElement petNameAtPriceBreakdown;
	@FindBy (how = How.XPATH, using = "//div[contains(@class,'quote-summary-block')]/div/div[2]/div/div[2]/span") WebElement coverTypeAtPriceBreakdown;
	@FindBy (how = How.XPATH, using = "(//div[@class='price__details']/div)[1]") WebElement monthlyPriceAtPriceBreakdown;
	@FindBy (how = How.XPATH, using = "(//div[@class='price__details']/div)[1]") WebElement yearlyPriceAtPriceBreakdown;
	@FindBy (how = How.XPATH, using = "(//div[@class='pet-name'])[2]") WebElement petNameAtPriceBreakdown_2;
	@FindBy (how = How.XPATH, using = "(//div[@class='price__details']/div)[2]") WebElement monthlyPriceAtPriceBreakdown_2;
	@FindBy (how = How.XPATH, using = "//div[contains(@class,'quote-summary-block')]/div/div[3]/div/div[2]/span") WebElement coverTypeAtPriceBreakdown_2;
	@FindBy (how = How.XPATH, using = "(//div[@class='price__details']/div)[2]") WebElement yearlyPriceAtPriceBreakdown_2;
	
	/*@FindBy (how = How.XPATH, using = "//*[@id='priceBreakdown']/div/table/tbody/tr[2]/td[2]/strong") WebElement monthlyCostAtTotal;
	@FindBy (how = How.XPATH, using = "//*[@id='priceBreakdown']/div/table/tbody/tr[3]/td/strong") WebElement yearlyCostAtTotal;*/
	@FindBy (how = How.XPATH, using = "//*[@id='backButton']") WebElement backLink;
	//@FindBy (how = How.XPATH, using = "//div[text()='Next']") WebElement goToPaymentPageButton;
		@FindBy (how = How.XPATH, using = "//div/button[text()='Next']") WebElement goToPaymentPageButton;
		@FindBy (how = How.XPATH, using = "//*[@id='today']//following-sibling::label") WebElement coverStartDateToday;
		@FindBy (how = How.XPATH, using = "//*[@id='tomorrow']//following-sibling::label") WebElement coverStartDateTomorrow;
		@FindBy (how = How.XPATH, using = "//*[@id='other']//following-sibling::label") WebElement coverStartDateAnotherDate;
		@FindBy (id = "calendarTrigger") WebElement startDateCalendar;
		@FindBy (how = How.XPATH, using = "//button[text()='Save and close']") WebElement saveAndClose;
		@FindBy (how = How.XPATH, using = "//button[@class='Toastify__close-button']") WebElement floatingToasterPanelClose;
		@FindBy (how = How.XPATH, using = "//button[@class='Toastify__close-button']") WebElement floatingToasterPanelSuccess;
		
		public void clickCoverStartDateAnotherDate ()
		{
			coverStartDateAnotherDate.click();
		}
		
		public void populateCoverStartDateAnotherDate ()
		{
			startDateCalendar.click();
		}
		
	public String getGreetingText()
	{
		String GreetingText = greetingText.getText();
		return GreetingText;
	}
	
	public String getQuoteReferenceNumberStartDate()
	{
		String QuoteReferenceNumberStartDate = quoteReferenceNumberValidityDate.getText();
		return QuoteReferenceNumberStartDate;
	}
	
	public String getQuoteValidityDate()
	{
		String QuoteValidityDate = quoteStartDate.getText();
		return QuoteValidityDate;
	}
	
	public String getPetName()
	{
		String PetName = petName.getText();
		return PetName;
	}
	
	public String getMonthlyPrice()
	{
		String MonthlyPrice = monthlyPrice.getText();
		return MonthlyPrice;
	}
	
	public String getYearlyPrice()
	{
		String YearlyPrice = yearlyPrice.getText();
		return YearlyPrice;
	}
	
	public void clickChangeCoverStartDate()
	{
	//	changeCoverStartDate.click();
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", changeCoverStartDate);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", changeCoverStartDate);
	}
	
	public void clickCoverStartDateToday ()
	{
		//coverStartDateToday.click();
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", coverStartDateToday);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", coverStartDateToday);
	}
	
	public void clickCoverStartDateTomorrow ()
	{
		//coverStartDateTomorrow.click();
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", coverStartDateTomorrow);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", coverStartDateTomorrow);

	}
	public String getCoverDetails()
	{
		String CoverDetails = coverDetails.getText();
		return CoverDetails;
	}
	
	public String getExcessDetails()
	{
		String ExcessDetails = excessDetails.getText();
		return ExcessDetails;
	}
	
	public String getVetFees()
	{
		String VetFees = vetFees.getText();
		return VetFees;
	}
	
	public void clickChangeCoverLink()
	{
		//changeCoverLink.click();
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", changeCoverLink);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", changeCoverLink);
	}
	
	public String getPetDetails()
	{
		String PetDetails = petDetails.getText();
		return PetDetails;
	}
	
	public String getPetType()
	{
	//	String PetType = petType.getText();
		String str=ldriver.get().findElement(By.xpath("(//span[@class='summary'])[1]")).getText();
		String[] parts = str.split("�");
		return parts[0];
	}
	
	public String getPetDOB()
	{
		String PetDOB = petDOB.getText();
		return PetDOB;
	}
	
	public String getPetSex()
	{
		String PetSex = petSex.getText();
		return PetSex;
	}
	
	public String getPetBreed()
	{
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", petBreed);
		String PetBreed =petBreed.getText();
		String[] PetBreedArray = PetBreed.split("�");
		return PetBreedArray[3].trim();
	}
	
	public void clickPetPreExistingConditionsAddDetailsLink()
	{
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", petPreExistingConditionsAddDetailsLink);
		petPreExistingConditionsAddDetailsLink.click();
	}
	
	public void clickAddAnotherPetButton()
	{
		addAnotherPetButton.click();
	}
	
	public String getCustomerFullName()
	{
		String CustomerFullName = customerFullName.getText();
		return CustomerFullName;
	}
	
	public String getCustomerEmailID()
	{
		String CustomerEmailID = customerEmailID.getText();
		return CustomerEmailID;
	}
	
	public String getCustomerDOB()
	{
		String CustomerDOB = customerDOB.getText();
		return CustomerDOB;
	}
	
	public String getCustomerPhoneNumber()
	{
		String CustomerPhoneNumber = customerPhoneNumber.getText();
		return CustomerPhoneNumber;
	}
	
	public String getCustomerAddress()
	{
		String CustomerAddress = customerAddress.getText();
		return CustomerAddress;
	}
	
	public void populateCustomerPhoneNumberTextField(String CustomerPhoneNumber)
	{
		customerPhoneNumberTextField.clear();
		customerPhoneNumberTextField.sendKeys(CustomerPhoneNumber);
	}
	
	public void clickAddPhoneNumberButton()
	{
		addPhoneNumberButton.click();
	}
	
	public void clickExistingPolicyLink()
	{
		existingPolicyLink.click();
	}
	
	public void setExistingPolicyTextField(String ExistingPolicyNumber)
	{
		existingPolicyTextField.clear();
		existingPolicyTextField.sendKeys(ExistingPolicyNumber);
	}
	
	public void clickExistingPolicyAddButton()
	{
		existingPolicyAddButton.click();
	}
	
	public String getExistingPolicySuccess()
	{
		return existingPolicySuccess.getText();
	}
	
	public void clickDocumentByPostButton()
	{
		documentByPostButton.click();
	}
	
	public String getMultiPetDiscount()
	{
		return multiPetDiscount.getText();
	}
	
	public void clickFloatingToasterPanelClose()
	{
		floatingToasterPanelClose.click();
	}
	
	public String getPetNameAtPriceBreakdown()
	{
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", petNameAtPriceBreakdown);
		String PetNameAtPriceBreakdown = petNameAtPriceBreakdown.getText();
		return PetNameAtPriceBreakdown;
	}
	
	public String getCoverTypeAtPriceBreakdown()
	{
		String CoverType = coverTypeAtPriceBreakdown.getText();
		return CoverType;
	}
	
	public String getMonthlyPriceAtPriceBreakdown()
	{
		
		
	//	String monthlyToggle=ldriver.findElement(By.xpath("//button[@role='switch']/span[text()='Monthly']")).getAttribute("class");
		String monthlyToggle=ldriver.get().findElement(By.xpath("//button[@role='switch']")).getAttribute("aria-pressed");
		//	if(monthlyToggle=="false") {
			if(monthlyToggle=="true") {
				ldriver.get().findElement(By.xpath("//button[@role='switch']")).click();
		}
			String MonthlyPriceAtPriceBreakdown = monthlyPriceAtPriceBreakdown.getText();
			//return MonthlyPriceAtPriceBreakdownArray[0];
			return MonthlyPriceAtPriceBreakdown;
	}
	
	public String getYearlyPriceAtPriceBreakdown()
	{
		
	//	String yearlyToggle=ldriver.findElement(By.xpath("//button[@role='switch']/span[text()='Yearly']")).getAttribute("class");
		String yearlyToggle=ldriver.get().findElement(By.xpath("//button[@role='switch']")).getAttribute("aria-pressed");
		//if(yearlyToggle=="false") {
		if(yearlyToggle=="false") {	
			ldriver.get().findElement(By.xpath("//button[@role='switch']")).click();
	}
		String YearlyPriceAtPriceBreakdown = yearlyPriceAtPriceBreakdown.getText();
		//return MonthlyPriceAtPriceBreakdownArray[0];
		return YearlyPriceAtPriceBreakdown;
		
	}
	
	/*public String getMonthlyCostAtTotal()
	{
		String MonthlyCostAtTotal = monthlyCostAtTotal.getText();
		return MonthlyCostAtTotal;
	}
	
	public String getYearlyCostAtTotal()
	{
		String YearlyCostAtTotal = yearlyCostAtTotal.getText();
		return YearlyCostAtTotal;
	}*/
	
	public String getPetNameAtPriceBreakdown_2()
	{
		return petNameAtPriceBreakdown_2.getText();
	}
	
	public String getMonthlyPriceAtPriceBreakdown_2()
	{	
		//String monthlyToggle=ldriver.findElement(By.xpath("//button[@role='switch']/span[text()='Monthly']")).getAttribute("class");
		String monthlyToggle=ldriver.get().findElement(By.xpath("//button[@role='switch']")).getAttribute("aria-pressed");
		if(monthlyToggle=="true") {
		//if(monthlyToggle=="false") {	
			ldriver.get().findElement(By.xpath("//button[@role='switch']")).click();
	}
		String MonthlyPriceAtPriceBreakdown_2 = monthlyPriceAtPriceBreakdown_2.getText();
		//return MonthlyPriceAtPriceBreakdownArray[0];
		return MonthlyPriceAtPriceBreakdown_2;
	}
	
	public String getCoverTypeAtPriceBreakdown_2()
	{
		return coverTypeAtPriceBreakdown_2.getText();
	}
	
	public String getYearlyPriceAtPriceBreakdown_2()
	{
	
		//String yearlyToggle=ldriver.findElement(By.xpath("//button[@role='switch']/span[text()='Yearly']")).getAttribute("class");
		String yearlyToggle=ldriver.get().findElement(By.xpath("//button[@role='switch']")).getAttribute("aria-pressed");
		if(yearlyToggle=="true") {
		//if(yearlyToggle=="false") {	
			ldriver.get().findElement(By.xpath("//button[@role='switch']")).click();
	}
		String YearlyPriceAtPriceBreakdown_2 = yearlyPriceAtPriceBreakdown_2.getText();
		//return MonthlyPriceAtPriceBreakdownArray[0];
		return YearlyPriceAtPriceBreakdown_2;
	}
	
	public void clickBackLink()
	{
		backLink.click();
	}
	
	public void clickGoToPaymentPageButton()
	{
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", goToPaymentPageButton);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", goToPaymentPageButton);
	}
	
	public void clicksaveAndClose ()
	{
		saveAndClose.click();
	}
	
	public void clickFloatingToasterPanelSuccessClose()
	{
		boolean successtoaster=ldriver.get().findElements(By.xpath("//button[@class='Toastify__close-button Toastify__close-button--success']")).size()>0;
		if(successtoaster) {
	//	((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", floatingToasterPanelSuccess);
	//	((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", floatingToasterPanelSuccess);
			floatingToasterPanelSuccess.click();
		}
	}
}
