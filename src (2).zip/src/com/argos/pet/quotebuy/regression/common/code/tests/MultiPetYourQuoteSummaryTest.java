/**
 * 
 */
package com.argos.pet.quotebuy.regression.common.code.tests;

import org.openqa.selenium.By;
import org.testng.annotations.Parameters;

import com.argos.pet.quotebuy.regression.common.code.dbconnection.DBConnectionRegressionCommonCode;
import com.argos.pet.quotebuy.regression.common.code.utilities.TestBase;
import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;
import com.codoid.products.fillo.Recordset;


/**
 * @author d23747
 *
 */
public class MultiPetYourQuoteSummaryTest extends TestBase {
	MultiPetYourQuoteSummaryTest multiPetYourQuoteSummaryTest;
	DBConnectionRegressionCommonCode dbConnectionCommonCode;
	Utilities utilities;
	MultiPetPreExistingConditionsTest multiPetPreExistingConditionsTest;
	MultiPetMoreAboutYourPetTest multiPetMoreAboutYourPetTest;
	static String multiPetInjuryIllness;
	String className;
	static String newMultiPetAnyInjuryIllness;
	String numberOfMultiPetsString;
	static int numberOfMultiPets = 2;
	public String ClassName;
	static String[] breedType;
	static String[] petDob;

	@Parameters ("ClassName")
	public int initiateMultiPetYourQuoteSummaryTest(String ClassName) throws Exception
	{
		dbConnectionCommonCode = new DBConnectionRegressionCommonCode();
		utilities = new Utilities();
		className = utilities.getClassName(ClassName);
		String  strQuery = "Select * from MultiPetYourQuoteSummary where TestClassName = '" + className + "'";
		Recordset recordset = dbConnectionCommonCode.recordset(strQuery);
		recordset.next();
		recordset.moveFirst();

		numberOfMultiPetsString = recordset.getField("NumberOfMultiPets");
		int numberOfMultiPetsInt = Integer.valueOf(numberOfMultiPetsString);
	//	System.out.println("No of pets int:"+numberOfMultiPetsInt);
		breedType = new String[numberOfMultiPetsInt];
		petDob = new String[numberOfMultiPetsInt];
		numberOfMultiPetsInt = numberOfMultiPetsInt + 1;
	
		for (numberOfMultiPets = 2; numberOfMultiPets <= numberOfMultiPetsInt; numberOfMultiPets ++)
		{
		//	System.out.println("No of pets:"+numberOfMultiPets);
			newMultiPetAnyInjuryIllness = recordset.getField("MultiPetAnyInjuryIllnessRadioButtonBasedOnRisk_" + (numberOfMultiPets - 1) + "");
			String str=driver.get().findElement(By.xpath("(//span[@class='summary'])["+numberOfMultiPets+"]")).getText();
			String[] parts = str.split("�");
			
			breedType[numberOfMultiPets-2]=parts[3];
		//	petDob[numberOfMultiPets-2]=driver.get().findElement(By.xpath("//*[@id='quoteReviewPetBlockContainer_"+numberOfMultiPets+"']/div/div[3]/div[2]/div/div[2]/table/tbody/tr[2]/td[2]")).getText();											
			if (newMultiPetAnyInjuryIllness.equalsIgnoreCase("Yes"))
			{
				Thread.sleep(1500);
				driver.get().findElement(By.xpath("//div[contains(text(),\""+MultiPetTest.multipetName[numberOfMultiPets-2]+"'s\")]//parent::div//following-sibling::button")).click();	
				multiPetPreExistingConditionsTest = new MultiPetPreExistingConditionsTest();
				multiPetPreExistingConditionsTest.initiateMultiPetPreExistingConditionsTest(className);
				Thread.sleep(2500);
		//		utilities.waitElement(driver.get().findElement(By.xpath("//*[@id='contentContainer']/div[1]/h1")), driver.get());
		//		Thread.sleep(2500);
			}
		}
		dbConnectionCommonCode.closeConnection();
		return numberOfMultiPets;
	}
}