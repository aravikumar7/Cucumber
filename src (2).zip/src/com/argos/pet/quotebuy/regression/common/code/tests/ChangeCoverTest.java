package com.argos.pet.quotebuy.regression.common.code.tests;

import org.openqa.selenium.By;
import org.testng.annotations.Parameters;

import com.argos.pet.quotebuy.regression.common.code.dbconnection.DBConnectionRegressionCommonCode;
import com.argos.pet.quotebuy.regression.common.code.pages.ChangeCoverPage;
import com.argos.pet.quotebuy.regression.common.code.utilities.TestBase;
import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;
import com.codoid.products.fillo.Recordset;


public class ChangeCoverTest extends TestBase {

	ChangeCoverPage changeCoverPage;
	DBConnectionRegressionCommonCode dbConnectionCommonCode;
	Utilities utilities;
	String className;
	public String ClassName;

		@Parameters ("ClassName")
		public void initiateChangeCoverTest(String ClassName) throws Exception
		{
			changeCoverPage = new ChangeCoverPage(driver);
			dbConnectionCommonCode = new DBConnectionRegressionCommonCode();
			utilities = new Utilities();
			className = utilities.getClassName(ClassName);
			String  strQuery = "Select * from ChangeCover where TestClassName = '" + className + "'";
			Recordset recordset = dbConnectionCommonCode.recordset(strQuery);
			recordset.next();
			recordset.moveFirst();
			Thread.sleep(2500);

			if (recordset.getField("CoverType").equalsIgnoreCase("TimeLimited"))
			{
				changeCoverPage.clickChooseTimeLimitedButton();
				utilities.waitElement(driver.get().findElement(By.xpath("//*[@id='coverLevel_4']")), driver);
				if (recordset.getField("TimeLimitedLevelOfCover").equalsIgnoreCase("�3000"))
				{
					changeCoverPage.clickRadio�3000Button();
				}
			}

			else if (recordset.getField("CoverType").equalsIgnoreCase("Lifetime"))
			{
				changeCoverPage.clickChooseLifetimeButton();
				utilities.waitElement(driver.get().findElement(By.xpath("//*[@id='coverLevel_7']")), driver);

				if (recordset.getField("LifetimeLevelOfCover").equalsIgnoreCase("�2500"))
				{
					changeCoverPage.clickRadio�2500Button();
				}

				if (recordset.getField("LifetimeLevelOfCover").equalsIgnoreCase("�5000"))
				{
					changeCoverPage.clickRadio�5000Button();
				}

				if (recordset.getField("LifetimeLevelOfCover").equalsIgnoreCase("�7500"))
				{
					changeCoverPage.clickRadio�7500Button();
				}

			}
			else if (recordset.getField("CoverType").equalsIgnoreCase("MaxBenefit"))
			{
				changeCoverPage.clickChooseMaxBenefitButton();
				utilities.waitElement(driver.get().findElement(By.xpath("//*[@id='coverLevel_10']")), driver);

				if (recordset.getField("MaxBenefitOfCover").equalsIgnoreCase("�3000"))
				{
					changeCoverPage.clickRadioMax�3000Button();
				}

				if (recordset.getField("MaxBenefitOfCover").equalsIgnoreCase("�6000"))
				{
					changeCoverPage.clickRadioMax�6000Button();
				}
			}
			changeCoverPage.clickSaveCloseButton();
			dbConnectionCommonCode.closeConnection();
		}
	}