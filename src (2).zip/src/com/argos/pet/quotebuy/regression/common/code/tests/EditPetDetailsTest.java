/**
 * 
 */
package com.argos.pet.quotebuy.regression.common.code.tests;

import org.openqa.selenium.By;
import org.testng.annotations.Parameters;

import com.argos.pet.quotebuy.regression.common.code.dbconnection.DBConnectionRegressionCommonCode;
import com.argos.pet.quotebuy.regression.common.code.pages.EditPetDetailsPage;
import com.argos.pet.quotebuy.regression.common.code.utilities.TestBase;
import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;
import com.codoid.products.fillo.Recordset;


/**
 * @author d23747
 *
 */
public class EditPetDetailsTest extends TestBase {

	DBConnectionRegressionCommonCode dbConnectionCommonCode;
	Utilities utilities;
	EditPetDetailsPage editPetDetailsPage;
	String className;
	public String ClassName;

	@Parameters ("ClassName")
	public void initiateEditPetDetailsTest(String ClassName) throws Exception
	{
		utilities = new Utilities();
		editPetDetailsPage = new EditPetDetailsPage(driver);
		className = utilities.getClassName(ClassName);
		String  strQuery = "Select * from EditCover where TestClassName = '" + className + "'";
		dbConnectionCommonCode = new DBConnectionRegressionCommonCode();
		Recordset recordset = dbConnectionCommonCode.recordset(strQuery);
		recordset.next();
		recordset.moveFirst();
		
		editPetDetailsPage.clickEditPetDetailsLink();
	//	editPetDetailsPage.setPetTypeCat();
		driver.get().findElement(By.id("breedCatType_1")).click();
		editPetDetailsPage.whatBreedQuestionTextField();
		editPetDetailsPage.populateBreedType(recordset.getField("CatBreed"));
		editPetDetailsPage.selectFromList();
		editPetDetailsPage.clickSaveCloseButton();
		dbConnectionCommonCode.closeConnection();
	}
}