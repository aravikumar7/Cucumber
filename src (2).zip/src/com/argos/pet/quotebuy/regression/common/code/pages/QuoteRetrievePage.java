/**
 * 
 */
package com.argos.pet.quotebuy.regression.common.code.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * @author d23747
 *
 */
public class QuoteRetrievePage {

	WebDriver ldriver;
	public QuoteRetrievePage (WebDriver rdriver)
	{
		ldriver = rdriver;
		PageFactory.initElements(rdriver, this);
	}

	@FindBy (how = How.XPATH, using = "//*[@id='quote-ref-number']") WebElement quoteReferenceNumberTextField;
	@FindBy (how = How.XPATH, using = "//*[@id='email-address']") WebElement emailAddressTextField;
	@FindBy (how = How.XPATH, using = "//*[@id='retrieveQuoteSubmit']") WebElement retrieveQuoteButton;
	@FindBy (how = How.XPATH, using = "//*[@id='retrieveQuoteForm']/div[1]/fieldset/div/p") WebElement retrieveQuoteErrorTextAtField;
	@FindBy (how = How.XPATH, using = "//*[@id='errorAlertContainer']/div/div/div/div/div") WebElement retrieveQuoteErrorTextAtTheTop;
	@FindBy (how = How.XPATH, using = "//*[@id='floatingToasterPanel']/div/div/div/div") WebElement floatingToasterPanelErrorText;

	public void setQuoteReferenceNumberTextField(String QuoteReferenceNumber)
	{
		quoteReferenceNumberTextField.clear();
		quoteReferenceNumberTextField.sendKeys(QuoteReferenceNumber);
	}

	public void setEmailAddressTextField(String EmailAddress)
	{
		emailAddressTextField.clear();
		emailAddressTextField.sendKeys(EmailAddress);
	}

	public void clickRetrieveQuoteButton()
	{
		retrieveQuoteButton.click();
	}

	public String getRetrieveQuoteErrorTextAtField()
	{
		return retrieveQuoteErrorTextAtField.getText();
	}

	public String getRetrieveQuoteErrorTextAtTheTop()
	{
		return retrieveQuoteErrorTextAtTheTop.getText();
	}

	public String getFloatingToasterPanelErrorText()
	{
		return floatingToasterPanelErrorText.getText();
	}

}
