/**
 * 
 */
package com.argos.pet.quotebuy.regression.common.code.tests;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Parameters;
import org.testng.asserts.SoftAssert;

import com.argos.pet.quotebuy.regression.common.code.dbconnection.DBConnectionRegressionCommonCode;
import com.argos.pet.quotebuy.regression.common.code.pages.YourPetDetailsPage;
import com.argos.pet.quotebuy.regression.common.code.utilities.TestBase;
import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;
import com.codoid.products.fillo.Recordset;


/**
 * @author d23747
 *
 */
public class MultiPetYourCoverTest extends TestBase {

	DBConnectionRegressionCommonCode dbConnectionCommonCode;
	Utilities utilities;
	YourPetDetailsPage yourPetDetailsPage;
	SoftAssert softAssert;
	String className;
	String numberOfMultiPetsString;
	static int numberOfMultiPets = 2;
	public String ClassName;

	@Parameters ("ClassName")
	public void initiateMultiPetYourCoverTest(String ClassName) throws Exception
	{
		utilities = new Utilities();
		className = utilities.getClassName(ClassName);
		String  strQuery = "Select * from MultiPetYourCover where TestClassName = '" + className + "'";
		dbConnectionCommonCode = new DBConnectionRegressionCommonCode();
		Recordset recordset = dbConnectionCommonCode.recordset(strQuery);
		recordset.next();
		recordset.moveFirst();
		numberOfMultiPetsString = recordset.getField("NumberOfMultiPets");
		int numberOfMultiPetsInt = Integer.valueOf(numberOfMultiPetsString);
		numberOfMultiPetsInt = numberOfMultiPetsInt + 1;
		softAssert = new SoftAssert();
		utilities.waitForLoad(driver);
		for (numberOfMultiPets = 2; numberOfMultiPets <= numberOfMultiPetsInt; numberOfMultiPets ++)
		{
			if (recordset.getField("MultiPetCoverType_" + (numberOfMultiPets - 1) + "").equalsIgnoreCase("TimeLimited"))
			{
				Thread.sleep(1500);
				((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//label[@for='TL']")));
				//driver.get().findElement(By.xpath("//label[@for='TL']")).click();
				((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//label[@for='TL']")));
				if (recordset.getField("MultiPetTimeLimitedLevelOfCover_" + (numberOfMultiPets - 1) + "").equalsIgnoreCase("�2500"))
				{
					Thread.sleep(1500);
					((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.id("radio_cover_level_2500_" + numberOfMultiPets)));
				//	driver.get().findElement(By.id("radio_cover_level_3000_" + numberOfMultiPets)).click();
					((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.id("radio_cover_level_2500_" + numberOfMultiPets)));
				}
				else if(recordset.getField("MultiPetTimeLimitedLevelOfCover_" + (numberOfMultiPets - 1) + "").equalsIgnoreCase("�4000"))
				{
					Thread.sleep(1500);
					((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.id("radio_cover_level_4000_" + numberOfMultiPets)));
					//driver.get().findElement(By.id("radio_cover_level_3000_" + numberOfMultiPets)).click();
					((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.id("radio_cover_level_4000_" + numberOfMultiPets)));
				}
			}

			else if((recordset.getField("MultiPetCoverType_" + (numberOfMultiPets - 1) + "").equalsIgnoreCase("Lifetime")))
			{
				Thread.sleep(1500);
				((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//label[@for='LT']")));
				//driver.get().findElement(By.xpath("//label[@for='LT']")).click();
				((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//label[@for='LT']")));
				
				if (recordset.getField("MultiPetType_" + (numberOfMultiPets - 1) + "").equalsIgnoreCase("Dog")) {
					if (recordset.getField("MultiPetLifetimeLevelOfCover_" + (numberOfMultiPets - 1) + "").equalsIgnoreCase("�2000"))
					{
						Thread.sleep(1500);
						((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.id("radio_cover_level_2000_" + numberOfMultiPets)));
						//driver.get().findElement(By.id("radio_cover_level_2500_" + numberOfMultiPets)).click();
						((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.id("radio_cover_level_2000_" + numberOfMultiPets)));
					}

					else if (recordset.getField("MultiPetLifetimeLevelOfCover_" + (numberOfMultiPets - 1) + "").equalsIgnoreCase("�4500"))
					{
						Thread.sleep(1500);
						((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.id("radio_cover_level_4500_" + numberOfMultiPets)));
						//driver.get().findElement(By.id("radio_cover_level_5000_" + numberOfMultiPets)).click();
						((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();",  driver.get().findElement(By.id("radio_cover_level_4500_" + numberOfMultiPets)));
					}

					else if (recordset.getField("MultiPetLifetimeLevelOfCover_" + (numberOfMultiPets - 1) + "").equalsIgnoreCase("�7000"))
					{
						Thread.sleep(1500);
						((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.id("radio_cover_level_7000_" + numberOfMultiPets)));
						//driver.get().findElement(By.id("radio_cover_level_7500_" + numberOfMultiPets)).click();
						((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.id("radio_cover_level_7000_" + numberOfMultiPets)));
					}	
				}
				else if(recordset.getField("MultiPetType_" + (numberOfMultiPets - 1) + "").equalsIgnoreCase("Cat")) {
					if (recordset.getField("MultiPetLifetimeLevelOfCover_" + (numberOfMultiPets - 1) + "").equalsIgnoreCase("�1000"))
					{
						Thread.sleep(1500);
						((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.id("radio_cover_level_1000_" + numberOfMultiPets)));
					//	driver.get().findElement(By.id("radio_cover_level_2500_" + numberOfMultiPets)).click();
						((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.id("radio_cover_level_1000_" + numberOfMultiPets)));
					}

					else if (recordset.getField("MultiPetLifetimeLevelOfCover_" + (numberOfMultiPets - 1) + "").equalsIgnoreCase("�3500"))
					{
						Thread.sleep(1500);
						((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.id("radio_cover_level_3500_" + numberOfMultiPets)));
						//driver.get().findElement(By.id("radio_cover_level_5000_" + numberOfMultiPets)).click();
						((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.id("radio_cover_level_3500_" + numberOfMultiPets)));
					}

					else if (recordset.getField("MultiPetLifetimeLevelOfCover_" + (numberOfMultiPets - 1) + "").equalsIgnoreCase("�7000"))
					{
						Thread.sleep(1500);
						((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.id("radio_cover_level_7000_" + numberOfMultiPets)));
						//driver.get().findElement(By.id("radio_cover_level_7500_" + numberOfMultiPets)).click();
						((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.id("radio_cover_level_7000_" + numberOfMultiPets)));
					}
				}
				else if(recordset.getField("MultiPetType_" + (numberOfMultiPets - 1) + "").equalsIgnoreCase("Rabbit")) {
					if (recordset.getField("MultiPetLifetimeLevelOfCover_" + (numberOfMultiPets - 1) + "").equalsIgnoreCase("�1000"))
					{
						Thread.sleep(1500);
						((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.id("radio_cover_level_1000_" + numberOfMultiPets)));
						((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.id("radio_cover_level_1000_" + numberOfMultiPets)));
					}
				}
			}
			else
			{
				Thread.sleep(1500);
				((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//label[@for='MB']")));
				//driver.get().findElement(By.xpath("//label[@for='MB']")).click();
				((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//label[@for='MB']")));
				//		utilities.waitElement(driver.get().findElement(By.xpath("//*[@id='coverLevel_10']")), driver.get());	
				
				if (recordset.getField("MultiPetMaxBenefitOfCover_" + (numberOfMultiPets - 1) + "").equalsIgnoreCase("�2000"))
				{
					Thread.sleep(1500);
					((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.id("radio_cover_level_2000_" + numberOfMultiPets)));
				//	driver.get().findElement(By.id("radio_cover_level_3000_" + numberOfMultiPets)).click();
					((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.id("radio_cover_level_2000_" + numberOfMultiPets)));
				}

				else if (recordset.getField("MultiPetMaxBenefitOfCover_" + (numberOfMultiPets - 1) + "").equalsIgnoreCase("�5000"))
				{
					Thread.sleep(1500);
					((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.id("radio_cover_level_5000_" + numberOfMultiPets)));
				//	driver.get().findElement(By.id("radio_cover_level_6000_" + numberOfMultiPets)).click();
					((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.id("radio_cover_level_5000_" + numberOfMultiPets)));
				}
			}
			
			/*WebElement downloadLink=driver.get().findElement(By.xpath(("//*[@id='chooser_container_"+numberOfMultiPets + "']/div[3]/div/div[1]/div/a")));
			utilities.downloadFile("PolicyDocument"+numberOfMultiPets,downloadLink);
			Thread.sleep(1500);
			
			downloadLink=driver.get().findElement(By.xpath("//*[@id='chooser_container_"+numberOfMultiPets + "']/div[3]/div/div[2]/div/a"));
			utilities.downloadFile("IPID"+numberOfMultiPets,downloadLink);
			Thread.sleep(1000);
			if(recordset.getField("MultiPetCoverType_" + (numberOfMultiPets - 1) + "").equalsIgnoreCase("TimeLimited")){
				softAssert.assertTrue(utilities.validatePDF(driver,downloadLink,"TimeLimited"));
				}
				else if(recordset.getField("MultiPetCoverType_" + (numberOfMultiPets - 1) + "").equalsIgnoreCase("Lifetime"))
				{
					softAssert.assertTrue(utilities.validatePDF(driver,downloadLink,"Lifetime"));
				}
				else{
					softAssert.assertTrue(utilities.validatePDF(driver,downloadLink,"Maximum Benefit Cover"));
				}*/
			//--End
			Thread.sleep(1500);
			softAssert.assertAll();
			((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//button[@type='submit']")));
			((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//button[@type='submit']")));
		
		}
		
		//utilities.TakePassScreenShot(driver, recordset.getField("TestClassName"));
		dbConnectionCommonCode.closeConnection();
	}
}
