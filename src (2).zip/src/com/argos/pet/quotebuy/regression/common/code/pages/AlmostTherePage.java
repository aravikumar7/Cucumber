package com.argos.pet.quotebuy.regression.common.code.pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class AlmostTherePage {

	ThreadLocal<WebDriver> ldriver;

	public AlmostTherePage(ThreadLocal<WebDriver> driver)
	{
		ldriver = driver;
		PageFactory.initElements(driver.get(), this);
	}

	
	@FindBy (how = How.XPATH, using ="//a[text()='Purchase policy']") WebElement buyNowTopButton;
	@FindBy (how = How.XPATH, using = "//*[@id='paymentConfirmationContainer']/div/div[1]/div/div/div[1]/button") WebElement printButton;
	@FindBy (how = How.XPATH, using = "//*[@id='paymentConfirmationContainer']/div/div[1]/div/div/div[2]/div[1]/span") WebElement accountHolderName;
	@FindBy (how = How.XPATH, using = "//*[@id='paymentConfirmationContainer']/div/div[1]/div/div/div[2]/div[3]/span") WebElement sortCode;
	@FindBy (how = How.XPATH, using = "//*[@id='paymentConfirmationContainer']/div/div[1]/div/div/div[2]/div[5]/span") WebElement bankBuildingSocietyName;
	@FindBy (how = How.XPATH, using = "//*[@id='paymentConfirmationContainer']/div/div[1]/div/div/div[2]/div[2]/span") WebElement accountNumber;
	@FindBy (how = How.XPATH, using = "//*[@id='paymentConfirmationContainer']/div/div[1]/div/div/div[2]/div[4]/span") WebElement quoteStartDate;
	@FindBy (how = How.XPATH, using = "//*[@id='paymentConfirmationContainer']/div/div[1]/div/div/div[2]/div[6]/span") WebElement bankBuildingSocietyAddress;
	@FindBy (how = How.XPATH, using = "//*[@id='paymentConfirmationContainer']/div/div[1]/div/div/div[3]/div/button/div[2]") WebElement editDetailsLink;
	@FindBy (how = How.XPATH, using = "//*[@id='paymentConfirmationContainer']/div/div[3]/div/div/div/div[1]/div/button") WebElement backLink;
	@FindBy (how = How.XPATH, using = "//a[text()='Purchase policy']") WebElement buyNowBottomButton;

	public void clickBuyNowTopButton()
	{
		((JavascriptExecutor) ldriver).executeScript("arguments[0].scrollIntoView(true);", buyNowTopButton);
		((JavascriptExecutor) ldriver).executeScript("arguments[0].click();", buyNowTopButton);
	//	buyNowTopButton.click();
	}

	public void clickBuyNowBottomButton()
	{
		((JavascriptExecutor) ldriver).executeScript("arguments[0].scrollIntoView(true);", buyNowTopButton);
		((JavascriptExecutor) ldriver).executeScript("arguments[0].click();", buyNowTopButton);
	//	buyNowBottomButton.click();
	}
}
