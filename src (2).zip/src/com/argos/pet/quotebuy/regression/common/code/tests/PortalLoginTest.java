package com.argos.pet.quotebuy.regression.common.code.tests;

import org.openqa.selenium.By;
import org.testng.annotations.Parameters;
import org.testng.asserts.SoftAssert;

import com.argos.pet.quotebuy.regression.common.code.dbconnection.DBConnectionRegressionCommonCode;
import com.argos.pet.quotebuy.regression.common.code.pages.PortalLogInPage;
import com.argos.pet.quotebuy.regression.common.code.utilities.TestBase;
import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;
import com.codoid.products.fillo.Recordset;


public class PortalLoginTest extends TestBase {

	YourPetDetailsTest yourPetDetailsTest;
	PortalLogInPage logInPage;
	Utilities utilities;
	DBConnectionRegressionCommonCode dbConnectionCommonCode;
	SoftAssert softAssert;
	String className;
	public String ClassName;
	ThreadLocal<String[]> uniqueTestDataArray;

	@Parameters ("ClassName")
	public void initiatePortalLoginTest(String ClassName) throws Exception
	{
		logInPage = new PortalLogInPage(driver);
		utilities = new Utilities();
		softAssert = new SoftAssert();
		className = utilities.getClassName(ClassName);
		uniqueTestDataArray = YourPetDetailsTest.uniqueTestDataArray;
		String  strQuery = "Select * from Login where TestClassName = '" + className + "'";
		dbConnectionCommonCode = new DBConnectionRegressionCommonCode();
		Recordset recordset = dbConnectionCommonCode.recordset(strQuery);
		recordset.next();
		recordset.moveFirst();

		Thread.sleep(3600);
		if (utilities.isElementPresent(By.xpath("//*[text()[contains (., 'Something went wrong')]]"), driver))
		{
			driver.get().findElement(By.xpath("//*[@id='panelClose']")).click();
		}
		if (utilities.isElementPresent(By.xpath("/html/body/div[4]/div/div/div[3]/div[1]/button/img"), driver))
		{
			driver.get().findElement(By.xpath("/html/body/div[4]/div/div/div[3]/div[1]/button/img")).click();
		}
	//	driver.get("https://" + Username + ":" + Password + "@" + PortalTestEnvironmentURL);
		Thread.sleep(5600);
		logInPage.setLoginTabButton();
		logInPage.setEmailAddress((uniqueTestDataArray.get())[14]);
		//logInPage.setEmailAddress("cpcustomerportal+rk129@gmail.com");
		logInPage.setPassword(recordset.getField("Password"));
		logInPage.setLoginButton();

	}
}
