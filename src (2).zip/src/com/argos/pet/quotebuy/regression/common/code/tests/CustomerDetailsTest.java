package com.argos.pet.quotebuy.regression.common.code.tests;

import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.argos.pet.quotebuy.regression.common.code.dbconnection.DBConnectionRegressionCommonCode;
import com.argos.pet.quotebuy.regression.common.code.pages.CustomerDetailsPage;
import com.argos.pet.quotebuy.regression.common.code.utilities.TestBase;
import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;
import com.codoid.products.fillo.Recordset;


public class CustomerDetailsTest extends TestBase {

	DBConnectionRegressionCommonCode dbConnectionCommonCode;
	CustomerDetailsPage customerDetails;
	Actions actions;
	SoftAssert softAssert;
	Utilities utilities;
	String className;
	String coverStartDate;
//	String[] uniqueTestDataArray;
	ThreadLocal<String[]> regressionTestDataArray;
	public String nextMonth;
	public String TextToWrite;
	public String ClassName;
	static public String postCode;
	static public String CustomerHouseNumberName;
	static public String portalEmail;
	static public String portalPostCode;
	static public String dateOfBirth1;
	static public String dateOfBirth2;
	static public String dateOfBirth3;
	String dateOfBirth;
	Actions builder;
	
	@Parameters ("ClassName")
	@Test
	public void initiateCustomerDetailsTest(String ClassName) throws Exception
	{
		customerDetails = new CustomerDetailsPage(driver);
		actions = new Actions(driver.get());
		utilities = new Utilities();
		softAssert = new SoftAssert();
		dbConnectionCommonCode = new DBConnectionRegressionCommonCode();
		className = utilities.getClassName(ClassName);
		String  strQuery = "Select * from CustomerDetails where TestClassName = '" + className + "'";
		Recordset recordset = dbConnectionCommonCode.recordset(strQuery);
		recordset.next();
		recordset.moveFirst();
		nextMonth = utilities.getNextMonth();
	//	uniqueTestDataArray = YourPetDetailsTest.uniqueTestDataArray;
		regressionTestDataArray = YourPetDetailsTest.regressionTestDataArray;
		//+ Moved to Payment
		/*
		String CoverStartDate_NumberOfDaysInFuture = regressionTestDataArray[16];
	
		System.out.println("Date is: "+recordset.getField("CoverStartDate_NumberOfDaysInFuture"));
		//String CoverStartDate_NumberOfDaysInFuture = recordset.getField("CoverStartDate_NumberOfDaysInFuture");
		coverStartDate = utilities.getCoverStartDate(CoverStartDate_NumberOfDaysInFuture);
	
		
		System.out.println(coverStartDate);
		*/
		//- Moved to Payment
	//	utilities.waitForLoad(driver);
		////////
			///////
		customerDetails = new CustomerDetailsPage(driver);
		//+ Moved to Payment
/*
		customerDetails.selectCustomerTitle(regressionTestDataArray[13]);
		customerDetails.populateCustomerFirstName(regressionTestDataArray[6]);
		customerDetails.populateCustomerLastName(regressionTestDataArray[7]);
		//dateOfBirth = regressionTestDataArray[8]+regressionTestDataArray[9]+regressionTestDataArray[10];
		dateOfBirth = regressionTestDataArray[8]+"/"+regressionTestDataArray[9]+"/"+regressionTestDataArray[10];
	//	dateOfBirth="20/02/2000";
		customerDetails.populatedateOfBirth(dateOfBirth);
	*/	
		//- Moved to Payment	
		
		customerDetails.populateCustomerEmail((regressionTestDataArray.get())[14]);
		//+ Moved to Payment
		//customerDetails.populateCustomerPhoneNumber(recordset.getField("CustomerPhoneNumber"));
		//- Moved to Payment
		customerDetails.populateCustomerHouseNumberName((regressionTestDataArray.get())[11]);
		customerDetails.populateCustomerPostcode((regressionTestDataArray.get())[12]);
		
		portalEmail=(regressionTestDataArray.get())[14];
		portalPostCode=(regressionTestDataArray.get())[12];
		//+ Moved to Payment
		//dateOfBirth1=regressionTestDataArray[8];
		//dateOfBirth2=regressionTestDataArray[9];
		//dateOfBirth3=regressionTestDataArray[10];
		//- Moved to Payment
		postCode=(regressionTestDataArray.get())[12];
		CustomerHouseNumberName=(regressionTestDataArray.get())[11];
		customerDetails.clickFindAddressButton();
		Thread.sleep(700);
		//customerDetails.clickFloatingToasterPanelSuccessClose();
		customerDetails.clickFloatingToasterPanelSuccessClose();
		
		boolean errortoaster=driver.get().findElements(By.xpath("//div[@class='toast-content__body' and contains(text(),'Invalid')]")).size()>0;
		if(errortoaster){
			System.out.println("Error toaster");
			driver.get().findElement(By.xpath("//*[@id='root']/div/div/div/button")).click();
		} 
		boolean addressError=driver.get().findElements(By.xpath("//h4[text()='Error']")).size()>0;
		
	if(addressError || errortoaster){	
		String AddressNotFoundErrorText;
	if(addressError){
		AddressNotFoundErrorText = customerDetails.getNoResultsError();
		System.out.println("Address Error toaster");
		driver.get().findElement(By.xpath("//*[@id='root']/div/div/div/button")).click();
	}
		else{
		 AddressNotFoundErrorText = "";
		}
		//	if (AddressNotFoundErrorText.equalsIgnoreCase("No results found for that house number/name and postcode."))
			{
				customerDetails.clickFloatingToasterPanelClose();
				System.out.println("Populating default");
				customerDetails.populateCustomerHouseNumberName("16");
				customerDetails.populateCustomerPostcode("WD7 8HT");
				portalPostCode="WD7 8HT";
				customerDetails.clickFindAddressButton();
				Thread.sleep(700);
				postCode="WD7 8HT";
				CustomerHouseNumberName="16";
				utilities.Filewriter(AddressNotFoundErrorText + "Hence new address used: CustomerHouseNumber = 16 & CustomerPostcode = WD7 8HT");
		//		customerDetails.clickFloatingToasterPanelSuccessClose();
						}
		}
	customerDetails.clickFloatingToasterPanelSuccessClose();
	TextToWrite = "Customer Details: " + " Email: " + (regressionTestDataArray.get())[14] + " House Number: " + CustomerHouseNumberName + " Postcode: " + postCode;
	utilities.Filewriter(TextToWrite);
	
		Thread.sleep(1500);
		if (recordset.getField("PromoCheckerLink").equalsIgnoreCase("Yes"))
		{
			Thread.sleep(700);
			//driver.get().switchTo().activeElement().sendKeys(Keys.TAB);
			customerDetails.populateCustomerPromotionalCode(recordset.getField("PromotionalCode"));
			Thread.sleep(800);
			customerDetails.applyCustomerPromotionalCode();
			Thread.sleep(700);
			if (recordset.getField("CheckPromotionalCodeText").equalsIgnoreCase("Yes"))
			{
				String promoCodeDescriptionOnWeb = customerDetails.getPromoCodeDescriptionTextMessage();
				String promoCodeDescriptionFromExcel = recordset.getField("PromotionalCodeTextMessage");
				softAssert.assertEquals(promoCodeDescriptionOnWeb, promoCodeDescriptionFromExcel);
				softAssert.assertAll();
			}
			TextToWrite = "Promo Code: " + recordset.getField("PromotionalCode");
			utilities.Filewriter(TextToWrite);
		}
		
		Thread.sleep(1000);
		
		customerDetails.clickGetAQuoteButton();
		Thread.sleep(5000);
		dbConnectionCommonCode.closeConnection();
		//return (regressionTestDataArray.get());
	}
}