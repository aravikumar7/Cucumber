/**
 * 
 */
package com.argos.pet.quotebuy.regression.common.code.tests;

import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Parameters;
import org.testng.asserts.SoftAssert;

import com.argos.pet.quotebuy.regression.common.code.dbconnection.DBConnectionRegressionCommonCode;
import com.argos.pet.quotebuy.regression.common.code.pages.YourQuoteSummaryPage;
import com.argos.pet.quotebuy.regression.common.code.utilities.TestBase;
import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;
import com.codoid.products.fillo.Recordset;

/**
 * @author d23747
 *
 */
public class YourQuoteSummaryTest extends TestBase{

	YourQuoteSummaryPage yourQuoteSummaryPage;
	PreExistingConditionsTest preExistingConditionsTest;
	ChangeCoverTest changeCoverTest;
	DBConnectionRegressionCommonCode dbConnectionCommonCode;
	Utilities utilities;
	SoftAssert softAssert;
	static String petInjuryIllness;
	String className;
	public String ClassName;
	//static String[] uniqueTestDataArray;
	ThreadLocal<String[]> regressionTestDataArray;
	static String[] multiPetUniqueTestDataArray;
	public String TextToWrite;
	String coverStartDate;
	Actions builder;
	
	@Parameters ("ClassName")
	public void testYourQuoteSummary(String ClassName) throws Exception
	{
		dbConnectionCommonCode = new DBConnectionRegressionCommonCode();
		softAssert = new SoftAssert();
		yourQuoteSummaryPage = new YourQuoteSummaryPage(driver);
		utilities = new Utilities();
	//	uniqueTestDataArray = YourPetDetailsTest.uniqueTestDataArray;
		className = utilities.getClassName(ClassName);
		String  strQuery = "Select * from YourQuoteSummary where TestClassName = '" + className + "'";
		Recordset recordset = dbConnectionCommonCode.recordset(strQuery);
		recordset.next();
		recordset.moveFirst();
		regressionTestDataArray = YourPetDetailsTest.regressionTestDataArray;	
		System.out.println("Date is: "+recordset.getField("CoverStartDate_NumberOfDaysInFuture"));
		String CoverStartDate_NumberOfDaysInFuture = recordset.getField("CoverStartDate_NumberOfDaysInFuture");
		coverStartDate = utilities.getCoverStartDate(CoverStartDate_NumberOfDaysInFuture);
	
		utilities.waitForLoad(driver);
		
		System.out.println(coverStartDate);
		//if (recordset.getField("CoverStartDate").equalsIgnoreCase("Today"))
		if ((regressionTestDataArray.get())[15].equalsIgnoreCase("Today"))	
		{
		//	Thread.sleep(700);
		//	yourQuoteSummaryPage.clickCoverStartDateToday();
		}
		else if ((regressionTestDataArray.get())[15].equalsIgnoreCase("Tomorrow"))
		//else if (recordset.getField("CoverStartDate").equalsIgnoreCase("Tomorrow"))
		{
		//	Thread.sleep(700);
			yourQuoteSummaryPage.clickChangeCoverStartDate();
			Thread.sleep(700);
			yourQuoteSummaryPage.clickCoverStartDateTomorrow();
			yourQuoteSummaryPage.clicksaveAndClose();
		}
		else if ((regressionTestDataArray.get())[15].equalsIgnoreCase("AnotherDate"))
		//else if (recordset.getField("CoverStartDate").equalsIgnoreCase("AnotherDate"))
		{
			yourQuoteSummaryPage.clickChangeCoverStartDate();
			Thread.sleep(700);
			try
			{
				//	Thread.sleep(700);
				yourQuoteSummaryPage.clickCoverStartDateAnotherDate();
				if(!driver.get().findElement(By.xpath("//button[@class='react-calendar__navigation__label']")).getText().contains(coverStartDate.substring(0,4)))
				{
					driver.get().findElement(By.xpath("(//div[@class='react-calendar__navigation__arrow-icon'])[2]")).click();
					Thread.sleep(1500);
					String[] parts = coverStartDate.split(",");
					String[] parts1 = parts[0].split(" ");
					builder = new Actions(driver.get());
					for(int i=0;i<Integer.parseInt(parts1[1]);i++){
							builder.sendKeys(Keys.TAB).perform();
							Thread.sleep(500);
					}
				}
				else{
					System.out.println(CoverStartDate_NumberOfDaysInFuture);
					 builder = new Actions(driver.get());
					for(int i=0;i<Integer.parseInt(CoverStartDate_NumberOfDaysInFuture)+3;i++){
							builder.sendKeys(Keys.TAB).perform();
							Thread.sleep(500);
					}
					
				}
				Thread.sleep(500);
			builder.sendKeys(Keys.ENTER).perform();	
			//utilities.actionClick(driver, coverStartDateElement);
			}
			catch (NoSuchElementException nsee)
			{
				System.out.println("We are in excpetion");
				if (className.equalsIgnoreCase("TEST_2112_QuoteDateOver30daysCurrentDate"))
				{
					softAssert.assertEquals("C", "C");
					utilities.shortFilewriter("Start date greater than 30 days is not allowed");
					softAssert.assertAll();
				}
				else if (className.equalsIgnoreCase("TEST_2161_QuoteDateOver30DaysCurrentDate"))
				{
					softAssert.assertEquals("C", "C");
					utilities.shortFilewriter("Start date greater than 30 days is not allowed");
					softAssert.assertAll();
				}
				else
				{
					try
					{
						yourQuoteSummaryPage.clickCoverStartDateToday();
					}
					catch (NoSuchElementException nsee2)
					{
						driver.get().switchTo().activeElement().sendKeys(Keys.ESCAPE);
						Thread.sleep(1500);
						yourQuoteSummaryPage.clickCoverStartDateTomorrow();
					}
				}
			}
			yourQuoteSummaryPage.clicksaveAndClose();
		}
	
		yourQuoteSummaryPage.clickFloatingToasterPanelSuccessClose();
		////
		petInjuryIllness = MoreAboutYourPetTest.petInjuryIllness;
		if (petInjuryIllness.equalsIgnoreCase("Yes"))
		{
			yourQuoteSummaryPage.clickPetPreExistingConditionsAddDetailsLink();
			preExistingConditionsTest = new PreExistingConditionsTest();
			preExistingConditionsTest.testPreExistingConditions(className);
			Thread.sleep(1500);
		//	utilities.waitElement(driver.findElement(By.xpath("//*[@id='contentContainer']/div[1]/h1")), driver);
		//	Thread.sleep(1500);
		}
		
		
		if (recordset.getField("ChangePetCover").equalsIgnoreCase("Yes"))
		{
		    changeCoverTest=new ChangeCoverTest();
			changeCoverTest.initiateChangeCoverTest(className);
		}		
		Thread.sleep(1500);
	
		if (utilities.isElementPresent(By.xpath("//*[@id='floatingToasterPanel']/div/div/div/div"), driver))
		{
			Thread.sleep(1500);
			driver.get().findElement(By.xpath("//*[@id='floatingToasterPanel']/div/div/div/button")).click();
			Thread.sleep(1500);
		}

	/*	if (recordset.getField("ExistingPolicy").equalsIgnoreCase("Yes"))
		{
			yourQuoteSummaryPage.clickExistingPolicyLink();
			WebElement existingPolicyTextField = driver.findElement(By.xpath("//*[@id='existingPolicyInput']"));
			utilities.waitElement(existingPolicyTextField, driver);
			yourQuoteSummaryPage.setExistingPolicyTextField(recordset.getField("ExistingPolicyNumber"));
			driver.switchTo().activeElement().sendKeys(Keys.TAB);
			yourQuoteSummaryPage.clickExistingPolicyAddButton();
			Thread.sleep(3200);
			TextToWrite = "Existing Allianz Policy: " + recordset.getField("ExistingPolicyNumber");
			utilities.Filewriter(TextToWrite);

			if (utilities.isElementPresent(By.xpath("//*[@id='floatingToasterPanel']/div/div/div/div"), driver))
			{
				//WebElement successMessage = driver.findElement(By.xpath("//*[@id='floatingToasterPanel']/div/div/div/div"));
				//utilities.waitElement(successMessage, driver);
				String successMessageOnWeb = yourQuoteSummaryPage.getExistingPolicySuccess();
				String successMessageFromExcel = recordset.getField("SuccessToastContainer");
				softAssert.assertEquals(successMessageOnWeb, successMessageFromExcel);
				Thread.sleep(5200);
				WebElement floatingToaster = driver.findElement(By.xpath("//*[@id='floatingToasterPanel']/div/div/div/div"));
				utilities.waitElement(floatingToaster, driver);
				yourQuoteSummaryPage.clickFloatingToasterPanelClose();
				Thread.sleep(700);
			}
			
			if (recordset.getField("MultiPet").equalsIgnoreCase("No"))
			{
				WebElement multipetDiscountMessage = driver.findElement(By.xpath("//*[@id='floatingToasterPanel']/div/div/div/div"));
				utilities.waitElement(multipetDiscountMessage, driver);
				String multipetDiscountMessageOnWeb = yourQuoteSummaryPage.getMultiPetDiscount();
				String multipetDiscountMessageFromExcel = recordset.getField("MultipetDiscountToastContainerText") + uniqueTestDataArray[0] + ".";
				softAssert.assertEquals(multipetDiscountMessageOnWeb, multipetDiscountMessageFromExcel);
			}
			else
			{
				multiPetUniqueTestDataArray = MultiPetYourPetDetailsTest.multiPetUniqueTestDataArray;
				WebElement multipetDiscountMessage = driver.findElement(By.xpath("//*[@id='floatingToasterPanel']/div/div/div/div"));
				utilities.waitElement(multipetDiscountMessage, driver);
				String multipetDiscountMessageOnWeb = yourQuoteSummaryPage.getMultiPetDiscount();
				String multipetDiscountMessageFromExcel = recordset.getField("MultipetDiscountToastContainerText") + uniqueTestDataArray[0] + " & " + multiPetUniqueTestDataArray[0] + ".";
				softAssert.assertEquals(multipetDiscountMessageOnWeb, multipetDiscountMessageFromExcel);
			}
			//softAssert.assertAll();
		}
*/
/*		if (recordset.getField("DocumentByPost").equalsIgnoreCase("Yes"))
		{
			yourQuoteSummaryPage.clickDocumentByPostButton();
			Thread.sleep(2500);
			if (utilities.isElementPresent(By.xpath("//*[@id='floatingToasterPanel']/div/div/div/div"), driver))
			{
				Thread.sleep(1500);
				driver.findElement(By.xpath("//*[@id='floatingToasterPanel']/div/div/div/button")).click();
				Thread.sleep(1500);
			}
		}*/
		yourQuoteSummaryPage.clickGoToPaymentPageButton();
		dbConnectionCommonCode.closeConnection();
	}
}
