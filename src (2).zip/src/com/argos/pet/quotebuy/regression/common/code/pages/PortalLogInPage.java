/**
 * 
 */
package com.argos.pet.quotebuy.regression.common.code.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * @author d23747
 *
 */
public class PortalLogInPage {

	public static ThreadLocal<WebDriver> ldriver;

	public PortalLogInPage (ThreadLocal<WebDriver> driver)
	{
		ldriver = driver;
		PageFactory.initElements(driver.get(), this);
	}

	@FindBy (how = How.XPATH, using = "//*[@id='login-tab']") WebElement loginTabButton;
	@FindBy (how = How.XPATH, using = "/html/body/div[3]/main/div/div/div/div/div[2]/div[2]/div[1]/div[3]/div[2]/div/form/div[1]/div/input") WebElement emailAddress;
	@FindBy (how = How.XPATH, using = "/html/body/div[3]/main/div/div/div/div/div[2]/div[2]/div[1]/div[3]/div[2]/div/form/div[2]/div/input") WebElement password;
	@FindBy (how = How.XPATH, using = "//*[@id='showForgottenPasswordModal']") WebElement forgotPasswordLink;
	@FindBy (how = How.XPATH, using = "//*[@id='loginForm']/div[3]/div[2]/div/label") WebElement rememberEmailIDCheckBox;
	@FindBy (how = How.XPATH, using = "//*[@id='loginSubmit']") WebElement loginButton;
	@FindBy (how = How.XPATH, using = "/html/body/div[4]/div/div/div[3]/div[2]/div/div/button") WebElement closeButton;

	public void setLoginTabButton()
	{
		loginTabButton.click();
	}

	public void setEmailAddress(String EmailID)
	{
		emailAddress.clear();
		emailAddress.sendKeys(EmailID);
	}

	public void setPassword(String Password)
	{
		password.clear();
		password.sendKeys(Password);
	}

	public void setForgotPasswordLink()
	{
		forgotPasswordLink.click();
	}
	public void setRememberEmailIDCheckBox()
	{
		rememberEmailIDCheckBox.click();
	}

	public void setLoginButton()
	{
		loginButton.click();
	}
	
	public void setCloseButton()
	{
		closeButton.click();
	}

}
