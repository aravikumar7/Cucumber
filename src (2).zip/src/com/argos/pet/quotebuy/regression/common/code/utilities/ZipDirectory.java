package com.argos.pet.quotebuy.regression.common.code.utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;
import java.util.Properties;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

public class ZipDirectory {
	
    public static void main(String[] args) throws IOException, InterruptedException, MessagingException {
    	String sourceFile = System.getProperty("user.dir") + "/reports/allure-results-html";
        FileOutputStream fos = new FileOutputStream(System.getProperty("user.dir") + "/dirCompressed.zip");
      
        ZipOutputStream zipOut = new ZipOutputStream(fos);

/*String[] cmd = {"allure", "serve","H://Cardif/Argos_BS/Regression - Windows10Chrome/reports/allure-results"};
    Runtime.getRuntime().exec(cmd);
    Thread.sleep(10000);
 */
       File fileToZip = new File(sourceFile);
 
        zipFile(fileToZip, fileToZip.getName(), zipOut);
        zipOut.close();
        fos.close();
        System.out.println("zipped");
        sendEmail();
        System.out.println("sent mail");
    }
 
    private static void zipFile(File fileToZip, String fileName, ZipOutputStream zipOut) throws IOException {
        if (fileToZip.isHidden()) {
            return;
        }
        if (fileToZip.isDirectory()) {
            if (fileName.endsWith("/")) {
                zipOut.putNextEntry(new ZipEntry(fileName));
                zipOut.closeEntry();
            } else {
                zipOut.putNextEntry(new ZipEntry(fileName + "/"));
                zipOut.closeEntry();
            }
            File[] children = fileToZip.listFiles();
            for (File childFile : children) {
                zipFile(childFile, fileName + "/" + childFile.getName(), zipOut);
            }
            return;
        }
        FileInputStream fis = new FileInputStream(fileToZip);
        ZipEntry zipEntry = new ZipEntry(fileName);
        zipOut.putNextEntry(zipEntry);
        byte[] bytes = new byte[1024];
        int length;
        while ((length = fis.read(bytes)) >= 0) {
            zipOut.write(bytes, 0, length);
        }
        System.out.println("Completed Successfully");
        fis.close();
    }

    private static void sendEmail() throws IOException, MessagingException {
		
		
			  String FullResultTextFileName = "Report.txt";
			  String ExtentReportFileName = "AllureReport"; 
			  String EmailSubject = "Report"; 
			  String EmailBody ="Test report"; 
			  final String SendersEmailID ="cpcustomerportal@yahoo.com"; 
			  final String SendersEmailPassword ="xzytaxpkjdcifxnf"; 
			  String FirstEmailID ="ravikumar.arjunan@cardifpinnacle.com"; 
			  String SecondEmailID ="aravikumar7@rediffmail.com"; 
			  
	      // creates a new session with an authenticator
			Properties props = new Properties();  
			  props.setProperty("mail.transport.protocol", "smtp");     
			  props.setProperty("mail.smtp.host", "smtp.mail.yahoo.com");  
			  props.put("mail.smtp.auth", "true");  
			  //	  props.put("mail.smtp.port", "465");  
			  props.put("mail.debug", "true");  
			 props.put("mail.smtp.socketFactory.port", "465");  
			 props.put("mail.smtp.socketFactory.class","javax.net.ssl.SSLSocketFactory");  
			  props.put("mail.smtp.socketFactory.fallback", "true");  
			 props.put("mail.smtp.starttls.enable", "true");
			//	  props.put("mail.smtp.ssl.enable", "true");
			    props.put("mail.smtp.user", SendersEmailID);
			     props.put("mail.smtp.password", SendersEmailPassword);

			     
					      Session session = Session.getDefaultInstance(props,  
					    		    new javax.mail.Authenticator() {
					    		       protected PasswordAuthentication getPasswordAuthentication() {  
					    		       return new PasswordAuthentication(SendersEmailID,SendersEmailPassword);  
					    		   }  
					    		   });  
					      // creates a new e-mail message
					      Message msg = new MimeMessage(session);

					      msg.setFrom(new InternetAddress(SendersEmailID));
					      InternetAddress[] toAddresses = { new InternetAddress(FirstEmailID),new InternetAddress(SecondEmailID) };
					      msg.setRecipients(Message.RecipientType.TO, toAddresses);
					      msg.setSubject(EmailSubject);
					      msg.setSentDate(new Date());

					      // creates message part
					      MimeBodyPart messageBodyPart = new MimeBodyPart();
					      messageBodyPart.setContent(EmailBody, "text/html");

					      // creates multi-part
					      Multipart multipart = new MimeMultipart();
					      multipart.addBodyPart(messageBodyPart);

					      // adds attachments
					String file  = System.getProperty("user.dir") + "dirCompressed.zip";
					 
					          MimeBodyPart attachPart = new MimeBodyPart();
					              try {
					                  attachPart.attachFile(file);
					              } catch (IOException ex) {
					                  ex.printStackTrace();
					              }
					              multipart.addBodyPart(attachPart);
			
					      // sets the multi-part as e-mail's content
					      msg.setContent(multipart);

					      // sends the e-mail
					   //     Transport.connect();  
					 Transport.send(msg);  
					 //Transport.close();
					   }  
	}

