/**
 * 
 */
package com.argos.pet.quotebuy.regression.common.code.tests;

import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Parameters;
import org.testng.asserts.SoftAssert;

import com.argos.pet.quotebuy.regression.common.code.dbconnection.DBConnectionRegressionCommonCode;
import com.argos.pet.quotebuy.regression.common.code.pages.MoreAboutYourPetPage;
import com.argos.pet.quotebuy.regression.common.code.utilities.TestBase;
import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;
import com.codoid.products.fillo.Recordset;


public class MoreAboutYourPetTest extends TestBase {

	DBConnectionRegressionCommonCode dbConnectionCommonCode;
	Utilities utilities;
	MoreAboutYourPetPage moreAboutYourPet;
	TestBase testBase;
	AssumptionsTest assumptionsTest;
	MultiPetTest multiPetTest;
	SoftAssert softAssert;
	static String petInjuryIllness;
	String className;
	static ThreadLocal<String[]> regressionTestDataArray;
	public String TextToWrite;
	public String ClassName;
	JavascriptExecutor js;
	WebDriverWait wait; 

	@Parameters("ClassName")
	// @Test (priority = 1)
	public String initiateMoreAboutYourPetTest(String ClassName)
			throws Exception {
		utilities = new Utilities();
		moreAboutYourPet = new MoreAboutYourPetPage(driver);
		regressionTestDataArray = YourPetDetailsTest.regressionTestDataArray;
		className = utilities.getClassName(ClassName);
		js = (JavascriptExecutor) driver.get();
		String strQuery = "Select * from MoreAboutYourPet where TestClassName = '"
				+ className + "'";
		dbConnectionCommonCode = new DBConnectionRegressionCommonCode();
		Recordset recordset = dbConnectionCommonCode.recordset(strQuery);
		recordset.next();
		recordset.moveFirst();
		Thread.sleep(2500);
		utilities.waitForLoad(driver);
		if (!recordset.getField("CostOfThePet").equalsIgnoreCase(
				"I didn't pay anything")) {
			String CostOfThePet = recordset.getField("CostOfThePet");
			moreAboutYourPet.enterPetCost(CostOfThePet);
			TextToWrite = "Pet 1 Cost: " + CostOfThePet;
			utilities.Filewriter(TextToWrite);
		} else {
			moreAboutYourPet.selectIDidntPayAnything();
		}
		driver.get().switchTo().activeElement().sendKeys(Keys.TAB);
		Thread.sleep(700);
		if (recordset.getField("PetNeuteredRadioButton").equalsIgnoreCase("No")) {
			moreAboutYourPet.selectPetNeuteredNoRadioButton();
			TextToWrite = "Pet 1 Neutered = No";
			utilities.Filewriter(TextToWrite);
		}
		Thread.sleep(700);
		if (recordset.getField("PetNeuteredRadioButton").equalsIgnoreCase("Yes")) {
			moreAboutYourPet.selectPetNeuteredYesRadioButton();
			TextToWrite = "Pet 1 Neutered = Yes";
			utilities.Filewriter(TextToWrite);
		} else {
			moreAboutYourPet.selectPetNeuteredNoRadioButton();
		}
		petInjuryIllness = recordset.getField("PetAnyInjuryIllnessRadioButton");

		if (recordset.getField("PetAnyInjuryIllnessRadioButton").equalsIgnoreCase("No")) {
			moreAboutYourPet.selectPetAnyInjuryIllnessNoRadioButton();
			if (recordset.getField("PetType").equalsIgnoreCase("Do Not Test")) {
				String PetAnyInjuryIllnessNoTextMessage = moreAboutYourPet
						.getPetAnyInjuryIllnessNoTextMessage();
				softAssert = new SoftAssert();

				String noTextMessageFromExcel = recordset.getField("PetAnyInjuryIllnessNoTextMessage");
				String noTextMessageFromExcel2 = recordset.getField("PetAnyInjuryIllnessNoTextMessage_A");
				String noTextMessageFromExcel3 = recordset.getField("PetAnyInjuryIllnessNoTextMessage_B");
				String noTextMessageFromExcel4 = recordset.getField("PetAnyInjuryIllnessNoTextMessage_C");
			    String finalPetAnyInjuryIllnessNoTextMessage = noTextMessageFromExcel + (regressionTestDataArray.get())[0] + noTextMessageFromExcel2 + (regressionTestDataArray.get())[0] + noTextMessageFromExcel3 + (regressionTestDataArray.get())[0] + noTextMessageFromExcel4;
	            softAssert.assertEquals(PetAnyInjuryIllnessNoTextMessage,finalPetAnyInjuryIllnessNoTextMessage);
				softAssert.assertAll();
			}
			TextToWrite = "Pet 1 Injury Illness = No";
			utilities.Filewriter(TextToWrite);
		} else if (recordset.getField("PetAnyInjuryIllnessRadioButton").equalsIgnoreCase("Yes")) {
			moreAboutYourPet.selectPetAnyInjuryIllnessYesRadioButton();
			TextToWrite = "Pet 1 Injury Illness = Yes";
			utilities.Filewriter(TextToWrite);
		} else {
			moreAboutYourPet.selectPetAnyInjuryIllnessNoRadioButton();
		}
		if (recordset.getField("ChangeAssumptionLink").equals("Top")) {
			moreAboutYourPet.selectChangeAssumptionTopLink();
			assumptionsTest = new AssumptionsTest();
			assumptionsTest.initiateAssumptionsPage(className);
			moreAboutYourPet.selectAssumptionCorrectTickBox();
		} else if (recordset.getField("ChangeAssumptionLink").equals("Bottom")) {
			moreAboutYourPet.selectChangeAssumptionBottomLink();
			assumptionsTest = new AssumptionsTest();
			assumptionsTest.initiateAssumptionsPage(className);
			moreAboutYourPet.selectAssumptionCorrectTickBox();
		} else {
			moreAboutYourPet.selectAssumptionCorrectTickBox();
		}
		Thread.sleep(1500);

		//moreAboutYourPet.clickNextButton();
		//testBase = new TestBase();
		Thread.sleep(4000);
	//	utilities.waitElement(driver.get().findElement(By.xpath("//*[text()='Add another pet']")),driver);
		if (recordset.getField("MultiPet").equalsIgnoreCase("Yes")) {
			multiPetTest = new MultiPetTest();
			String numberOfMultiPetsString = null;
			multiPetTest.initiateMultiPetTest(numberOfMultiPetsString,className);
			}
		
		
		Thread.sleep(700);
		moreAboutYourPet.clickNextButton();
		Thread.sleep(2500);
		petInjuryIllness = recordset.getField("PetAnyInjuryIllnessRadioButtonBasedOnRisk");
		dbConnectionCommonCode.closeConnection();
		return petInjuryIllness;
	}
}