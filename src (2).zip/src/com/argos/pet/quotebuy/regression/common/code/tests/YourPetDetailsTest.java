/**
 * 
 */
package com.argos.pet.quotebuy.regression.common.code.tests;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Parameters;
import org.testng.asserts.SoftAssert;

import com.argos.pet.quotebuy.regression.common.code.dbconnection.DBConnectionRegressionCommonCode;
import com.argos.pet.quotebuy.regression.common.code.pages.YourPetDetailsPage;
import com.argos.pet.quotebuy.regression.common.code.utilities.TestBase;
import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;
import com.codoid.products.fillo.Recordset;


/**
 * @author d23747
 *
 */
public class YourPetDetailsTest extends TestBase {

	DBConnectionRegressionCommonCode dbConnectionCommonCode;
	Utilities utilities;
	YourPetDetailsPage yourPetDetailsPage;
	SoftAssert softAssert;
/*	String[] dobArray;
	String dateOfBirth;
	String className;
	public static String[] uniqueTestDataArray;
	public String TextToWrite;
	public static String[] regressionTestDataArray;
	public String ClassName;*/
	


	public ThreadLocal<String[]> dobArray = new ThreadLocal<String[]>();
	public ThreadLocal<String> dateOfBirth = new ThreadLocal<String>();
	public String className;
	public static ThreadLocal<String[]> uniqueTestDataArray = new ThreadLocal<String[]>();
	public String TextToWrite;
	public static ThreadLocal<String[]> regressionTestDataArray = new ThreadLocal<String[]>();
	public ThreadLocal<String> ClassName = new ThreadLocal<String>();
//	public ThreadLocal<> x = new ThreadLocal<>();
	

	@Parameters ("ClassName")
	public void initiateYourPetDetailsTest(String ClassName) throws Exception
	{
		utilities = new Utilities();
		className = utilities.getClassName(ClassName);
		System.out.println("Class"+className+ClassName);
		String  strQuery = "Select * from PetQuote where TestClassName = '" + className + "'";
		dbConnectionCommonCode = new DBConnectionRegressionCommonCode();
		Recordset recordset = dbConnectionCommonCode.recordset(strQuery);
		recordset.next();
		recordset.moveFirst();
		uniqueTestDataArray.set(utilities.getPetTestDataFromExcel(ClassName));
		softAssert = new SoftAssert();
		//regressionTestDataArray = utilities.getRegressionTestData(ClassName);
		regressionTestDataArray.set(utilities.getRegressionTestData(ClassName));
		yourPetDetailsPage = new YourPetDetailsPage(driver);
		utilities.waitForLoad(driver);
	//	String [] regdata=regressionTestDataArray.get();
		yourPetDetailsPage.setPetName((regressionTestDataArray.get())[0]);
		Thread.sleep(500);
			if (recordset.getField("PetType").equalsIgnoreCase("Dog"))
			{
				yourPetDetailsPage.setPetTypeDog();
			//	Thread.sleep(5000);
			//	yourPetDetailsPage.setPetName(regressionTestDataArray[0]);
				Thread.sleep(1000);
			//	utilities.waitElement(driver.get().findElement(By.xpath("//*[@id='breedDogType_1']")), driver);
				if (recordset.getField("TypeOfPet").equalsIgnoreCase("Breed"))
				{
					yourPetDetailsPage.selectDogBreed();
				//	yourPetDetailsPage.whatBreedQuestionTextField();
					Thread.sleep(500);
					yourPetDetailsPage.populateBreedType((regressionTestDataArray.get())[1]);
				//	yourPetDetailsPage.selectFromList();
					TextToWrite = "Pet: 1 Details: Full Name: " + (regressionTestDataArray.get())[0] + "	Dog Breed Type: " + (regressionTestDataArray.get())[1];
					utilities.Filewriter(TextToWrite);
				}
				else if (recordset.getField("TypeOfPet").equalsIgnoreCase("Crossbreed"))
				{
					yourPetDetailsPage.selectDogCrossBreed();
					Thread.sleep(500);
					yourPetDetailsPage.whatBreedQuestionTextField();
					yourPetDetailsPage.populateBreedType((regressionTestDataArray.get())[2]);
					yourPetDetailsPage.selectFromList();
					TextToWrite = "Pet: 1 Details: Full Name: " + (regressionTestDataArray.get())[0] + "	Dog Cross Breed Type: " + (regressionTestDataArray.get())[2];
					utilities.Filewriter(TextToWrite);
				}
				else if (recordset.getField("TypeOfPet").equalsIgnoreCase("Mongrel"))
				{
					yourPetDetailsPage.selectDogMongrel();
				//	utilities.waitElement(driver.get().findElement(By.xpath("//*[@id=\'mongrel148164\']")), driver);
					if ((regressionTestDataArray.get())[3].equalsIgnoreCase("Small"))
					{
						yourPetDetailsPage.selectSmallMongrel();
						TextToWrite = "Pet: 1 Details: Full Name: " + (regressionTestDataArray.get())[0] + "	Dog Type: Mongrel Small";
						utilities.Filewriter(TextToWrite);
					}
					else if ((regressionTestDataArray.get())[3].equalsIgnoreCase("Medium"))
					{
						yourPetDetailsPage.selectMediumMongrel();
						TextToWrite = "Pet: 1 Details: Full Name: " + (regressionTestDataArray.get())[0] + "	Dog Type: Mongrel Medium";
						utilities.Filewriter(TextToWrite);
					}
					else if ((regressionTestDataArray.get())[3].equalsIgnoreCase("Large"))
					{
						yourPetDetailsPage.selectLargeMongrel();
						TextToWrite = "Pet: 1 Details: Full Name: " + (regressionTestDataArray.get())[0] + "	Dog Type: Mongrel Large";
						utilities.Filewriter(TextToWrite);
					}
					else
					{
						yourPetDetailsPage.selectSmallMongrel();
					}
				}
				else
				{
					yourPetDetailsPage.selectDogBreed();
					yourPetDetailsPage.whatBreedQuestionTextField();
					yourPetDetailsPage.populateBreedType("Bulldog");
					yourPetDetailsPage.selectFromList();
				}
			}

			else if (recordset.getField("PetType").equalsIgnoreCase("Cat"))
			{
				yourPetDetailsPage.setPetTypeCat();
				
			//	if(recordset.getField("TypeOfPet").equalsIgnoreCase("Moggie")){
				if((regressionTestDataArray.get())[4].equalsIgnoreCase("Moggie")){
					((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//label[@for='moggie_pet1']")));
					driver.get().findElement(By.xpath("//label[@for='moggie_pet1']")).click();
				}
				else if((regressionTestDataArray.get())[4].equalsIgnoreCase("Domestic ShortHair")){
				//else if(recordset.getField("TypeOfPet").equalsIgnoreCase("Domestic ShortHair")){
					((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//label[@for='domestic-shorthair_pet1']")));
					driver.get().findElement(By.xpath("//label[@for='domestic-shorthair_pet1']")).click();
				}

			else if((regressionTestDataArray.get())[4].equalsIgnoreCase("British ShortHair")){
			//else if(recordset.getField("TypeOfPet").equalsIgnoreCase("British ShortHair")){
				((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//label[@for='british-shorthair_pet1']")));
					driver.get().findElement(By.xpath("//label[@for='british-shorthair_pet1']")).click();
				}
			//else if(regressionTestDataArray[4].equalsIgnoreCase("Crossbreed")){
			else if(recordset.getField("TypeOfPet").equalsIgnoreCase("Crossbreed")){
				((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//label[@for='cat-crossbreed_pet1']")));
					driver.get().findElement(By.xpath("//label[@for='cat-crossbreed_pet1']")).click();
				}
				else{
					((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//label[@for='cat-other_pet1']")));
					driver.get().findElement(By.xpath("//label[@for='cat-other_pet1']")).click();
					driver.get().switchTo().activeElement().sendKeys(Keys.TAB);
				//	utilities.waitElement(driver.get().findElement(By.xpath("//*[@id=\'whatBreedQuestion_1\']/div[1]/div[1]/div/div")), driver);
				//	yourPetDetailsPage.whatBreedQuestionTextField();
					Thread.sleep(500);
					yourPetDetailsPage.populateBreedType((regressionTestDataArray.get())[4]);
				//	yourPetDetailsPage.selectFromList();
				}
				
				TextToWrite = "Pet: 1 Details: Full Name: " + (regressionTestDataArray.get())[0] + "	Cat Type: " + (regressionTestDataArray.get())[4];
				utilities.Filewriter(TextToWrite);
			}
			else if (recordset.getField("PetType").equalsIgnoreCase("Rabbit")) {
				yourPetDetailsPage.setPetTypeRabbit();
				
				if((regressionTestDataArray.get())[18].equalsIgnoreCase("Lop-Mini")){
					((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//label[@for='lop-mini_pet1']")));
					driver.get().findElement(By.xpath("//label[@for='lop-mini_pet1']")).click();
				}
				else if((regressionTestDataArray.get())[18].equalsIgnoreCase("Lop-Dwarf")){
					((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//label[@for='lop-dwarf_pet1']")));
					driver.get().findElement(By.xpath("//label[@for='lop-dwarf_pet1']")).click();
				}

			else if((regressionTestDataArray.get())[18].equalsIgnoreCase("Non-Pedigree Rabbit")){
				((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//label[@for='non-pedigree_pet1']")));
					driver.get().findElement(By.xpath("//label[@for='non-pedigree_pet1']")).click();
				}
			else if((regressionTestDataArray.get())[18].equalsIgnoreCase("Lionhead")){
				((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//label[@for='lionhead_pet1']")));
					driver.get().findElement(By.xpath("//label[@for='lionhead_pet1']")).click();
				}
			else if((regressionTestDataArray.get())[18].equalsIgnoreCase("Netherlands Dwarf")){
				((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//label[@for='netherlands-dwarf_pet1']")));
					driver.get().findElement(By.xpath("//label[@for='netherlands-dwarf_pet1']")).click();
				}
				else{
					((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//label[@for='rabbit-other_pet1']")));
					driver.get().findElement(By.xpath("//label[@for='rabbit-other_pet1']")).click();
					yourPetDetailsPage.populateBreedType((regressionTestDataArray.get())[18]);
				}
				
				TextToWrite = "Pet: 1 Details: Full Name: " + (regressionTestDataArray.get())[0] + "	Rabbit Type: " + (regressionTestDataArray.get())[18];
				utilities.Filewriter(TextToWrite);
			}
			/*dateOfBirth = utilities.getDOB(regressionTestDataArray[5].replace(".", "/"));
			yourPetDetailsPage.populatedateOfBirth(dateOfBirth);
			
			TextToWrite = "Pet: 1 DOB: " + dateOfBirth;*/
			
			dobArray.set(utilities.getDOB((regressionTestDataArray.get())[5]));
			yourPetDetailsPage.populateDobDay((dobArray.get())[0]);
			yourPetDetailsPage.populateDobMonth((dobArray.get())[1]);
			yourPetDetailsPage.populateDobYear((dobArray.get())[2]);
			TextToWrite = "Pet: 1 DOB: " + (dobArray.get())[0] + "." + (dobArray.get())[1] + "." + (dobArray.get())[2];
			
		    utilities.Filewriter(TextToWrite);
		    
			if (recordset.getField("Sex").equalsIgnoreCase("Male"))
			{
				yourPetDetailsPage.selectMalePet();
				TextToWrite = "Pet: 1 Sex: Male";
				utilities.Filewriter(TextToWrite);
			}
			else
			{
				yourPetDetailsPage.selectFemalePet();
				TextToWrite = "Pet: 1 Sex: Female";
				utilities.Filewriter(TextToWrite);
			}
/*		if(driver.get().findElement(By.xpath("//div[text()='Next']//parent::button")).isEnabled())
			{
			yourPetDetailsPage.clickNextButton();
			}*/
			
		dbConnectionCommonCode.closeConnection();
	//	return (regressionTestDataArray.get());
	}
}
