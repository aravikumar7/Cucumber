/**
 * 
 */
package com.argos.pet.quotebuy.regression.common.code.tests;

import org.openqa.selenium.By;
import org.testng.annotations.Parameters;
import org.testng.asserts.SoftAssert;

import com.argos.pet.quotebuy.regression.common.code.dbconnection.DBConnectionRegressionCommonCode;
import com.argos.pet.quotebuy.regression.common.code.pages.ConfirmationPage;
import com.argos.pet.quotebuy.regression.common.code.utilities.TestBase;
import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;
import com.codoid.products.fillo.Recordset;


/**
 * @author d23747
 *
 */
public class ConfirmationTest extends TestBase {

	ConfirmationPage confirmationPage;
	Utilities utilities;
	DBConnectionRegressionCommonCode dbConnectionCommonCode;
	String[] confirmationArray;
	SoftAssert softAssert;
	static int numberOfMultiPetsInt;
	public String TextToWrite;
	public String ShortTextToWrite;
	String className;
	public String ClassName;
	String result;
	//RA - int tempPetNumber = 0;
	public static String[][] policyDetails;
	
	@Parameters ("ClassName")
	public void initiateConfirmationTest(String ClassName) throws Exception
	{
		confirmationPage = new ConfirmationPage(driver);
		utilities = new Utilities();
		softAssert = new SoftAssert();
		className = utilities.getClassName(ClassName);
		numberOfMultiPetsInt = MultiPetTest.numberOfMultiPets;
		String  strQuery = "Select * from MultiPet where TestClassName = '" + className + "'";
		dbConnectionCommonCode = new DBConnectionRegressionCommonCode();
		Recordset recordset = dbConnectionCommonCode.recordset(strQuery);
		recordset.next();
		recordset.moveFirst();
		int petNumber = 1;
		Thread.sleep(700);
		String petFullName = driver.get().findElement(By.xpath("(//div[contains(@class, 'pet-name')])[" + petNumber + "]")).getText();														
		String policyNumber = driver.get().findElement(By.xpath("(//div[@class='product-right']/div/div/div[1])[" + petNumber + "]")).getText();
		String coverType = driver.get().findElement(By.xpath("(//div[@class='product-details']/h2)[" + petNumber + "]")).getText();
		String monthlyCost = driver.get().findElement(By.xpath("(//ul[@class='product-benefits']/li[1]/span)[" + petNumber + "]")).getText();
		String policyStartDate = driver.get().findElement(By.xpath("//div[@class='start-policy-date__date']")).getText();
		TextToWrite = "Pet: 1 Name: " + petFullName + "	Cover: " + coverType + " Policy Number: " + policyNumber + " Monthly Cost: " + monthlyCost + " Start Date: " + policyStartDate;
		String[] annualCostArray = monthlyCost.split("\\(");
		String[] annualCostArray1 = annualCostArray[1].split(" ");
	//	System.out.println("cost : "+annualCostArray[1]+annualCostArray1[0]);
		ShortTextToWrite = "," + policyNumber + "," + annualCostArray1[0] + "," + "Start Date: " + policyStartDate;
		utilities.shortFilewriter(ShortTextToWrite);
		utilities.Filewriter(TextToWrite);
//	System.out.println("Policy New : "+driver.get().findElement(By.xpath("(//div[@class='product-right']/div/div/div[1])[" + petNumber + "]")).getText());
//	System.out.println("Policy : "+policyNumber+":");
		//	utilities.loadPolicy();
	//	Thread.sleep(5000);
		//result=utilities.searchPolicy(policyNumber,policyStartDate,monthlyCost,petFullName,coverType,"","");
		//softAssert.assertEquals(result,"0");
		
		policyDetails = new String[Integer.valueOf(recordset.getField("NumberOfMultiPets"))+1][5];
		policyDetails[0][0] = petFullName;
		policyDetails[0][1] = coverType;
		policyDetails[0][2] = policyNumber;
		policyDetails[0][3] = monthlyCost;
		policyDetails[0][4] = policyStartDate;
		
		
		if (recordset.getField("MultiPet").equalsIgnoreCase("Yes"))
		{
			if (Integer.valueOf(recordset.getField("NumberOfMultiPets")) > 0)
			{
				for (petNumber = 2; petNumber <= numberOfMultiPetsInt - 1; petNumber++)
				{
					 petFullName = driver.get().findElement(By.xpath("(//div[contains(@class, 'pet-name')])[" + petNumber + "]")).getText();														
					 coverType = driver.get().findElement(By.xpath("(//div[@class='product-details']/h2)[" + petNumber + "]")).getText();
					 policyNumber = driver.get().findElement(By.xpath("(//div[@class='d-md-none']/div[contains(@class,'policy-number-badge d-flex')]/div[contains(@class,'copy')])[" + petNumber + "]")).getText();
					 monthlyCost = driver.get().findElement(By.xpath("(//ul[@class='product-benefits'])[" + petNumber + "]")).getText();
					 policyStartDate = driver.get().findElement(By.xpath("//div[@class='start-policy-date__date']")).getText();
				
					
					
					policyDetails[petNumber-1][0] = petFullName;
					policyDetails[petNumber-1][1] = coverType;
					policyDetails[petNumber-1][2] = policyNumber;
					policyDetails[petNumber-1][3] = monthlyCost;
					policyDetails[petNumber-1][4] = policyStartDate;
					
					TextToWrite = "Pet: " + petNumber + " Name: " + petFullName + "	Cover: " + coverType + " Policy Number: " + policyNumber + " Monthly Cost: " + monthlyCost + " Start Date: " + policyStartDate;
					utilities.Filewriter(TextToWrite);
				//	result=utilities.searchPolicy(policyNumber,policyStartDate,monthlyCost,petFullName,coverType,MultiPetYourQuoteSummaryTest.breedType[petNumber-2],MultiPetYourQuoteSummaryTest.petDob[petNumber-2]);
				//	softAssert.assertEquals(result,"0");
				}
			}
		}
		dbConnectionCommonCode.closeConnection();
	}
}
