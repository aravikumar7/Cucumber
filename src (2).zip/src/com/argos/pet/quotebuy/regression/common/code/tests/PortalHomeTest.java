package com.argos.pet.quotebuy.regression.common.code.tests;

import org.openqa.selenium.By;
import org.testng.annotations.Parameters;
import org.testng.asserts.SoftAssert;

import com.argos.pet.quotebuy.regression.common.code.dbconnection.DBConnectionRegressionCommonCode;
import com.argos.pet.quotebuy.regression.common.code.pages.PortalHomePage;
import com.argos.pet.quotebuy.regression.common.code.utilities.TestBase;
import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;
import com.codoid.products.fillo.Recordset;



public class PortalHomeTest extends TestBase {

	YourPetDetailsTest yourPetDetailsTest;
	PortalHomePage portalHomePage;
	Utilities utilities;
	DBConnectionRegressionCommonCode dbConnectionCommonCode;
	SoftAssert softAssert;
	String className;
	public String ClassName;
	ThreadLocal<String[]> uniqueTestDataArray;
	public static String[][] policyInformation;
	public String TextToWrite;

	@Parameters ("ClassName")
	public void initiatePortalHomeTest(String ClassName) throws Exception
	{
		portalHomePage = new PortalHomePage(driver);
		utilities = new Utilities();
		softAssert = new SoftAssert();
		className = utilities.getClassName(ClassName);
		uniqueTestDataArray = YourPetDetailsTest.uniqueTestDataArray;
		policyInformation = ConfirmationTest.policyDetails;
		/*String  strQuery = "Select * from Home where TestClassName = '" + className + "'";
		dbConnectionCommonCode = new DBConnectionCommonCode();
		Recordset recordset = dbConnectionCommonCode.recordset(strQuery);
		recordset.next();
		recordset.moveFirst();*/

		String PetNameOnWeb = portalHomePage.getPetNameOnWeb();
		String PetCoverOnWeb = portalHomePage.getPetCoverOnWeb();
		String PolicyNumberOnWeb = portalHomePage.getPolicyNumberOnWeb();
		String CoverRemainingText = portalHomePage.getCoverRemainingText();
		String CoverRemainingValue = portalHomePage.getCoverRemainingValue();
		String TotalCoverOnweb = portalHomePage.getCoverTotal();
		String CoverUsedOnWeb = portalHomePage.getCoverUsed();
		
		for(int petCount=0;petCount<=policyInformation.length-1;petCount++)
		{
		PetNameOnWeb=driver.get().findElement(By.xpath("//*[@id='root']/div[3]/div[2]/main/div/div["+(petCount+2)+"]/div/div[1]/div[1]/div[2]/h3")).getText();
		PetCoverOnWeb=driver.get().findElement(By.xpath("//*[@id='root']/div[3]/div[2]/main/div/div["+(petCount+2)+"]/div/div[1]/div[1]/div[2]/h4")).getText();
		PolicyNumberOnWeb=driver.get().findElement(By.xpath("//*[@id='root']/div[3]/div[2]/main/div/div["+(petCount+2)+"]/div/div[1]/div[1]/div[2]/div")).getText();
		softAssert.assertEquals(PetNameOnWeb, policyInformation[petCount][0]);
		softAssert.assertEquals(PetCoverOnWeb, policyInformation[petCount][1]);
		softAssert.assertEquals(PolicyNumberOnWeb, policyInformation[petCount][2]);
		//softAssert.assertAll();
		
		TextToWrite = "PetNameOnWeb is: " + PetNameOnWeb + "PetCoverOnWeb is: " + PetCoverOnWeb + "PolicyNumberOnWeb is: " + PolicyNumberOnWeb +
		"CoverRemainingText is: " + CoverRemainingText + "CoverRemainingValue is: " + CoverRemainingValue + "TotalCoverOnweb is: " +
		TotalCoverOnweb + "CoverUsedOnWeb is: " + CoverUsedOnWeb;
		utilities.Filewriter(TextToWrite);
		}
		portalHomePage.setGoToDocumentsButton();

	}
}