/**
 * 
 */
package com.argos.pet.quotebuy.regression.common.code.utilities;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.apache.tika.parser.ocr.TesseractOCRConfig.OUTPUT_TYPE;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestNGMethod;
import org.testng.ITestResult;
import org.testng.Reporter;

import com.argos.pet.quotebuy.regression.common.code.dbconnection.DBConnectionRegressionCommonCode;
import com.argos.pet.quotebuy.regression.common.code.tests.ConfirmationTest;
import com.argos.pet.quotebuy.regression.tests.BaseClass;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.ChartLocation;
import com.aventstack.extentreports.reporter.configuration.Theme;

//import io.qameta.allure.Attachment;
/**
 * @author d23747
 *
 */
public class ListenersTest extends TestBase implements ITestListener {

	Utilities utilities;
	TestBase testBase = new TestBase();
	DBConnectionRegressionCommonCode dbConnectionRegressionCommonCode;
	ConfirmationTest confirmationTest;
	public String Filepath;
	public String TextToWrite;
	public String TestEnvName;
	public ExtentHtmlReporter htmlReporter;
	public ExtentReports extent;
	public ExtentTest logger;
	String[] ConfirmationArray;
	
	private static String getTestMethodName(ITestResult iTestResult){
		return iTestResult.getMethod().getConstructorOrMethod().getName();
		}
	
	public void onTestStart(ITestResult result) {
	System.out.println("I am on start method "+getTestMethodName(result)+" start");
		String timeStamp = new SimpleDateFormat("dd.MM.yyyy.HH.mm.ss").format(new Date());//time stamp
		String repName="Test_Report_"+timeStamp+".html";
		
		htmlReporter=new ExtentHtmlReporter(System.getProperty("user.dir")+ "/Results/"+repName);//specify location of the report
		htmlReporter.loadXMLConfig(System.getProperty("user.dir")+ "/extent-config.xml");
		
		extent=new ExtentReports();
		
		extent.attachReporter(htmlReporter);
		extent.setSystemInfo("Host name","localhost");
		extent.setSystemInfo("Environemnt","UAT15");
		extent.setSystemInfo("user","Ravikumar");
		
		htmlReporter.config().setDocumentTitle("Argos Pet Quote & Buy"); // Tile of report
		htmlReporter.config().setReportName("Argos Pet Quote & Buy Functional Test Automation Report"); // name of the report
		htmlReporter.config().setTestViewChartLocation(ChartLocation.TOP); //location of the chart
		htmlReporter.config().setTheme(Theme.DARK);

	}

	public void onTestSuccess(ITestResult result) {
		try
		{
			ThreadLocal<WebDriver> driver = TestBase.driver;
			utilities = new Utilities();
			dbConnectionRegressionCommonCode = new DBConnectionRegressionCommonCode();
			String timeStamp = new SimpleDateFormat("dd.MM.yyyy.HH.mm.ss").format(new Date());
			confirmationTest = new ConfirmationTest();
			//ConfirmationArray = confirmationTest.initiateConfirmationTest();
			String TextToWrite = "Executed on " + timeStamp + " is PASS";
			//utilities.shortFilewriter(TextToWrite);
			TextToWrite=TextToWrite + System.lineSeparator()+ result.getName();
			TextToWrite = TextToWrite + System.lineSeparator() + "****************************************************************************************";
		//	utilities.shortFilewriter(TextToWrite);
			TextToWrite = TextToWrite + System.lineSeparator() + "________________________________________________________________________________________";
			TextToWrite = TextToWrite + System.lineSeparator();
			TextToWrite = TextToWrite + System.lineSeparator() + "****************************************************************************************";
			utilities.Filewriter(TextToWrite);
			utilities.TakePassScreenShot(driver.get(), result.getName());
			System.out.println("Test Pass: " + result.getName());
			logger=extent.createTest(result.getName()); // create new entry in the report
			logger.log(Status.PASS,MarkupHelper.createLabel(result.getName(),ExtentColor.GREEN)); // send the passed information to the report with GREEN color highlighted
		} 
		catch (Exception e)
		{
			e.printStackTrace();
		}

	}

	public void onTestFailure(ITestResult result) {
		try
		{
			ThreadLocal<WebDriver> driver = TestBase.driver;
			utilities = new Utilities();
			dbConnectionRegressionCommonCode = new DBConnectionRegressionCommonCode();
			String timeStamp = new SimpleDateFormat("dd.MM.yyyy.HH.mm.ss").format(new Date());
			String TextToWrite = "Executed on " + timeStamp + " is FAIL";
			TextToWrite=TextToWrite + System.lineSeparator()+ result.getName();
			TextToWrite = TextToWrite + System.lineSeparator() + "****************************************************************************************";
			//utilities.shortFilewriter(", , Fail");
			//utilities.shortFilewriter(TextToWrite);
			TextToWrite = TextToWrite + System.lineSeparator() + "________________________________________________________________________________________";
			TextToWrite = TextToWrite + System.lineSeparator();
			TextToWrite = TextToWrite + System.lineSeparator() + "****************************************************************************************";
			utilities.Filewriter(TextToWrite);
			String failScreenShotPath = utilities.TakeFailScreenShot(driver.get(), result.getName());
		//	takeScreenShot(result.getMethod());
			//Object testClass=result.getInstance();
			//if(driver instanceof WebDriver) {
		//	takeScreenShot(driver);
		//	saveTextLog(getTestMethodName(result)+"failed and screenshot taken!");
			//}
			////////
		
			/////
			logger=extent.createTest(result.getName()); // create new entry in th report
			logger.log(Status.FAIL,MarkupHelper.createLabel(result.getName(),ExtentColor.RED)); // send the passed information to the report with GREEN color highlighted
			
			File f = new File(failScreenShotPath); 
			
			if(f.exists())
			{
			try {
				logger.fail("Screenshot is below:" + logger.addScreenCaptureFromPath(failScreenShotPath));
				} 
			catch (IOException e) 
					{
					e.printStackTrace();
					}
			}
			System.out.println("Test Fail: " + result.getName());
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}

	}

	////////////
	/*private void takeScreenShot(String name) throws IOException {
        String path = getRelativePath(name);
        File screenShot = ((TakesScreenshot) driver)
                .getScreenshotAs(OutputType.FILE);
        FileUtils.copyFile(screenShot, new File(path));
        String filename = makeScreenShotFileName(name);
        System.out.println("Taking Screenshot! " + filename);
        Reporter.log("<a href=" + path + " target='_blank' >" + filename
                + "</a>");
           }*/
/*	private void takeScreenShot(ITestNGMethod testMethod) throws IOException {
        String nameScreenShot = testMethod.getTestClass().getRealClass()
                .getSimpleName()
                + "_" + testMethod.getMethodName();
        takeScreenShot(nameScreenShot);
    }
	
private String makeScreenShotFileName(String name) {
        DateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy_hh.mm.ss");
        Date date = new Date();
        return dateFormat.format(date) + "_" + name + ".png";
    }
private String getRelativePath(String name) throws IOException {
        Path path = Paths.get(".", "target", "surefire-reports", "screenShots",
                makeScreenShotFileName(name));
        File directory = new File(path.toString());
        return directory.getCanonicalPath();
    }
*/
	/////
	
	
	
	
	public void onTestSkipped(ITestResult result) {
		System.out.println("test skip");
		
		logger=extent.createTest(result.getName()); // create new entry in th report
		logger.log(Status.SKIP,MarkupHelper.createLabel(result.getName(),ExtentColor.ORANGE));

	}

	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {

	}

	public void onFinish(ITestContext context) {

		System.out.println("I am on finish method "+context.getName());
	}
	
	//@Attachment(value = "Error_Screenshot", type = "image/png")
	/*
	@Attachment
    public byte[] takeScreenShot(WebDriver driver) throws IOException {
	// public void takeScreenShot(WebDriver driver) throws IOException {     
	//	  byte[] screenShot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
     //     Allure.getLifecycle().addAttachment(LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd-MMM-yy_hh:mm:ss")), "image/png", "png", screenShot);
			return ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
    }

	@Attachment(value="{0}",type="text/plain")
	public static String saveTextLog(String message){
	return message;
	}
*/
	@Override
	public void onStart(ITestContext iTestContext) {
		System.out.println("I am on start method "+iTestContext.getName());
		iTestContext.setAttribute("WebDriver", TestBase.driver);
	}
	
}
