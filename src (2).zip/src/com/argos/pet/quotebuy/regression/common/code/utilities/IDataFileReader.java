/**
 * 
 */
package com.argos.pet.quotebuy.regression.common.code.utilities;

/**
 * @author d23747
 *
 */

import java.util.List;

public interface IDataFileReader {
	public int rowNum(); // current row number!
	public List<String[]> readRows(int batchSize) throws Exception;
}
