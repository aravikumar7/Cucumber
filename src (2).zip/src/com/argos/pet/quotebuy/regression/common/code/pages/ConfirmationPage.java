/**
 * 
 */
package com.argos.pet.quotebuy.regression.common.code.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * @author d23747
 *
 */
public class ConfirmationPage {

	ThreadLocal<WebDriver> ldriver;

	public ConfirmationPage(ThreadLocal<WebDriver> driver)
	{
		ldriver = driver;
		PageFactory.initElements(driver.get(), this);
	}
	
	@FindBy (how = How.XPATH, using = "//*[@id='policyConfirmationContainer']/div[1]/div/div/div/div[2]/div[2]") WebElement coverType;
	@FindBy (how = How.XPATH, using = "//*[@id='policyConfirmationContainer']/div[1]/div/div/div/div[3]/div[2]") WebElement policyNumber;
	@FindBy (how = How.XPATH, using = "//*[@id='policyConfirmationContainer']/div[1]/div/div/div/div[4]/div[2]") WebElement monthlyCost;
	@FindBy (how = How.XPATH, using = "//*[@id='policyConfirmationContainer']/div[1]/div/div/div/div[5]/div[2]") WebElement policyStartDate;
	
	public String getCoverType()
	{
		String CoverType = coverType.getText();
		return CoverType;
	}
	
	public String getPolicyNumber()
	{
		String PolicyNumber = policyNumber.getText();
		return PolicyNumber;
	}
	
	public String getMonthlyCost()
	{
		String MonthlyCost = monthlyCost.getText();
		return MonthlyCost;
	}
	
	public String getPolicyStartDate()
	{
		String PolicyStartDate = policyStartDate.getText();
		return PolicyStartDate;
	}
}
