/**
 * 
 */
package com.argos.pet.quotebuy.regression.common.code.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * @author d23747
 *
 */
public class AssumptionsPage {

	ThreadLocal<WebDriver> ldriver;

	public AssumptionsPage (ThreadLocal<WebDriver> driver)
	{
		ldriver = driver;
		PageFactory.initElements(driver.get(), this);
	}

	@FindBy (how = How.XPATH, using = "//label[@for='pet_microchippedYes']") WebElement dogCatMicrochippedYes;
	@FindBy (how = How.XPATH, using = "//label[@for='pet_microchippedNo']") WebElement dogCatMicrochippedNo;
	@FindBy (how = How.XPATH, using = "//mark[contains(text(),'microchipped')]//parent::span//parent::div/following-sibling::div[2]/div") WebElement dogCatMicrochippedNoTextMessage;
	@FindBy (how = How.XPATH, using = "//label[@for='is_working_dogYes']") WebElement dogWorkingYes;
	@FindBy (how = How.XPATH, using = "//span[contains(text(),'Is he a ')]//parent::span//parent::div/following-sibling::div[2]/div") WebElement dogWorkingYesTextMessage;
	@FindBy (how = How.XPATH, using = "//label[@for='is_working_dogNo']") WebElement dogWorkingNo;
	@FindBy (how = How.XPATH, using = "//label[@for='rescue_homeYes']") WebElement dogCatFromRescueHomeYes;
	@FindBy (how = How.XPATH, using = "//label[@for='rescue_homeNo']") WebElement dogCatFromRescueHomeNo;
	@FindBy (how = How.XPATH, using = "//label[@for = 'pet_reside_same_addressYes']") WebElement dogCatAddressSameAsPolicyHolderYes;
	@FindBy (how = How.XPATH, using = "//label[@for = 'pet_reside_same_addressNo']") WebElement dogCatAddressSameAsPolicyHolderNo;
	@FindBy(how = How.XPATH, using = "//span[contains(text(),' permanently?')]//parent::span//parent::div/following-sibling::div[2]/div") WebElement dogCatAddressSameAsPolicyHolderNoTextMessage;
	@FindBy (how = How.XPATH, using = "//label[@for='iddYes']") WebElement dogCatVeterinaryNeedsYes;
	@FindBy (how = How.XPATH, using = "//label[@for='iddNo']") WebElement dogCatVeterinaryNeedsNo;
	@FindBy (how = How.XPATH, using = "//span[contains(text(),'re you looking for a policy ')]//parent::span//parent::div/following-sibling::div[2]/div") WebElement dogCatVeterinaryNeedsNoTextMessage;
	@FindBy (how = How.XPATH, using = "//label[@for = 'licensed_premisesYes']") WebElement dogAlchoholSoldPremisesYes;
	@FindBy (how = How.XPATH, using = "//span[contains(text(),'Do you or family members take')]//parent::span//parent::div/following-sibling::div[2]") WebElement dogAlchoholSoldPremisesYesTextMessage;;
	@FindBy (how = How.XPATH, using = "//label[@for = 'licensed_premisesNo']") WebElement dogAlchoholSoldPremisesNo;
	@FindBy (how = How.XPATH, using = "//label[@for='dog_behaviourYes']") WebElement dogBadBehaviourYes;
	@FindBy (how = How.XPATH, using = "//span[text()='Has anyone ever ']//parent::span//parent::div/following-sibling::div[2]") WebElement dogBadBehaviourYesTextMessage;;
	@FindBy (how = How.XPATH, using = "//label[@for='dog_behaviourNo']") WebElement dogBadBehaviourNo;
	@FindBy (how = How.XPATH, using = "//*[@id='morePetDetails_1']/div[2]/div/div/div/div/button[1]") WebElement backButton;
	@FindBy (how = How.XPATH, using = "//button[contains(text(),'Cancel')]") WebElement cancelButton;
			
	public WebElement getDogCatMicrochippedYes()
	{
		return dogCatMicrochippedYes;
	}
	public void setDogCatMicrochippedYes()
	{
		dogCatMicrochippedYes.click();
	}
	public WebElement getDogCatMicrochippedNo()
	{
		return dogCatMicrochippedNo;
	}
	public String getDogCatMicrochippedNoTextMessage()
	{
		String DogCatMicrochippedNoTextMessage = dogCatMicrochippedNoTextMessage.getText();
		return DogCatMicrochippedNoTextMessage;
	}
	
	public void setDogCatMicrochippedNo()
	{
		dogCatMicrochippedNo.click();
	}
	public WebElement getDogWorkingYes()
	{
		return dogWorkingYes;
	}
	public void setDogWorkingYes()
	{
		dogWorkingYes.click();
	}
	public String getDogWorkingYesTextMessage()
	{
		String DogWorkingYesTextMessage = dogWorkingYesTextMessage.getText();
		return DogWorkingYesTextMessage;
	}
	public WebElement getDogWorkingNo()
	{
		return dogWorkingNo;
	}
	public void setDogWorkingNo()
	{
		dogWorkingNo.click();
	}
	public WebElement getDogCatFromRescueHomeYes()
	{
		return dogCatFromRescueHomeYes;
	}
	public void setDogCatFromRescueHomeYes()
	{
		dogCatFromRescueHomeYes.click();
	}
	public WebElement getDogCatFromRescueHomeNo()
	{
		return dogCatFromRescueHomeNo;
	}
	public void setDogCatFromRescueHomeNo()
	{
		dogCatFromRescueHomeNo.click();
	}
	public WebElement getDogCatAddressSameAsPolicyHolderYes()
	{
		return dogCatAddressSameAsPolicyHolderYes;
	}
	public void setDogCatAddressSameAsPolicyHolderYes()
	{
		dogCatAddressSameAsPolicyHolderYes.click();
	}
	public WebElement getDogCatAddressSameAsPolicyHolderNo()
	{
		return dogCatAddressSameAsPolicyHolderNo;
	}
	public void setDogCatAddressSameAsPolicyHolderNo()
	{
		dogCatAddressSameAsPolicyHolderNo.click();
	}
	public String getDogCatAddressSameAsPolicyHolderNoTextMessage()
	{
		String DogCatAddressSameAsPolicyHolderNoTextMessage = dogCatAddressSameAsPolicyHolderNoTextMessage.getText();
		return DogCatAddressSameAsPolicyHolderNoTextMessage;
	}
	public WebElement getDogCatVeterinaryNeedsYes()
	{
		return dogCatVeterinaryNeedsYes;
	}
	public void setDogCatVeterinaryNeedsYes()
	{
		dogCatVeterinaryNeedsYes.click();
	}
	public WebElement getDogCatVeterinaryNeedsNo()
	{
		return dogCatVeterinaryNeedsNo;
	}
	public void setDogCatVeterinaryNeedsNo()
	{
		dogCatVeterinaryNeedsNo.click();
	}
	public String getDogCatVeterinaryNeedsNoTextMessage()
	{
		String DogCatVeterinaryNeedsNoTextMessage = dogCatVeterinaryNeedsNoTextMessage.getText();
		return DogCatVeterinaryNeedsNoTextMessage;
	}
	public WebElement getDogAlchoholSoldPremisesYes()
	{
		return dogAlchoholSoldPremisesYes;
	}
	public void setDogAlchoholSoldPremisesYes()
	{
		dogAlchoholSoldPremisesYes.click();
	}
	public String getDogAlchoholSoldPremisesYesTextMessage()
	{
		String DogAlchoholSoldPremisesYesTextMessage = dogAlchoholSoldPremisesYesTextMessage.getText();
		return DogAlchoholSoldPremisesYesTextMessage;
	}
	public WebElement getDogAlchoholSoldPremisesNo()
	{
		return dogAlchoholSoldPremisesNo;
	}
	public void setDogAlchoholSoldPremisesNo()
	{
		dogAlchoholSoldPremisesNo.click();
	}
	public WebElement getDogBadBehaviourYes()
	{
		return dogBadBehaviourYes;
	}
	public void setDogBadBehaviourYes()
	{
		dogBadBehaviourYes.click();
	}
	public String getDogBadBehaviourYesTextMessage()
	{
		String DogBadBehaviourYesTextMessage = dogBadBehaviourYesTextMessage.getText();
		return DogBadBehaviourYesTextMessage;
	}
	public WebElement getDogBadBehaviourNo()
	{
		return dogBadBehaviourNo;
	}
	public void setDogBadBehaviourNo()
	{
		dogBadBehaviourNo.click();
	}
	public void setBackButton()
	{
		backButton.click();
	}
	public void clickCancel() {
		cancelButton.click();
		
	}

}