/**
 * 
 */
package com.argos.pet.quotebuy.regression.common.code.tests;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Parameters;

import com.argos.pet.quotebuy.regression.common.code.dbconnection.DBConnectionRegressionCommonCode;
import com.argos.pet.quotebuy.regression.common.code.utilities.TestBase;
import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;
import com.codoid.products.fillo.Recordset;


/**
 * @author d23747
 *
 */
public class MultiPetTest extends TestBase{
	MultiPetYourPetDetailsTest multiPetYourPetDetailsTest;
	MultiPetMoreAboutYourPetTest multiPetMoreAboutYourPetTest;
	MultiPetYourCoverTest multiPetYourCoverTest;
	MultiPetYourQuoteSummaryTest multiPetYourQuoteSummaryTest;
	DBConnectionRegressionCommonCode dbConnectionCommonCode;
	Utilities utilities;
	String numberOfMultiPetsString;
	String className;
	static int numberOfMultiPets = 2;
	public String ClassName;
	static String[] multipetName;
	
	@Parameters ("ClassName")
	public int initiateMultiPetTest(String numberOfMultiPetsString, String ClassName) throws Exception
	{
		dbConnectionCommonCode = new DBConnectionRegressionCommonCode();
		utilities = new Utilities();
		className = utilities.getClassName(ClassName);
		String  strQuery = "Select * from MultiPet where TestClassName = '" + className + "'";
		Recordset recordset = dbConnectionCommonCode.recordset(strQuery);
		recordset.next();
		recordset.moveFirst();
		numberOfMultiPetsString = recordset.getField("NumberOfMultiPets");
		int numberOfMultiPetsInt = Integer.valueOf(numberOfMultiPetsString);
		numberOfMultiPetsInt = numberOfMultiPetsInt + 1;
		utilities.waitForLoad(driver);
		if (recordset.getField("MultiPet").equalsIgnoreCase("Yes"))
		{
			multipetName=new String[Integer.valueOf(recordset.getField("NumberOfMultiPets"))];
			
			for (numberOfMultiPets = 2; numberOfMultiPets <= numberOfMultiPetsInt; numberOfMultiPets ++)
			{
				multiPetYourPetDetailsTest = new MultiPetYourPetDetailsTest();
			multiPetYourPetDetailsTest.initiateMultiPetYourPetDetailsTest(className);
			multiPetMoreAboutYourPetTest = new MultiPetMoreAboutYourPetTest();
			multiPetMoreAboutYourPetTest.initiateMultiPetMoreAboutYourPetTest(className);
		/*	((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.id("pet1.pet_cost")));
			((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.id("pet1.pet_cost")));
			Thread.sleep(700);
			driver.get().findElement(By.id("pet1.pet_cost")).sendKeys(Keys.SPACE);
			Thread.sleep(700);
			*/
		/*	for(int j=2;j<=numberOfMultiPetsInt;j++){
				((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.id("pet"+(j-1)+".pet_cost")));
			//	Thread.sleep(700);
				((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.id("pet"+(j-1)+".pet_cost")));
				driver.get().findElement(By.id("pet"+(j-1)+".pet_cost")).sendKeys(Keys.SPACE);
			}*/
			//driver.get().findElement(By.xpath("//div[text()='Next']//parent::button")).click();
		//	((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//div[text()='Next']//parent::button")));
		//	((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//div[text()='Next']//parent::button")));
		//	Thread.sleep(700);
		}
	}
	dbConnectionCommonCode.closeConnection();
		return numberOfMultiPets;
	}
}
