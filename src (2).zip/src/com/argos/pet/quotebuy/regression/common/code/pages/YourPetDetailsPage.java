package com.argos.pet.quotebuy.regression.common.code.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.touch.TouchActions;
import org.openqa.selenium.remote.Augmenter;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;

import net.bytebuddy.asm.Advice.Enter;

public class YourPetDetailsPage {

	public static ThreadLocal<WebDriver> ldriver;
	Utilities utilities;


	public YourPetDetailsPage(ThreadLocal<WebDriver> driver)
	{
		ldriver = driver;
		PageFactory.initElements(driver.get(), this);
	}

	@FindBy (how = How.ID, using = "pet1.pet_name") WebElement petName;
	@FindBy (how = How.ID, using = "radio_dog_pet1") WebElement petTypeDog;
	@FindBy (how = How.ID, using = "radio_cat_pet1") WebElement petTypeCat;
	@FindBy (how = How.ID, using = "radio_rabbit_pet1") WebElement petTypeRabbit;
	@FindBy (how = How.XPATH, using = "//*[@id='pet1.pet_nameContainer']/div") WebElement petNameErrorMessage;
	@FindBy (how = How.XPATH, using = "//*[@id='petDetailsForm_1']/div[1]/div[1]/div/fieldset/label") WebElement petNameDogMessage;
	@FindBy (how = How.XPATH, using = "//*[@id='petDetailsForm_1']/div[1]/div[1]/div/fieldset/label") WebElement petNameCatMessage;
	@FindBy (how = How.XPATH, using = "//*[@id=\'petDetailsForm_1\']/div[1]/div[1]/div/fieldset/div/p") WebElement petNameErrorLongMessage;
	@FindBy (how = How.XPATH, using = "//*[@id='breed_pet1']") WebElement dogBreed;
	@FindBy (how = How.XPATH, using = "//*[@id='crossbreed_pet1']") WebElement dogCrossBreed;
	@FindBy (how = How.XPATH, using = "//*[@id='mongrel_pet1']") WebElement dogMongrel;
	@FindBy (how = How.XPATH, using = "//*[@id='mongrel-smallpet1']") WebElement smallMongrel;
	@FindBy (how = How.XPATH, using = "//*[@id='mongrel-mediumpet1']") WebElement mediumMongrel;
	@FindBy (how = How.XPATH, using = "//*[@id='mongrel-largepet1']") WebElement largeMongrel;
	@FindBy (how = How.ID, using = "moggie_pet1") WebElement moggie;
	@FindBy (how = How.ID, using = "domestic-shorthair_pet1") WebElement domesticShortHair;
	@FindBy (how = How.ID, using = "british-shorthair_pet1") WebElement britishShortHair;
	@FindBy (how = How.ID, using = "cat-crossbreed_pet1") WebElement crossBreed;
	@FindBy (how = How.ID, using = "cat-other_pet1") WebElement catOthers;

	@FindBy (how = How.XPATH, using = "//*[@id='pet1.pet_breed']/div/div[1]/div[1]") WebElement whatBreedQuestion;
	@FindBy (how = How.XPATH, using = "//*[@id='pet1.pet_breed']/div/div[1]/div[1]") WebElement whatBreedQuestionText;
	@FindBy (how = How.XPATH, using = "//*[@id='pet1.dateDayName']") WebElement dobDay;
	@FindBy (how = How.XPATH, using = "//*[@id='pet1.dateMonthName']") WebElement dobMonth;
	@FindBy (how = How.XPATH, using = "//*[@id='pet1.dateYearName']") WebElement dobYear;
	@FindBy (how = How.ID, using = "pet1.pet_date_of_birth") WebElement dob;
	@FindBy (how = How.XPATH, using = "//label[contains(@for,'male_radio_1pet1')]") WebElement malePet;
	@FindBy (how = How.XPATH, using = "//label[contains(@for,'female_radio_1pet1')]") WebElement femalePet;
	@FindBy (how = How.XPATH, using = "//button[@type='submit']") WebElement nextButton;
	
	public void setPetName(String fullPetName) throws InterruptedException
	{
		JavascriptExecutor js = (JavascriptExecutor) ldriver.get();
	//	petName.sendKeys(fullPetName);
	//	petName.sendKeys(Keys.TAB);
	/*	petName.sendKeys(fullPetName);
		petName.sendKeys(Keys.UP);
		Thread.sleep(10000);
		petName.sendKeys(fullPetName); 
		petName.sendKeys(Keys.RETURN);*/
	//	Actions action =new Actions(ldriver);
	//	Actions actions = new Actions(ldriver);
		
	//	actions.sendKeys(Keys.RETURN).click(target)petName.click();
	//	Thread.sleep(5000);
		petName.sendKeys(fullPetName,Keys.TAB);
	//	Thread.sleep(5000);
		//TouchActions tapAction = new TouchActions((new Augmenter().augment(ldriver))).singleTap(petTypeDog);
	      //  tapAction.perform();
		
	//	petName.sendKeys(Keys.TAB);
	//	actions.sendKeys(Keys.TAB).build().perform();
		//ldriver.findElement(By.xpath("//XCUIElementTypeTextField[contains(@id,'pet1.pet_name')]")).sendKeys("aerobatic");
	//	ldriver.findElement(By.xpath("//XCUIElementTypeSecureTextField[@value='password']")).sendKeys("aerobatic");

		//action.sendKeys("Keys.TAB");
	//	js.executeScript("arguments[0].setAttribute('innerHTML','name')", petName);
	//	js.executeScript("document.getElementById('pet1.pet_name').setAttribute('value', 'name')");
	}

	public void setPetTypeDog()
	{
		petTypeDog.click();
		//TouchActions tapAction = new TouchActions((new Augmenter().augment(ldriver))).singleTap(petTypeDog);
	    //tapAction.perform();
	}

	public void setPetTypeCat()
	{
		petTypeCat.click();
	}

	public void setPetTypeRabbit() {
		petTypeRabbit.click();
	}
	public String setPetNameErrorMessage()
	{
		String petNameErrorText = petNameErrorMessage.getText();
		return petNameErrorText;
	}

	public String setPetNameDogMessage()
	{
		String petNameDogText = petNameDogMessage.getText();
		return petNameDogText;
	}

	public String setPetNameCatMessage()
	{
		String petNameCatText = petNameCatMessage.getText();
		return petNameCatText;
	}

	public String setPetNameErrorLongMessage()
	{
		String petNameErrorLongText = petNameErrorLongMessage.getText();
		return petNameErrorLongText;
	}

	public void selectDogBreed()
	{
	//	dogBreed.click();
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", dogBreed);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", dogBreed);	
		ldriver.get().switchTo().activeElement().sendKeys(Keys.TAB);
	}
	
	public void selectDogCrossBreed()
	{
		//dogCrossBreed.click();
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", dogCrossBreed);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", dogCrossBreed);	
		ldriver.get().switchTo().activeElement().sendKeys(Keys.TAB);
	}
	
	public void selectDogMongrel()
	{
		//dogMongrel.click();
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", dogMongrel);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", dogMongrel);	
	}
	
	public void selectSmallMongrel()
	{
		//smallMongrel.click();	
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", smallMongrel);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", smallMongrel);	
	}
	
	public void selectMediumMongrel()
	{
		//mediumMongrel.click();
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", mediumMongrel);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", mediumMongrel);	
	}
	
	public void selectLargeMongrel()
	{
		//largeMongrel.click();
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", largeMongrel);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", largeMongrel);	
	}
	public void setPetTypeCatMoggie() {
		//moggie.click();
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", moggie);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", moggie);
	}

	public void setPetTypeCatDomesticSH() {
		//domesticShortHair.click();
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", domesticShortHair);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", domesticShortHair);	
	}

	public void setPetTypeCatBritishSH() {
		//britishShortHair.click();
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", britishShortHair);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", britishShortHair);	
	}

	public void setPetTypeCatCrossBreed() {
		//crossBreed.click();
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", crossBreed);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", crossBreed);	
	}
	public void setPetTypeCatOthers() {
		//catOthers.click();
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", catOthers);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", catOthers);	
	}
	public void whatBreedQuestionTextField()
	{
		//whatBreedQuestion.click();
	}

	public void populateBreedType(String dogBreed) throws InterruptedException
	{		
		//Actions builder = new Actions(ldriver);
	/*	((JavascriptExecutor) ldriver).executeScript("arguments[0].scrollIntoView(true);", ldriver.findElement(By.xpath("//*[@id='react-select-2-input']")));
				ldriver.findElement(By.xpath("//*[@id='react-select-2-input']")).sendKeys(dogBreed,Keys.ENTER);
				Thread.sleep(5000);
				*/

		WebElement breed=ldriver.get().findElement(By.id("pet1.pet_breed"));
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", breed);
		Thread.sleep(500);
		breed.click();
		Thread.sleep(500);
		WebElement petbreed=ldriver.get().findElement(By.xpath("//div[contains(@class,'react-select__menu-list')]")).findElement(By.xpath(String.format(".//div[text()='%s']", dogBreed)));
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", petbreed);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", petbreed);	
				
				
	}
	
	public void selectFromList() throws InterruptedException
	{
	//	Actions builder = new Actions(ldriver);
		
	//	builder.sendKeys(Keys.ARROW_DOWN).perform();
		//builder.sendKeys(Keys.ENTER).perform();
	//	Thread.sleep(5000);
		//whatBreedQuestionText.sendKeys(Keys.ARROW_DOWN);
		//Thread.sleep(5000);
		//whatBreedQuestionText.sendKeys(Keys.ENTER);
	}

	public void populateDobDay(String dob_day) throws InterruptedException
	{
		//dobDay.clear();
		dobDay.sendKeys(Keys.BACK_SPACE);
		dobDay.sendKeys(Keys.BACK_SPACE);
		dobDay.sendKeys(dob_day);
		
	/*	((JavascriptExecutor) ldriver).executeScript("arguments[0].scrollIntoView(true);", dobDay);
	Thread.sleep(700);
		((JavascriptExecutor) ldriver).executeScript("arguments[0].focus(); arguments[0].blur(); return true", dobDay);
		((JavascriptExecutor) ldriver).executeScript("let input = arguments[0];var setValue = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;setValue.call(input, '" + dob_day + "');var e = new Event('input', { bubbles: true });input.dispatchEvent(e);", dobDay);
		((JavascriptExecutor) ldriver).executeScript("document.getElementById('daySelectDob_1').blur()");
		Thread.sleep(1500);
		*/
	}

	public void populateDobMonth(String dob_month) throws InterruptedException
	{
		dobMonth.clear();
		dobMonth.sendKeys(dob_month);
		/*((JavascriptExecutor) ldriver).executeScript("arguments[0].scrollIntoView(true);", dobMonth);
		Thread.sleep(700);
			((JavascriptExecutor) ldriver).executeScript("arguments[0].focus(); arguments[0].blur(); return true", dobMonth);
			((JavascriptExecutor) ldriver).executeScript("let input = arguments[0];var setValue = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;setValue.call(input, '" + dob_month + "');var e = new Event('input', { bubbles: true });input.dispatchEvent(e);", dobMonth);
			((JavascriptExecutor) ldriver).executeScript("document.getElementById('pet1.pet_date_of_birth').blur()");
			Thread.sleep(1500);*/
	}

	public void populateDobYear (String dob_year) throws InterruptedException
	{
		dobYear.clear();
		dobYear.sendKeys(dob_year);
		Thread.sleep(500);
		dobYear.sendKeys(Keys.TAB);
		
		/*Thread.sleep(700);
		((JavascriptExecutor) ldriver).executeScript("arguments[0].focus(); arguments[0].blur(); return true", dobYear);
		((JavascriptExecutor) ldriver).executeScript("let input = arguments[0];var setValue = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;setValue.call(input, '" + dob_year + "');var e = new Event('input', { bubbles: true });input.dispatchEvent(e);", dobYear);
		((JavascriptExecutor) ldriver).executeScript("document.getElementById('pet1.pet_date_of_birth').blur()");
		Thread.sleep(1500);*/
	}


	public void selectMalePet()
	{
		//malePet.click();
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", malePet);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", malePet);
	}

	public void selectFemalePet()
	{
		//femalePet.click();
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", femalePet);
	}

	public void clickNextButton()
	{
	//	nextButton.click();
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", nextButton);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", nextButton);
	
	}

	public void populatedateOfBirth(String dateOfBirth) throws InterruptedException {
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", dob);
	Thread.sleep(700);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].focus(); arguments[0].blur(); return true", dob);
		((JavascriptExecutor) ldriver.get()).executeScript("let input = arguments[0];var setValue = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;setValue.call(input, '" + dateOfBirth + "');var e = new Event('input', { bubbles: true });input.dispatchEvent(e);", dob);
		((JavascriptExecutor) ldriver.get()).executeScript("document.getElementById('pet1.pet_date_of_birth').blur()");
		Thread.sleep(1500);
	}

	
}
