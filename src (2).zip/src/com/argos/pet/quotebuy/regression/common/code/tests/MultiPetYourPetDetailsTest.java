/**
 * 
 */
package com.argos.pet.quotebuy.regression.common.code.tests;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.testng.annotations.Parameters;
import org.testng.asserts.SoftAssert;

import com.argos.pet.quotebuy.regression.common.code.dbconnection.DBConnectionRegressionCommonCode;
import com.argos.pet.quotebuy.regression.common.code.pages.YourPetDetailsPage;
import com.argos.pet.quotebuy.regression.common.code.utilities.TestBase;
import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;
import com.codoid.products.fillo.Recordset;


/**
 * @author d23747
 *
 */
public class MultiPetYourPetDetailsTest extends TestBase {

	DBConnectionRegressionCommonCode dbConnectionCommonCode;
	Utilities utilities;
	YourPetDetailsPage yourPetDetailsPage;
	MultiPetTest multiPetTest;
	SoftAssert softAssert;
	String[] dobArray;
	String className;
	String dateOfBirth;
	static String[] multiPetUniqueTestDataArray;
	static int numberOfMultiPetsInt;
	public String TextToWrite;
	public String ClassName;
	
	@Parameters ("ClassName")
	public String[] initiateMultiPetYourPetDetailsTest(String ClassName) throws Exception
	{
		utilities = new Utilities();
		className = utilities.getClassName(ClassName);
		numberOfMultiPetsInt = MultiPetTest.numberOfMultiPets;
		String  strQuery = "Select * from MultiPet where TestClassName = '" + className + "'";
		dbConnectionCommonCode = new DBConnectionRegressionCommonCode();
		Recordset recordset = dbConnectionCommonCode.recordset(strQuery);
		recordset.next();
		recordset.moveFirst();
		softAssert = new SoftAssert();
		Actions actions = new Actions(driver.get());
		yourPetDetailsPage = new YourPetDetailsPage(driver);
		System.out.println("No. of pets is : "+numberOfMultiPetsInt);
		utilities.waitForLoad(driver);
		if (recordset.getField("MultiPet").equalsIgnoreCase("Yes"))
		{
			if (Integer.valueOf(recordset.getField("NumberOfMultiPets")) > 0)
			{
				Thread.sleep(500);
				((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//*[text()='Add another pet']")));
				Thread.sleep(700);
				((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//*[text()='Add another pet']")));
				
				multiPetUniqueTestDataArray = utilities.getMultiPetTestDataFromExcel(ClassName, numberOfMultiPetsInt);
				MultiPetTest.multipetName[numberOfMultiPetsInt-2]=multiPetUniqueTestDataArray[0];
				//System.out.println(numberOfMultiPetsInt-2+":"+MultiPetTest.multipetName[numberOfMultiPetsInt-2]);
				utilities.waitElement(driver.get().findElement(By.id("pet"+numberOfMultiPetsInt + ".pet_name")), driver);
				driver.get().findElement(By.id("pet"+numberOfMultiPetsInt + ".pet_name")).sendKeys(multiPetUniqueTestDataArray[0]);

				if (recordset.getField("MultiPetType_" + (numberOfMultiPetsInt-1) + "").equalsIgnoreCase("Dog"))
				{
					((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//*[@id='radio_dog_pet" + numberOfMultiPetsInt + "']")));
					((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//*[@id='radio_dog_pet" + numberOfMultiPetsInt + "']")));
					utilities.waitElement(driver.get().findElement(By.xpath("//*[@for='breed_pet" + numberOfMultiPetsInt + "']")), driver);
					if (recordset.getField("MultiPetTypeOfDog_" + (numberOfMultiPetsInt-1) + "").equalsIgnoreCase("Breed"))
					{	
						((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//*[@for='breed_pet" + numberOfMultiPetsInt + "']")));
						((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//*[@for='breed_pet" + numberOfMultiPetsInt + "']")));
						Thread.sleep(500);
						Actions builder = new Actions(driver.get());
						driver.get().findElement(By.xpath("//div[@id='pet"+ numberOfMultiPetsInt + ".pet_breed']/div/div/div/div/input")).sendKeys(multiPetUniqueTestDataArray[1]);
						Thread.sleep(1000);
						builder.sendKeys(Keys.ENTER).perform();
						
						
						TextToWrite = "Pet " + numberOfMultiPetsInt + " Details: Full Name: " + multiPetUniqueTestDataArray[0] + " Dog Breed Type: " + multiPetUniqueTestDataArray[1];
						utilities.Filewriter(TextToWrite);
					}
					else if (recordset.getField("MultiPetTypeOfDog_" + (numberOfMultiPetsInt-1) + "").equalsIgnoreCase("Crossbreed"))
					{
						((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//*[@id='crossbreedDogType_" + numberOfMultiPetsInt + "']")));
						((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//*[@id='crossbreedDogType_" + numberOfMultiPetsInt + "']")));
						Thread.sleep(500);
						Actions builder = new Actions(driver.get());
							driver.get().findElement(By.xpath("//div[@id='pet"+ numberOfMultiPetsInt + ".pet_breed']/div/div/div/div/input")).sendKeys(multiPetUniqueTestDataArray[1]);
							Thread.sleep(1000);
							builder.sendKeys(Keys.ENTER).perform();
						
						TextToWrite = "Pet " + numberOfMultiPetsInt + " Details: Full Name: " + multiPetUniqueTestDataArray[0] + " Dog Crossbreed Type: " + multiPetUniqueTestDataArray[2];
						utilities.Filewriter(TextToWrite);
					}
					else if (recordset.getField("MultiPetTypeOfDog_" + (numberOfMultiPetsInt-1) + "").equalsIgnoreCase("Mongrel"))
					{
						((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//*[@for='mongrel_pet" + numberOfMultiPetsInt + "']")));
						((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//*[@for='mongrel_pet" + numberOfMultiPetsInt + "']")));
//						utilities.waitElement(driver.get().findElement(By.xpath("//*[@for='mongrel-smallpet" + numberOfMultiPetsInt + "']")), driver.get());
if (multiPetUniqueTestDataArray[3].equalsIgnoreCase("Small"))
						{
							Thread.sleep(1000);
						//	driver.get().findElement(By.xpath("//*[@id='mongrel-smallpet" + numberOfMultiPetsInt + "']")).click();
							((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//*[@for='mongrel-smallpet" + numberOfMultiPetsInt + "']")));
							((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//*[@for='mongrel-smallpet" + numberOfMultiPetsInt + "']")));
				
							TextToWrite = "Pet " + numberOfMultiPetsInt + " Details: Full Name: " + multiPetUniqueTestDataArray[0] + " Dog Type: Mongrel Small";
							utilities.Filewriter(TextToWrite);
						}
						else if (multiPetUniqueTestDataArray[3].equalsIgnoreCase("Medium"))
						{
							Thread.sleep(1000);
						//	driver.get().findElement(By.xpath("//*[@id='mongrel-mediumpet" + numberOfMultiPetsInt + "']")).click();
							((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//*[@for='mongrel-mediumpet" + numberOfMultiPetsInt + "']")));
							((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//*[@for='mongrel-mediumpet" + numberOfMultiPetsInt + "']")));
				
							TextToWrite = "Pet " + numberOfMultiPetsInt + " Details: Full Name: " + multiPetUniqueTestDataArray[0] + " Dog Type: Mongrel Medium";
							utilities.Filewriter(TextToWrite);
						}
						else if (multiPetUniqueTestDataArray[3].equalsIgnoreCase("Large"))
						{
							Thread.sleep(1000);
							((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//*[@for='mongrel-largepet" + numberOfMultiPetsInt + "']")));
							((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//*[@for='mongrel-largepet" + numberOfMultiPetsInt + "']")));
					
							TextToWrite = "Pet " + numberOfMultiPetsInt + " Details: Full Name: " + multiPetUniqueTestDataArray[0] + " Dog Type: Mongrel Large";
							utilities.Filewriter(TextToWrite);
						}
					}
				}

				else if (recordset.getField("MultiPetType_" + (numberOfMultiPetsInt-1) + "").equalsIgnoreCase("Cat"))
				{
					Thread.sleep(1000);
					((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//*[@id='radio_cat_pet" + numberOfMultiPetsInt + "']")));
					((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//*[@id='radio_cat_pet" + numberOfMultiPetsInt + "']")));
					
					TextToWrite = "Pet " + numberOfMultiPetsInt + " Details: Full Name: " + multiPetUniqueTestDataArray[0] + " Cat Type: " + multiPetUniqueTestDataArray[4];
					utilities.Filewriter(TextToWrite);
				//
					if (recordset.getField("MultiPetTypeOfDog_" + (numberOfMultiPetsInt-1) + "").equalsIgnoreCase("Moggie")){
						Thread.sleep(1000);
						((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//*[@for='moggie_pet" + numberOfMultiPetsInt + "']")));
						((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//*[@for='moggie_pet" + numberOfMultiPetsInt + "']")));
						}
					else if (recordset.getField("MultiPetTypeOfDog_" + (numberOfMultiPetsInt-1) + "").equalsIgnoreCase("Domestic ShortHair")){
						Thread.sleep(1000);
						((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//*[@for='domestic-shorthair_pet" + numberOfMultiPetsInt + "']")));
						((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//*[@for='domestic-shorthair_pet" + numberOfMultiPetsInt + "']")));
						}
					else if (recordset.getField("MultiPetTypeOfDog_" + (numberOfMultiPetsInt-1) + "").equalsIgnoreCase("British ShortHair")){
						Thread.sleep(1000);
						((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//*[@for='british-shorthair_pet" + numberOfMultiPetsInt + "']")));
						((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//*[@for='british-shorthair_pet" + numberOfMultiPetsInt + "']")));
						}
					else if (recordset.getField("MultiPetTypeOfDog_" + (numberOfMultiPetsInt-1) + "").equalsIgnoreCase("Crossbreed")){
						Thread.sleep(1500);
						((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//*[@for='cat-crossbreed_pet" + numberOfMultiPetsInt + "']")));
						((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//*[@for='cat-crossbreed_pet" + numberOfMultiPetsInt + "']")));
						}
					else{
						Thread.sleep(1000);
						((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//*[@for='cat-other_pet" + numberOfMultiPetsInt + "']")));
						((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//*[@for='cat-other_pet" + numberOfMultiPetsInt + "']")));
						Thread.sleep(500);
						Actions builder = new Actions(driver.get());
							driver.get().findElement(By.xpath("//div[@id='pet"+ numberOfMultiPetsInt + ".pet_breed']/div/div/div/div/input")).sendKeys(multiPetUniqueTestDataArray[4]);
							Thread.sleep(1000);
							builder.sendKeys(Keys.ENTER).perform();
					}
					TextToWrite = "Pet " + numberOfMultiPetsInt + " Details: Full Name: " + multiPetUniqueTestDataArray[0] + " Cat Type: " + multiPetUniqueTestDataArray[4];
					utilities.Filewriter(TextToWrite);
				}
				else if (recordset.getField("MultiPetType_" + (numberOfMultiPetsInt-1) + "").equalsIgnoreCase("Rabbit"))
				{
					Thread.sleep(1000);
					((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//*[@id='radio_rabbit_pet" + numberOfMultiPetsInt + "']")));
					((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//*[@id='radio_rabbit_pet" + numberOfMultiPetsInt + "']")));
					
					TextToWrite = "Pet " + numberOfMultiPetsInt + " Details: Full Name: " + multiPetUniqueTestDataArray[0] + " Rabbit Type: " + multiPetUniqueTestDataArray[17];
					utilities.Filewriter(TextToWrite);
				//
					if (recordset.getField("MultiPetTypeOfDog_" + (numberOfMultiPetsInt-1) + "").equalsIgnoreCase("Lop-Mini")){
						Thread.sleep(1000);
						((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//*[@for='lop-mini_pet" + numberOfMultiPetsInt + "']")));
						((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//*[@for='lop-mini_pet" + numberOfMultiPetsInt + "']")));
						}
					else if (recordset.getField("MultiPetTypeOfDog_" + (numberOfMultiPetsInt-1) + "").equalsIgnoreCase("Lop-Dwarf")){
						Thread.sleep(1000);
						((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//*[@for='lop-dwarf_pet" + numberOfMultiPetsInt + "']")));
						((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//*[@for='lop-dwarf_pet" + numberOfMultiPetsInt + "']")));
						}
					else if (recordset.getField("MultiPetTypeOfDog_" + (numberOfMultiPetsInt-1) + "").equalsIgnoreCase("Non-Pedigree Rabbit")){
						Thread.sleep(1000);
						((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//*[@for='non-pedigree_pet" + numberOfMultiPetsInt + "']")));
						((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//*[@for='non-pedigree_pet" + numberOfMultiPetsInt + "']")));
						}
					else if (recordset.getField("MultiPetTypeOfDog_" + (numberOfMultiPetsInt-1) + "").equalsIgnoreCase("Lionhead")){
						Thread.sleep(1000);
						((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//*[@for='lionhead_pet" + numberOfMultiPetsInt + "']")));
						((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//*[@for='lionhead_pet" + numberOfMultiPetsInt + "']")));
						}
					else if (recordset.getField("MultiPetTypeOfDog_" + (numberOfMultiPetsInt-1) + "").equalsIgnoreCase("Netherlands Dwarf")){
						Thread.sleep(1500);
						((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//*[@for='netherlands-dwarf_pet" + numberOfMultiPetsInt + "']")));
						((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//*[@for='netherlands-dwarf_pet" + numberOfMultiPetsInt + "']")));
						}
					else{
						Thread.sleep(1000);
						((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//*[@for='rabbit-other_pet" + numberOfMultiPetsInt + "']")));
						((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//*[@for='rabbit-other_pet" + numberOfMultiPetsInt + "']")));
						
						Actions builder = new Actions(driver.get());
					/*		driver.get().findElement(By.xpath("//div[@id='pet"+ numberOfMultiPetsInt + ".pet_breed']/div/div/div/div/input")).sendKeys(multiPetUniqueTestDataArray[4]);
							Thread.sleep(1000);
							builder.sendKeys(Keys.ENTER).perform();*/
							
							WebElement breed=driver.get().findElement(By.id("pet" + numberOfMultiPetsInt + ".pet_breed"));
							breed.click();
							driver.get().findElement(By.xpath("//div[contains(@class,'react-select__menu-list')]"))
						    .findElement(By.xpath(String.format(".//div[text()='%s']", multiPetUniqueTestDataArray[17])))
						    .click();			
					}
					TextToWrite = "Pet " + numberOfMultiPetsInt + " Details: Full Name: " + multiPetUniqueTestDataArray[0] + " Rabbit Type: " + multiPetUniqueTestDataArray[17];
					utilities.Filewriter(TextToWrite);
				}
				dobArray = utilities.getDOB(multiPetUniqueTestDataArray[5]);
				driver.get().findElement(By.xpath("//*[@id='pet" + numberOfMultiPetsInt + ".dateDayName']")).clear();
				driver.get().findElement(By.xpath("//*[@id='pet" + numberOfMultiPetsInt + ".dateDayName']")).sendKeys(dobArray[0]);
				driver.get().findElement(By.xpath("//*[@id='pet" + numberOfMultiPetsInt + ".dateMonthName']")).clear();
				driver.get().findElement(By.xpath("//*[@id='pet" + numberOfMultiPetsInt + ".dateMonthName']")).sendKeys(dobArray[1]);
				driver.get().findElement(By.xpath("//*[@id='pet" + numberOfMultiPetsInt + ".dateYearName']")).clear();
				driver.get().findElement(By.xpath("//*[@id='pet" + numberOfMultiPetsInt + ".dateYearName']")).sendKeys(dobArray[2]);
				
				TextToWrite = "Pet " + numberOfMultiPetsInt + " DOB: " + dobArray[0] + "." + dobArray[1] + "." + dobArray[2];
				utilities.Filewriter(TextToWrite);
				if (recordset.getField("MultiPetSex_" + (numberOfMultiPetsInt) + "").equalsIgnoreCase("Male"))
				{
					((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//label[contains(@for,'male_radio_1pet" + numberOfMultiPetsInt + "')]")));
					((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//label[contains(@for,'male_radio_1pet" + numberOfMultiPetsInt + "')]")));
					TextToWrite = "Pet: " + numberOfMultiPetsInt + " Sex: Male";
					utilities.Filewriter(TextToWrite);
				}
				else
				{
					((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//label[contains(@for,'female_radio_1pet" + numberOfMultiPetsInt + "')]")));	
					((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//label[contains(@for,'female_radio_1pet" + numberOfMultiPetsInt + "')]")));
					TextToWrite = "Pet: " + numberOfMultiPetsInt + " Sex: Female";
					utilities.Filewriter(TextToWrite);
				}
		//		Thread.sleep(1000);
		//		((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//div[text()='Next']//parent::button")));	
		//		((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//div[text()='Next']//parent::button")));
				
				numberOfMultiPetsInt ++;
			}
		}
		dbConnectionCommonCode.closeConnection();
		return multiPetUniqueTestDataArray;
	}
}