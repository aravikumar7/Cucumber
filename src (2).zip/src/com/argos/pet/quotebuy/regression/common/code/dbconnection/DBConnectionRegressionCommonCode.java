/**
 * 
 */
package com.argos.pet.quotebuy.regression.common.code.dbconnection;

import java.io.IOException;

import com.argos.pet.quotebuy.regression.common.code.utilities.ReadConfig;
import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;
import com.codoid.products.fillo.Update;

/**
 * @author d23747
 *
 */
public class DBConnectionRegressionCommonCode {

	String ExcelFilePath = System.getProperty("user.dir") + "/Files/";
	public String ExcelPath;
	ReadConfig readConfig;
	Connection connection = null;
	Recordset recordset = null;
	Update executeUpdate = null;

	public Recordset recordset(String strQuery) throws IOException {
		Fillo fillo = new Fillo();
		readConfig = new ReadConfig();
		try {
			ExcelFilePath = ExcelFilePath + readConfig.getExcelPath();
			Connection connection = fillo.getConnection(ExcelFilePath);
			recordset = connection.executeQuery(strQuery);
			recordset.next();
		} catch (FilloException fe) {
			fe.printStackTrace();
		}
		return recordset;
	}

	public Update executeUpdate (String strUpdate) {
		Fillo fillo = new Fillo();
		try {
			Connection connection=fillo.getConnection(ExcelFilePath);
			connection.executeUpdate(strUpdate);
		}
		catch (FilloException fe)
		{
			fe.printStackTrace();
		}
		return executeUpdate;
	}

	public void closeConnection() {
		recordset.close();
		//connection.close();
	}

}
