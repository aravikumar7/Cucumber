/**
 * 
 */
package com.argos.pet.quotebuy.regression.common.code.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * @author d23747
 *
 */
public class PaymentPage {

	ThreadLocal<WebDriver> ldriver;

	public PaymentPage(ThreadLocal<WebDriver> driver)
	{
		ldriver = driver;
		PageFactory.initElements(driver.get(), this);
	}
	
	@FindBy (how = How.XPATH, using = "//label[@for='MP']") WebElement payMonthlyRadioButton;
	@FindBy (how = How.XPATH, using = "//*[@id='paymentPageForm']/div[1]/fieldset/div[3]/label/span/span[1]") WebElement payMonthlyText;
	@FindBy (how = How.XPATH, using = "//*[@id='paymentPageForm']/div[1]/fieldset/div[3]/label/span/span[2]") WebElement monthlyCost;
	@FindBy (how = How.XPATH, using = "//*[@id='paymentPageForm']/div[1]/fieldset/div[3]/label/span/span[3]") WebElement monthlyCostInterestRate;
	@FindBy (how = How.XPATH, using = "//label[@for='AP']") WebElement payYearlyRadioButton;
	@FindBy (how = How.XPATH, using = "//label[@for='DDType']") WebElement directDebitRadioButton;
	@FindBy (how = How.XPATH, using = "//*[@id='account_name']") WebElement directDebitAccountName;
	@FindBy (how = How.XPATH, using = "//*[@id='sortCode1']") WebElement sortCode1;
	@FindBy (how = How.XPATH, using = "//*[@id='sortCode2']") WebElement sortCode2;
	@FindBy (how = How.XPATH, using = "//*[@id='sortCode3']") WebElement sortCode3;
	@FindBy (how = How.XPATH, using = "//div[@id='payment_day']/div/div") WebElement payment;
	@FindBy (how = How.XPATH, using = "//*[@id='account_number']") WebElement accountNumber;
	@FindBy (how = How.XPATH, using = "//*[@id='payment_day']/div/div[1]/div") WebElement collectionDate;
	@FindBy (how = How.XPATH, using = "//*[@id='payment_options_debit_credit_card']") WebElement debitCreditCardRadioButton;
	@FindBy (how = How.ID, using = "dd_confirmation") WebElement directDebitConfirmationTickBox;
	@FindBy (how = How.XPATH, using = "//div/button[text()='Confirm payment']") WebElement confirmPaymentButton;
	@FindBy (how = How.ID, using = "cardNumber") WebElement creditCardNumber;
	@FindBy (how = How.ID, using = "expiryDateMonth") WebElement creditCardExpiryDateMM;
	@FindBy (how = How.ID, using = "expiryDateYear") WebElement creditCardExpiryDateYY;
	@FindBy (how = How.ID, using = "securityCode") WebElement creditCardSecurityCode;
	@FindBy (how = How.ID, using = "nameOnCard") WebElement creditCardAccountName;
	@FindBy (how = How.ID, using = "customer_date_of_birth") WebElement dob;
	@FindBy (how = How.XPATH, using = "//*[@id='userTitle']") WebElement userTitle;
	@FindBy (how = How.ID, using = "customer_first_name") WebElement firstName;
	@FindBy (how = How.ID, using = "customer_last_name") WebElement lastName;
	@FindBy (how = How.ID, using = "customer_contact_number") WebElement userPhoneNumber;
	@FindBy (how = How.XPATH, using = "//*[@id='dateDayName']") WebElement dobDay;
	@FindBy (how = How.XPATH, using = "//*[@id='dateMonthName']") WebElement dobMonth;
	@FindBy (how = How.XPATH, using = "//*[@id='dateYearName']") WebElement dobYear;
	
	public void selectCustomerTitle (String Title) throws InterruptedException
	{
		//ldriver.findElement(By.xpath("//label[text()='"+Title+"']")).click();
		//((JavascriptExecutor) ldriver.get()).executeScript("let input = arguments[0];var setValue = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;setValue.call(input, '" + Title + "');var e = new Event('input', { bubbles: true });input.dispatchEvent(e);", title);
		//	((JavascriptExecutor)ldriver.get()).executeScript("var myList = document.getElementsByClassName('react-select__single-value css-1uccc91-singleValue');myList[0].innerHTML="+Title+";");
	
	
	/*
		((JavascriptExecutor)ldriver.get()).executeScript("document.getElementsByClassName('react-select__single-value css-1uccc91-singleValue').innerHTML='Mr'");
		Thread.sleep(3000);
		((JavascriptExecutor)ldriver.get()).executeScript("document.getElementsByClassName('customer_title').value ='"+Title+"'");*/
		
		/*WebElement title=ldriver.findElement(By.xpath("(//div[@id='customer_title']/div/div/div)[1]"));
		ldriver.findElement(By.id("customer_title")).click();
		Thread.sleep(3000);
		ldriver.findElement(By.id("react-select-2-option-2")).getText();
		Actions actions = new Actions(ldriver.get());
		WebDriverWait wait = new WebDriverWait(ldriver, 15);
		WebElement actionWebElement = wait.until(ExpectedConditions.visibilityOf(ldriver.findElement(By.id("react-select-2-option-2"))));
		actions.click(actionWebElement).build();
	*/
/*		
		Actions builder = new Actions(ldriver.get());
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", ldriver.findElement(By.xpath("//input[contains(@id,'react-select-')]")));
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", ldriver.findElement(By.xpath("//input[contains(@id,'react-select-')]")));
		ldriver.findElement(By.xpath("//input[contains(@id,'react-select-')]")).sendKeys("Miss",Keys.ENTER);*/

		WebElement title=ldriver.get().findElement(By.id("customer_title"));
		title.click();
	/*	Actions actions = new Actions(ldriver.get());
		WebDriverWait wait = new WebDriverWait(ldriver, 15);
		actions.sendKeys(Keys.ARROW_DOWN).build().perform();
		//actions.sendKeys(Keys.DOWN).build().perform();
		//actions.sendKeys(Keys.DOWN).build().perform();
		actions.sendKeys(Keys.ENTER).build().perform();*/
		
		Actions actions = new Actions(ldriver.get());
//		title.sendKeys(Keys.ARROW_DOWN);
//		Thread.sleep(1500);
	//	ldriver.findElement(By.xpath("/html/body/div[12]/div/div"))
	 //   .findElement(By.xpath(String.format(".//div[text()='%s']", Title)))
	  //  .click();
	//	ldriver.findElement(By.xpath("//div[contains(@class,'react-select__menu-list')]"))
	 //   .findElement(By.xpath(String.format(".//div[text()='%s']", Title)))
	  //  .click();
		
		
		WebElement customertitle=ldriver.get().findElement(By.xpath("//div[contains(@class,'react-select__menu-list')]"))
			    .findElement(By.xpath(String.format(".//div[text()='%s']", Title)));		
				
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", customertitle);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", customertitle);
	}
	
	
	
	public void populateCustomerFirstName (String FirstName)
	{
		//firstName.sendKeys(FirstName);
		//firstName.sendKeys(Keys.TAB);
		((JavascriptExecutor) ldriver.get()).executeScript("let input = arguments[0];var setValue = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;setValue.call(input, '" + FirstName + "');var e = new Event('input', { bubbles: true });input.dispatchEvent(e);", firstName);

	}
	
	public void populateCustomerLastName (String LastName)
	{
	//	lastName.sendKeys(LastName);
	//	lastName.sendKeys(Keys.TAB);
		((JavascriptExecutor) ldriver.get()).executeScript("let input = arguments[0];var setValue = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;setValue.call(input, '" + LastName + "');var e = new Event('input', { bubbles: true });input.dispatchEvent(e);", lastName);

	}
	
	public void populatedateOfBirth(String dateOfBirth) {
		dob.sendKeys(Keys.BACK_SPACE);
		dob.sendKeys(dateOfBirth);
	}
	public void populateCustomerDOBDay (String DOBDay)
	{
	//	dobDay.clear();
	//	dobDay.sendKeys(DOBDay);
			((JavascriptExecutor) ldriver.get()).executeScript("let input = arguments[0];var setValue = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;setValue.call(input, '" + DOBDay + "');var e = new Event('input', { bubbles: true });input.dispatchEvent(e);", dobDay);
			}
	
	public void populateCustomerDOBMonth (String DOBMonth)
	{
//		dobMonth.clear();
//		dobMonth.sendKeys(DOBMonth);
		((JavascriptExecutor) ldriver.get()).executeScript("let input = arguments[0];var setValue = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;setValue.call(input, '" + DOBMonth + "');var e = new Event('input', { bubbles: true });input.dispatchEvent(e);", dobMonth);
			}
	
	public void populateCustomerDOBYear (String DOBYear)
	{
		//dobYear.clear();
		//dobYear.sendKeys(DOBYear);
		((JavascriptExecutor) ldriver.get()).executeScript("let input = arguments[0];var setValue = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;setValue.call(input, '" + DOBYear + "');var e = new Event('input', { bubbles: true });input.dispatchEvent(e);", dobYear);
	}
	
	public void populateCustomerPhoneNumber(String customerPhoneNumber) {
	//	userPhoneNumber.sendKeys(customerPhoneNumber);
		((JavascriptExecutor) ldriver.get()).executeScript("let input = arguments[0];var setValue = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;setValue.call(input, '" + customerPhoneNumber + "');var e = new Event('input', { bubbles: true });input.dispatchEvent(e);", userPhoneNumber);
	
	}
	public void clickPayMonthlyRadioButton()
	{
		//payMonthlyRadioButton.click();
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", payMonthlyRadioButton);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", payMonthlyRadioButton);
	
	}
	
	public String getPayMonthlyText()
	{
		String PayMonthlyText = payMonthlyText.getText();
		return PayMonthlyText;
	}
	
	public String getMonthlyCost()
	{
		String MonthlyCost = monthlyCost.getText();
		return MonthlyCost;
	}
	
	public String getMonthlyCostInterestRate()
	{
		String MonthlyCostInterestRate = monthlyCostInterestRate.getText();
		return MonthlyCostInterestRate;
	}
	
	public void clickPayYearlyRadioButton()
	{
		//payYearlyRadioButton.click();
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", payYearlyRadioButton);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", payYearlyRadioButton);
	
	}
	
	public void clickDirectDebitRadioButton()
	{
		//directDebitRadioButton.click();
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", directDebitRadioButton);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", directDebitRadioButton);
	
	}
	
	public void populateDirectDebitAccountName(String DirectDebitAccountName)
	{
	//	directDebitAccountName.clear();
	//	directDebitAccountName.sendKeys(DirectDebitAccountName);
		((JavascriptExecutor) ldriver.get()).executeScript("let input = arguments[0];var setValue = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;setValue.call(input, '" + DirectDebitAccountName + "');var e = new Event('input', { bubbles: true });input.dispatchEvent(e);", directDebitAccountName);
		
	}
	
	public void populateSortCode1(String SortCode1)
	{
	//	sortCode1.clear();
	//	sortCode1.sendKeys(SortCode1);
		((JavascriptExecutor) ldriver.get()).executeScript("let input = arguments[0];var setValue = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;setValue.call(input, '" + SortCode1 + "');var e = new Event('input', { bubbles: true });input.dispatchEvent(e);", sortCode1);
		
	}
	
	public void populateSortCode2(String SortCode2)
	{
	//	sortCode2.clear();
	//	sortCode2.sendKeys(SortCode2);
		((JavascriptExecutor) ldriver.get()).executeScript("let input = arguments[0];var setValue = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;setValue.call(input, '" + SortCode2 + "');var e = new Event('input', { bubbles: true });input.dispatchEvent(e);", sortCode2);
		
	}
	
	public void populateSortCode3(String SortCode3)
	{
	//	sortCode3.clear();
	//	sortCode3.sendKeys(SortCode3);
		((JavascriptExecutor) ldriver.get()).executeScript("let input = arguments[0];var setValue = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;setValue.call(input, '" + SortCode3 + "');var e = new Event('input', { bubbles: true });input.dispatchEvent(e);", sortCode3);
		
	}
	
	public void populateAccountNumber(String AccountNumber)
	{
	//	accountNumber.clear();
	//	accountNumber.sendKeys(AccountNumber);
		((JavascriptExecutor) ldriver.get()).executeScript("let input = arguments[0];var setValue = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;setValue.call(input, '" + AccountNumber + "');var e = new Event('input', { bubbles: true });input.dispatchEvent(e);", accountNumber);
		
	}
	
	public void populatePreferredPaymentDate(String PreferredPaymentDate) throws InterruptedException
	{
	
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", payment);
	
		Thread.sleep(500);
		payment.click();
		//payment.sendKeys(Keys.TAB);
	/*	Actions actions = new Actions(ldriver.get());
		for(int i=1;i<Integer.parseInt(PreferredPaymentDate);i++){
		//actions.sendKeys(Keys.ARROW_DOWN).perform();
		//Thread.sleep(700);
			payment.sendKeys(Keys.ARROW_DOWN);
		}
		actions.sendKeys(Keys.ENTER).build().perform();
		*/
	//	ldriver.findElement(By.xpath("//div[@id='payment_day']/div/div")).click();
	//	Thread.sleep(1000);
		//ldriver.findElement(By.id("id=react-select-3-option-5")).click();
		//ldriver.findElement(By.xpath("//input[contains(@id,'react-select-')]")).click();
		
		Actions actions = new Actions(ldriver.get());
	//	payment.sendKeys(Keys.ARROW_DOWN);
		Thread.sleep(700);
		//ldriver.findElement(By.xpath("/html/body/div[12]/div/div"))
	    //.findElement(By.xpath(String.format(".//div[text()='%s']", PreferredPaymentDate)))
	   // .click();
	//	ldriver.findElement(By.xpath("//div[contains(@class,'react-select__menu-list')]"))
	 //   .findElement(By.xpath(String.format(".//div[text()='%s']", PreferredPaymentDate)))
	  //  .click();
	
		WebElement paymentdate=ldriver.get().findElement(By.xpath("//div[contains(@class,'react-select__menu-list')]"))
			    .findElement(By.xpath(String.format(".//div[text()='%s']", PreferredPaymentDate)));		
				
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", paymentdate);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", paymentdate);
		
		
	}
	
	public void clickDebitCreditCardRadioButton()
	{
		debitCreditCardRadioButton.click();
	}
	
	public void clickDirectDebitConfirmationTickBox()
	{
		//directDebitConfirmationTickBox.click();
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", directDebitConfirmationTickBox);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", directDebitConfirmationTickBox);
	}
	public void populateCreditCardNumber(String CreditCardNumber)
	{
		creditCardNumber.clear();
		creditCardNumber.sendKeys(CreditCardNumber);
	}
public void populateCreditCardExpiryDateMM(String CreditCardExpiryDateMM)
	{
		creditCardExpiryDateMM.clear();
		creditCardExpiryDateMM.sendKeys(CreditCardExpiryDateMM);
	}
public void populateCreditCardExpiryDateYY(String CreditCardExpiryDateYY)
	{
		creditCardExpiryDateYY.clear();
		creditCardExpiryDateYY.sendKeys(CreditCardExpiryDateYY);
	}
public void populateCreditCardSecurityCode(String populateCreditCardSecurityCode)
	{
		creditCardSecurityCode.clear();
		creditCardSecurityCode.sendKeys(populateCreditCardSecurityCode);
	}

public void populateCreditCardAccountName(String CreditCardAccountName)
	{
		creditCardAccountName.clear();
		creditCardAccountName.sendKeys(CreditCardAccountName);
	}

	public void clickConfirmPaymentButton()
	{
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", confirmPaymentButton);
	}

	public void populateSortCode(String SortCode) {
	//	sortCode.clear();
	//	sortCode.sendKeys(SortCode);
	//	sortCode.sendKeys(Keys.TAB);
	}
}
