package com.argos.pet.quotebuy.regression.common.code.tests;

import org.openqa.selenium.By;
import org.testng.annotations.Parameters;
import org.testng.asserts.SoftAssert;

import com.argos.pet.quotebuy.regression.common.code.dbconnection.DBConnectionRegressionCommonCode;
import com.argos.pet.quotebuy.regression.common.code.pages.PortalRegisterPage;
import com.argos.pet.quotebuy.regression.common.code.utilities.TestBase;
import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;
import com.codoid.products.fillo.Recordset;



/**
 * @author d23747
 *
 */
public class PortalRegisterTest extends TestBase {

	YourPetDetailsTest yourPetDetailsTest;
	PortalRegisterPage registerPage;
	Utilities utilities;
	DBConnectionRegressionCommonCode dbConnectionCommonCode;
	SoftAssert softAssert;
	String className;
	public String ClassName;
	ThreadLocal<String[]> uniqueTestDataArray;
	public static String[][] policyInformation;

	@Parameters ("ClassName")
	public void initiateRegisterTest(String ClassName) throws Exception
	{
		registerPage = new PortalRegisterPage(driver);
		utilities = new Utilities();
		softAssert = new SoftAssert();
		policyInformation = ConfirmationTest.policyDetails;
		className = utilities.getClassName(ClassName);
		uniqueTestDataArray = YourPetDetailsTest.uniqueTestDataArray;
		String  strQuery = "Select * from Register where TestClassName = '" + className + "'";
		dbConnectionCommonCode = new DBConnectionRegressionCommonCode();
		Recordset recordset = dbConnectionCommonCode.recordset(strQuery);
		recordset.next();
		recordset.moveFirst();

		Thread.sleep(3600);
	//	driver.get("https://" + Username + ":" + Password + "@" + PortalTestEnvironmentURL);
		//driver.navigate().to("https://" + PortalTestEnvironmentURL);
		Thread.sleep(5600);
		if(utilities.isElementPresent(By.xpath("//*[@id='cookieMessageDismiss']"), driver))
		{
			registerPage.clickContinueButton();
		}
		registerPage.setRegisterTabButton();
		registerPage.setEmailAddress((uniqueTestDataArray.get())[14]);
		registerPage.setPolicyNumber(policyInformation[0][2]);
		registerPage.setPostCode((uniqueTestDataArray.get())[12]);
		registerPage.setDOBDay((uniqueTestDataArray.get())[8]);
		registerPage.setDOBMonth((uniqueTestDataArray.get())[9]);
		registerPage.setDOBYear((uniqueTestDataArray.get())[10]);
		registerPage.setPassword(recordset.getField("Password"));
		registerPage.setReEnterPassword(recordset.getField("VerifyPassword"));
		registerPage.setNextButton();
		if (utilities.isElementPresent(By.xpath("//*[@id='policyNumber']"), driver))
		{
			registerPage.setPolicyNumberOnNewPopUp(policyInformation[0][2]);
			registerPage.setSubmitPolicyNumberButton();
		}
		
		if (utilities.isElementPresent(By.xpath("//*[text() [contains (., 'Having trouble')]]"), driver))
		{
			driver.get().findElement(By.xpath("//*[text() [contains (., 'Close')]]")).click();
		}
		/*String SuccessfulRegistrationMessageOnWeb = registerPage.getSuccessfulRegistrationMessage();
		String SuccessfulRegistrationMessageFromExcel = recordset.getField("SuccessfulRegistrationMessage");
		softAssert.assertEquals(SuccessfulRegistrationMessageOnWeb, SuccessfulRegistrationMessageFromExcel);
		softAssert.assertAll();*/
		dbConnectionCommonCode.closeConnection();
	}
}
