/**
 * 
 */
package com.argos.pet.quotebuy.regression.common.code.tests;

import org.testng.annotations.Parameters;

import com.argos.pet.quotebuy.regression.common.code.dbconnection.DBConnectionRegressionCommonCode;
import com.argos.pet.quotebuy.regression.common.code.pages.PaymentPage;
import com.argos.pet.quotebuy.regression.common.code.utilities.TestBase;
import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;
import com.codoid.products.fillo.Recordset;


/**
 * @author d23747
 *
 */
public class PaymentTest extends TestBase {

	PaymentPage paymentPage;
	DBConnectionRegressionCommonCode dbConnectionCommonCode;
	Utilities utilities;
	String className;
	public String TextToWrite;
	public String ClassName;
	//String[] uniqueTestDataArray;
	ThreadLocal<String[]> regressionTestDataArray;
	String coverStartDate;
	public String nextMonth;
	static public String postCode;
	static public String CustomerHouseNumberName;
	static public String portalEmail;
	static public String portalPostCode;
	static public String dateOfBirth1;
	static public String dateOfBirth2;
	static public String dateOfBirth3;
	String dateOfBirth;
	
	@Parameters ("ClassName")
	public void initiatePaymentTest(String ClassName) throws Exception
	{
		utilities = new Utilities();
		className = utilities.getClassName(ClassName);
		String  strQuery = "Select * from Payment where TestClassName = '" + className + "'";
		dbConnectionCommonCode = new DBConnectionRegressionCommonCode();
		Recordset recordset = dbConnectionCommonCode.recordset(strQuery);
		recordset.next();
		recordset.moveFirst();
		regressionTestDataArray = YourPetDetailsTest.regressionTestDataArray;
		utilities.waitForLoad(driver);
		
		paymentPage = new PaymentPage(driver);
		
	
		paymentPage.selectCustomerTitle((regressionTestDataArray.get())[13]);
		paymentPage.populateCustomerFirstName((regressionTestDataArray.get())[6]);
		paymentPage.populateCustomerLastName((regressionTestDataArray.get())[7]);
		paymentPage.populateCustomerDOBDay((regressionTestDataArray.get())[8]);
		paymentPage.populateCustomerDOBMonth((regressionTestDataArray.get())[9]);
		paymentPage.populateCustomerDOBYear((regressionTestDataArray.get())[10]);
		//dateOfBirth = regressionTestDataArray[8]+"/"+regressionTestDataArray[9]+"/"+regressionTestDataArray[10];
		//paymentPage.populatedateOfBirth(dateOfBirth);
		System.out.println("DOB"+className+" "+(regressionTestDataArray.get())[8]+"/"+(regressionTestDataArray.get())[9]+"/"+(regressionTestDataArray.get())[10]);
		paymentPage.populateCustomerPhoneNumber(recordset.getField("CustomerPhoneNumber"));
		dateOfBirth1=(regressionTestDataArray.get())[8];
		dateOfBirth2=(regressionTestDataArray.get())[9];
		dateOfBirth3=(regressionTestDataArray.get())[10];
		
		if (recordset.getField("PaymentFrequency").equalsIgnoreCase("Monthly"))
		{
			paymentPage.clickPayMonthlyRadioButton();
			TextToWrite = "Payment Frequency = Monthly";
			utilities.Filewriter(TextToWrite);
		}
		else
		{
			paymentPage.clickPayYearlyRadioButton();
			TextToWrite = "Payment Frequency = Yearly";
			utilities.Filewriter(TextToWrite);
		}
		
		
		
		if(recordset.getField("PaymentMeans").equalsIgnoreCase("DirectDebit"))
		{
		paymentPage.clickDirectDebitRadioButton();
	//	paymentPage.populateSortCode(recordset.getField("SortCode1")+"�"+recordset.getField("SortCode2")+"�"+recordset.getField("SortCode3"));
		paymentPage.populateDirectDebitAccountName(recordset.getField("AccountName"));
		
		paymentPage.populateSortCode1(recordset.getField("SortCode1"));
		paymentPage.populateSortCode2(recordset.getField("SortCode2"));
		paymentPage.populateSortCode3(recordset.getField("SortCode3"));
		paymentPage.populateAccountNumber(recordset.getField("AccountNumber"));		
		}
		else if(recordset.getField("PaymentMeans").equalsIgnoreCase("DirectCredit"))
		{
			paymentPage.clickDebitCreditCardRadioButton();
			paymentPage.populateCreditCardAccountName(recordset.getField("AccountName"));
			paymentPage.populateCreditCardExpiryDateMM(recordset.getField("CreditCardExpiryDateMM"));
			paymentPage.populateCreditCardExpiryDateYY(recordset.getField("CreditCardExpiryDateYY"));
			paymentPage.populateCreditCardSecurityCode(recordset.getField("CreditCardSecurityCode"));
			paymentPage.populateCreditCardNumber(recordset.getField("CreditCardNumber"));
		}
		paymentPage.populatePreferredPaymentDate(recordset.getField("PreferredPaymentDate"));
		TextToWrite = "Preferred Payment Date = " + recordset.getField("PreferredPaymentDate");
		utilities.Filewriter(TextToWrite);
		paymentPage.clickDirectDebitConfirmationTickBox();
		paymentPage.clickConfirmPaymentButton();
		dbConnectionCommonCode.closeConnection();
	}
}
