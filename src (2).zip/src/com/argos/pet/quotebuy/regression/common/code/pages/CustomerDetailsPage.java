/**
 * 
 */
package com.argos.pet.quotebuy.regression.common.code.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;


/**
 * @author d23747
 *
 */
public class CustomerDetailsPage {

	ThreadLocal<WebDriver> ldriver;
	Utilities utilities;

	public CustomerDetailsPage(ThreadLocal<WebDriver> driver)
	{
		ldriver = driver;
		PageFactory.initElements(driver.get(), this);
	}
	
	@FindBy (how = How.XPATH, using = "//*[@id='userTitle']") WebElement userTitle;
	@FindBy (how = How.ID, using = "customer_first_name") WebElement firstName;
	@FindBy (how = How.ID, using = "customer_last_name") WebElement lastName;
	@FindBy (how = How.XPATH, using = "//*[@id='daySelectDob']") WebElement dobDay;
	@FindBy (how = How.XPATH, using = "//*[@id='monthSelectDob']") WebElement dobMonth;
	@FindBy (how = How.XPATH, using = "//*[@id='yearSelectDob']") WebElement dobYear;
	@FindBy (how = How.ID, using = "customer_date_of_birth") WebElement dob;
	@FindBy (how = How.ID, using = "email_address") WebElement userEmail;
	@FindBy (how = How.ID, using = "customer_contact_number") WebElement userPhoneNumber;
	@FindBy (how = How.ID, using = "houseNumberName") WebElement houseNumberName;
	@FindBy (how = How.XPATH, using = "//div[@class='toast-content__body']") WebElement houseNumberNameErrorText;
	@FindBy (how = How.ID, using = "postcodeSearch") WebElement postcode;
	@FindBy (how = How.XPATH, using = "//button[text()='Find address']") WebElement findAddressButton;
	@FindBy (how = How.XPATH, using = "//div[text()='We could not find your address!']") WebElement noResultsError;
	@FindBy (how = How.XPATH, using = "//*[@id='today']//following-sibling::label") WebElement coverStartDateToday;
	@FindBy (how = How.XPATH, using = "//*[@id='tomorrow']//following-sibling::label") WebElement coverStartDateTomorrow;
	@FindBy (how = How.XPATH, using = "//*[@id='other']//following-sibling::label") WebElement coverStartDateAnotherDate;
	@FindBy (id = "calendarTrigger") WebElement startDateCalendar;
	@FindBy (how = How.XPATH, using = "//*[@id='startDateCalendarWrapper']/div[2]/div[1]/div/div[1]/div/div/select") WebElement nextMonthSelector;
	@FindBy (how = How.XPATH, using = "//*[@id='nectarCardInput']") WebElement nectarCardNumber;
	@FindBy (how = How.XPATH, using = "//div[@class='discount-button__copy']") WebElement promoCheckerLink;
	@FindBy (how = How.ID, using = "promoCodeNumber") WebElement promotionalCode;
	@FindBy (how = How.XPATH, using = "//button[text()='Add promotional code']") WebElement promoApply;
	@FindBy (how = How.XPATH, using = "//*[@id='promoCodeDescription']") WebElement promoCodeDescriptionTextMessage;
	@FindBy (how = How.XPATH, using = "//*[@id='quoteReviewMarketingPrefsContainer']/div/div/p[1]/a") WebElement privacyPolicyLink;
	@FindBy (how = How.XPATH, using = "//*[@id='quoteReviewMarketingPrefsContainer']/div/div/p[3]/a") WebElement marketingOptOutLink;
	@FindBy (how = How.XPATH, using = "//*[@id='marketingPrefsForm']/fieldset/label/label") WebElement documentByPostTickBox;
	@FindBy (how = How.XPATH, using = "//button[@type='submit']") WebElement getAQuoteButton;
	@FindBy (how = How.XPATH, using = "//*[@id='userDetailsForm']/div[4]/div/div/button/div[2]") WebElement existingPolicyLink;
	@FindBy (how = How.ID, using = "num") WebElement existingPolicyTextField;
	@FindBy (how = How.XPATH, using = "//*[@id='userDetailsForm']/button/div") WebElement existingPolicyAddButton;
	
	@FindBy (how = How.XPATH, using = "//*[@id='floatingToasterPanel']/div/div/div/div") WebElement existingPolicySuccess;
	@FindBy (how = How.XPATH, using = "//button[@class='Toastify__close-button']") WebElement floatingToasterPanelClose;
	@FindBy (how = How.XPATH, using = "//button[@class='Toastify__close-button']") WebElement floatingToasterPanelSuccess;

	public void selectCustomerTitle (String Title)
	{
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", ldriver.get().findElement(By.xpath("//label[text()='"+Title+"']")));
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", ldriver.get().findElement(By.xpath("//label[text()='"+Title+"']")));
		//ldriver.get().findElement(By.xpath("//label[text()='"+Title+"']")).click();
	}
	
	public void populateCustomerFirstName (String FirstName)
	{
		firstName.sendKeys(FirstName);
		firstName.sendKeys(Keys.TAB);
	}
	
	public void populateCustomerLastName (String LastName)
	{
		lastName.sendKeys(LastName);
		lastName.sendKeys(Keys.TAB);
	}
	
	public void populateCustomerDOBDay (String DOBDay)
	{
		dobDay.clear();
		dobDay.sendKeys(DOBDay);
	}
	
	public void clickExistingPolicyLink()
	{
		existingPolicyLink.click();
	}
	public void setExistingPolicyTextField(String ExistingPolicyNumber)
	{
		existingPolicyTextField.clear();
		existingPolicyTextField.sendKeys(ExistingPolicyNumber);
	}
	
	public void clickExistingPolicyAddButton()
	{
		existingPolicyAddButton.click();
	}
	
	public String getExistingPolicySuccess()
	{
		return existingPolicySuccess.getText();
	}
	public void clickFloatingToasterPanelClose()
	{
		//floatingToasterPanelClose.click();
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", floatingToasterPanelClose);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", floatingToasterPanelClose);
	}
	
	public void clickFloatingToasterPanelSuccessClose()
	{
		boolean successtoaster=ldriver.get().findElements(By.xpath("//button[@class='Toastify__close-button']")).size()>0;
		if(successtoaster) {
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", floatingToasterPanelSuccess);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", floatingToasterPanelSuccess);
	//		floatingToasterPanelSuccess.click();
		}
	}
	
	public void populateCustomerDOBMonth (String DOBMonth)
	{
		dobMonth.clear();
		dobMonth.sendKeys(DOBMonth);
	}
	
	public void populateCustomerDOBYear (String DOBYear)
	{
		dobYear.clear();
		dobYear.sendKeys(DOBYear);
	}
	
	public void populateCustomerEmail (String Email)
	{
		userEmail.clear();
		userEmail.sendKeys(Email);
	}
	
	public void populateCustomerHouseNumberName (String HouseNumberName)
	{
		JavascriptExecutor js = (JavascriptExecutor) ldriver.get();
		js.executeScript("(arguments[0])[arguments[1]] = arguments[2];", 
				houseNumberName, "value","");	
		houseNumberName.sendKeys(HouseNumberName);
		houseNumberName.sendKeys(Keys.TAB);
	}
	
	public String getHouseNumberNameErrorText()
	{
		return houseNumberNameErrorText.getText();
	}
	
	public void populateCustomerPostcode (String Postcode)
	{
		JavascriptExecutor js = (JavascriptExecutor) ldriver.get();
		js.executeScript("(arguments[0])[arguments[1]] = arguments[2];", 
				postcode, "value","");	
		
		postcode.sendKeys(Postcode);
		houseNumberName.sendKeys(Keys.TAB);
	}
	
	public void clickFindAddressButton () throws InterruptedException
	{
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", findAddressButton);
		Thread.sleep(700);
	//	findAddressButton.click();
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", findAddressButton);
	}
	
	public String getNoResultsError()
	{
		return noResultsError.getText();
	}
	
	public void clickCoverStartDateToday ()
	{
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", coverStartDateToday);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", coverStartDateToday);
	//	coverStartDateToday.click();
	}
	
	public void clickCoverStartDateTomorrow ()
	{
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", coverStartDateTomorrow);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", coverStartDateTomorrow);
		//coverStartDateTomorrow.click();
	}
	
	public void clickCoverStartDateAnotherDate ()
	{
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", coverStartDateAnotherDate);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", coverStartDateAnotherDate);
	//coverStartDateAnotherDate.click();
	}
	
	public void populateCoverStartDateAnotherDate ()
	{
		startDateCalendar.click();
	}
	
	public void selectNextMonth(String Month)
	{
		new Select(nextMonthSelector).selectByVisibleText(Month);
	}
	
	public void populateCustomerNectarCardNumber (String NectarCardNumber)
	{
		nectarCardNumber.clear();
		nectarCardNumber.sendKeys(NectarCardNumber);
	}
	
	public void selectPromoCheckerLink ()
	{
		utilities = new Utilities();
		utilities.actionClick(ldriver.get(), promoCheckerLink);
	}
	
	public void populateCustomerPromotionalCode (String PromotionalCode)
	{
		promotionalCode.clear();
		promotionalCode.sendKeys(PromotionalCode);
		
	}
	public void applyCustomerPromotionalCode ()
	{
		promoApply.click();
	}
	public String getPromoCodeDescriptionTextMessage()
	{
		String promoCodeDescriptionText = promoCodeDescriptionTextMessage.getText();
		return promoCodeDescriptionText;
	}
	
	public void selectPrivacyPolicyLink()
	{
		privacyPolicyLink.click();
	}
	
	public void selectMarketingOptOutLink()
	{
		marketingOptOutLink.click();
	}
	
	public void clickDocumentByPostTickBox()
	{
		documentByPostTickBox.click();
	}
	
	public void clickGetAQuoteButton () throws InterruptedException
	{
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", getAQuoteButton);
		Thread.sleep(1000);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", getAQuoteButton);
	}
	public void populatedateOfBirth(String dateOfBirth) throws InterruptedException {
	//dob.sendKeys(Keys.BACK_SPACE);
	//dob.sendKeys(Keys.CLEAR);
	//	Thread.sleep(700);
		dob.sendKeys(dateOfBirth);
		dob.sendKeys(Keys.TAB);
	//correct
	//	((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].focus(); arguments[0].blur(); return true",dob);
	//	((JavascriptExecutor) ldriver.get()).executeScript("let input = arguments[0];var setValue = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;setValue.call(input, '" + dateOfBirth + "');var e = new Event('input', { bubbles: true });input.dispatchEvent(e);", dob);
	//	dob.sendKeys(Keys.TAB);
	//	((JavascriptExecutor) ldriver.get()).executeScript("document.getElementById('customer_date_of_birth').blur()");				
	//correct	
	}

	public void populateCustomerPhoneNumber(String customerPhoneNumber) {
		userPhoneNumber.sendKeys(customerPhoneNumber);
	}
}
