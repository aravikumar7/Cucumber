/**
 * 
 */
package com.argos.pet.quotebuy.regression.common.code.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * @author d23747
 *
 */
public class PortalHomePage {

	ThreadLocal<WebDriver> ldriver;

	public PortalHomePage(ThreadLocal<WebDriver> driver)
	{
		ldriver = driver;
		PageFactory.initElements(driver.get(), this);
	}
	
	@FindBy (how = How.XPATH, using = "//*[@id='root']/div[3]/div[2]/main/div/div[2]/div/div[1]/div[1]/div[2]/h3") WebElement petNameOnWeb;
	@FindBy (how = How.XPATH, using = "//*[@id='root']/div[3]/div[2]/main/div/div[2]/div/div[1]/div[1]/div[2]/h4") WebElement petCoverOnWeb;
	@FindBy (how = How.XPATH, using = "//*[@id='root']/div[3]/div[2]/main/div/div[2]/div/div[1]/div[1]/div[2]/div") WebElement policyNumberOnWeb;
	@FindBy (how = How.XPATH, using = "//*[@id='root']/div[3]/div[2]/main/div/div[2]/div/div[1]/div[2]/button") WebElement goToDocumentsButton;
	@FindBy (how = How.XPATH, using = "//*[@id='root']/div[3]/div[2]/main/div/div[2]/div/div[2]/div[2]/div[1]/div/div/div/div/div/span") WebElement coverRemainingText;
	@FindBy (how = How.XPATH, using = "//*[@id='root']/div[3]/div[2]/main/div/div[2]/div/div[2]/div[2]/div[1]/div/div/div/div/div/strong") WebElement coverRemainingValue; //not for time limited policies
	@FindBy (how = How.XPATH, using = "//*[@id='root']/div[3]/div[2]/main/div/div[2]/div/div[2]/div[2]/div[2]/div/div[1]/div[2]/span") WebElement coverTotal; //not for time limited policies
	@FindBy (how = How.XPATH, using = "//*[@id='root']/div[3]/div[2]/main/div/div[2]/div/div[2]/div[2]/div[2]/div/div[2]/div[2]/span") WebElement coverUsed; //not for time limited policies
	@FindBy (how = How.XPATH, using = "//*[@id='root']/div[3]/div[2]/main/div/div[2]/div/div[2]/div[2]/div[2]/div/div[3]/div[2]") WebElement coverExcess; //not for time limited policies
	@FindBy (how = How.XPATH, using = "//*[@id='root']/div[3]/div[2]/main/div/div[3]/div[1]/div/div[2]/div/button") WebElement goToVetAssistanceButton;
	@FindBy (how = How.XPATH, using = "//*[@id='root']/div[3]/div[2]/main/div/div[3]/div[2]/div/div[2]/div/button") WebElement goToWeTalkPetButton;
	@FindBy (how = How.XPATH, using = "//*[@id='root']/div[3]/div[2]/main/div/div[3]/div[3]/div/div[2]/div/button") WebElement goToFAQsButton;
	@FindBy (how = How.XPATH, using = "//*[@id='root']/div[3]/div[2]/div/div/div[1]/a/img") WebElement accountIcon;
	@FindBy (how = How.XPATH, using = "//*[@id='root']/div[3]/div[2]/div/div/div[2]/a/img") WebElement messageIcon;
	@FindBy (how = How.XPATH, using = "//*[@id='root']/div[3]/div[2]/main/div/div[1]/div[2]/a/button") WebElement makeClaimButton;
	@FindBy (how = How.XPATH, using = "//*[@id='root']/div[3]/div[1]/div/div[2]/a[1]/div[2]") WebElement homeLink;
	@FindBy (how = How.XPATH, using = "//*[@id='root']/div[3]/div[1]/div/div[2]/a[2]/div[2]") WebElement myClaimsLink;
	@FindBy (how = How.XPATH, using = "//*[@id='root']/div[3]/div[1]/div/div[2]/a[3]/div[2]") WebElement documentsLink;
	@FindBy (how = How.XPATH, using = "//*[@id='root']/div[3]/div[1]/div/div[4]/a[1]/div[2]") WebElement vetAssistanceLink;
	@FindBy (how = How.XPATH, using = "//*[@id='root']/div[3]/div[1]/div/div[4]/a[2]/div[2]") WebElement accountDetailsLink;
	@FindBy (how = How.XPATH, using = "//*[@id='root']/div[3]/div[1]/div/div[4]/a[3]/div[2]") WebElement needHelpLink;
	@FindBy (how = How.XPATH, using = "//*[@id='root']/div[3]/div[1]/div/div[4]/a[4]/div[2]") WebElement logoutLink;
	
	public String getPetNameOnWeb()
	{
		String PetNameOnWeb = petNameOnWeb.getText();
		return PetNameOnWeb;
	}
	
	public String getPetCoverOnWeb()
	{
		String PetCoverOnWeb = petCoverOnWeb.getText();
		return PetCoverOnWeb;
	}
	
	public String getPolicyNumberOnWeb()
	{
		String PolicyNumberOnWeb = policyNumberOnWeb.getText();
		return PolicyNumberOnWeb;
	}
	
	public void setGoToDocumentsButton()
	{
		goToDocumentsButton.click();
	}
	
	public String getCoverRemainingText()
	{
		return coverRemainingText.getText();
	}
	
	public String getCoverRemainingValue()
	{
		return coverRemainingValue.getText();
	}
	
	public String getCoverTotal()
	{
		return coverTotal.getText();
	}
	
	public String getCoverUsed()
	{
		return coverUsed.getText();
	}
	
	public String getCoverExcess()
	{
		return coverExcess.getText();
	}
	
	public void setGoToVetAssistanceButton()
	{
		goToVetAssistanceButton.click();
	}
	
	public void setGoToWeTalkPetButton()
	{
		goToWeTalkPetButton.click();
	}
	
	public void setGoToFAQsButton()
	{
		goToFAQsButton.click();
	}
	
	public void setAccountIcon()
	{
		accountIcon.click();
	}
	
	public void setMessageIcon()
	{
		messageIcon.click();
	}
	
	public void setMakeClaimButton()
	{
		makeClaimButton.click();
	}
	
	public void setHomeLink()
	{
		homeLink.click();
	}
	
	public void setMyClaimsLink()
	{
		myClaimsLink.click();
	}
	
	public void setDocumentsLink()
	{
		documentsLink.click();
	}
	
	public void setVetAssistanceLink()
	{
		vetAssistanceLink.click();
	}
	
	public void setAccountDetailsLink()
	{
		accountDetailsLink.click();
	}
	
	public void setNeedHelpLink()
	{
		needHelpLink.click();
	}
	
	public void setLogoutLink()
	{
		logoutLink.click();
	}
}
