/**
 * 
 */
package com.argos.pet.quotebuy.regression.common.code.tests;

import org.testng.annotations.Parameters;
import org.testng.asserts.SoftAssert;

import com.argos.pet.quotebuy.regression.common.code.dbconnection.DBConnectionRegressionCommonCode;
import com.argos.pet.quotebuy.regression.common.code.pages.AssumptionsPage;
import com.argos.pet.quotebuy.regression.common.code.utilities.TestBase;
import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;
import com.codoid.products.fillo.Recordset;


/**
 * @author d23747
 *
 */
public class AssumptionsTest extends TestBase {

	AssumptionsPage assumptionsPage;
	DBConnectionRegressionCommonCode dbConnectionCommonCode;
	TestBase testBase;
	Utilities utilities;
	SoftAssert softAssert;
	String className;
	public String TextToWrite;
	public String ClassName;

	@Parameters ("ClassName")
	public void initiateAssumptionsPage(String ClassName) throws Exception
	{
		utilities = new Utilities();
		className = utilities.getClassName(ClassName);
		softAssert = new SoftAssert();
		String  strQuery = "Select * from Assumptions where TestClassName = '" + className + "'";
		dbConnectionCommonCode = new DBConnectionRegressionCommonCode();
		Recordset recordset = dbConnectionCommonCode.recordset(strQuery);
		recordset.next();
		recordset.moveFirst();
		assumptionsPage = new AssumptionsPage(driver);

		if (recordset.getField("DogCatMicrochipped").equalsIgnoreCase("Yes"))
		{
			assumptionsPage.setDogCatMicrochippedYes();
			TextToWrite = "Pet 1 Microchipped = Yes";
			utilities.Filewriter(TextToWrite);
		}
		else
		{
			if (recordset.getField("PetType").equalsIgnoreCase("Dog"))
			{
				assumptionsPage.setDogCatMicrochippedNo();
				String DogMicrochippedNoTextMessage = assumptionsPage.getDogCatMicrochippedNoTextMessage();
				softAssert.assertEquals(DogMicrochippedNoTextMessage, recordset.getField("DogMicrochippedNoTextMessage"));
				softAssert.assertAll();
				TextToWrite = "Pet 1 Microchipped = No";
				utilities.Filewriter(TextToWrite);
			}
			else
			{
				assumptionsPage.setDogCatMicrochippedNo();
				String CatMicrochippedNoTextMessage = assumptionsPage.getDogCatMicrochippedNoTextMessage();
				softAssert.assertEquals(CatMicrochippedNoTextMessage, recordset.getField("CatMicrochippedNoTextMessage"));
				softAssert.assertAll();
				TextToWrite = "Pet 1 Microchipped = No";
				utilities.Filewriter(TextToWrite);
			}
		}

		if (recordset.getField("PetType").equalsIgnoreCase("Dog"))
		{
			if (recordset.getField("DogWorking").equalsIgnoreCase("Yes"))
			{
				assumptionsPage.setDogWorkingYes();
				String DogWorkingYesTextMessage = assumptionsPage.getDogWorkingYesTextMessage();
				softAssert.assertEquals(DogWorkingYesTextMessage, recordset.getField("DogWorkingYesTextMessage"));
				softAssert.assertAll();
				TextToWrite = "Pet 1 Working = Yes";
				utilities.Filewriter(TextToWrite);
			}
			else
			{
				assumptionsPage.setDogWorkingNo();
				TextToWrite = "Pet 1 Working = No";
				utilities.Filewriter(TextToWrite);
			}
		}

/*		if (recordset.getField("DogCatFromRescueHome").equalsIgnoreCase("Yes"))
		{
			assumptionsPage.setDogCatFromRescueHomeYes();
			TextToWrite = "Pet 1 From Rescue Home = Yes";
			utilities.Filewriter(TextToWrite);
		}
		else
		{
			assumptionsPage.setDogCatFromRescueHomeNo();
			TextToWrite = "Pet 1 From Rescue Home = No";
			utilities.Filewriter(TextToWrite);
		}
*/
		if (recordset.getField("DogCatAddressSameAsPolicyHolder").equalsIgnoreCase("Yes"))
		{
			assumptionsPage.setDogCatAddressSameAsPolicyHolderYes();
			TextToWrite = "Pet 1 Lives With Policyholder = Yes";
			utilities.Filewriter(TextToWrite);
		}
		else
		{
			assumptionsPage.setDogCatAddressSameAsPolicyHolderNo();
			String DogCatAddressSameAsPolicyHolderNoTextMessage = assumptionsPage.getDogCatAddressSameAsPolicyHolderNoTextMessage();
			softAssert.assertEquals(DogCatAddressSameAsPolicyHolderNoTextMessage, recordset.getField("DogCatAddressSameAsPolicyHolderNoTextMessage"));
			softAssert.assertAll();
			TextToWrite = "Pet 1 Lives With Policyholder = No";
			utilities.Filewriter(TextToWrite);
		}

		if (recordset.getField("DogCatVeterinaryNeeds").equalsIgnoreCase("Yes"))
		{
			assumptionsPage.setDogCatVeterinaryNeedsYes();
			TextToWrite = "Pet 1 Veterinary Needs = Yes";
			utilities.Filewriter(TextToWrite);
		}
		else
		{
			assumptionsPage.setDogCatVeterinaryNeedsNo();
			String DogCatVeterinaryNeedsNoTextMessage = assumptionsPage.getDogCatVeterinaryNeedsNoTextMessage();
			softAssert.assertEquals(DogCatVeterinaryNeedsNoTextMessage, recordset.getField("DogCatVeterinaryNeedsNoTextMessage"));
			softAssert.assertAll();
			TextToWrite = "Pet 1 Veterinary Needs = No";
			utilities.Filewriter(TextToWrite);
		}

		if (recordset.getField("PetType").equalsIgnoreCase("Dog"))
		{
	/*		if (recordset.getField("DogAlchoholSoldPremises").equalsIgnoreCase("Yes"))
			{
				assumptionsPage.setDogAlchoholSoldPremisesYes();
				String DogAlchoholSoldPremisesYesTextMessage = assumptionsPage.getDogAlchoholSoldPremisesYesTextMessage();
				softAssert.assertEquals(DogAlchoholSoldPremisesYesTextMessage, recordset.getField("DogAlchoholSoldPremisesYesTextMessage"));
				softAssert.assertAll();
				TextToWrite = "Pet 1 From Alchohol Sold Premises = Yes";
				utilities.Filewriter(TextToWrite);
			}
			else
			{
				assumptionsPage.setDogAlchoholSoldPremisesNo();
				TextToWrite = "Pet 1 From Alchohol Sold Premises = No";
				utilities.Filewriter(TextToWrite);
			}
*/
			if (recordset.getField("DogBadBehaviour").equalsIgnoreCase("Yes"))
			{
				assumptionsPage.setDogBadBehaviourYes();
				String DogBadBehaviourYesTextMessage = assumptionsPage.getDogBadBehaviourYesTextMessage();
				softAssert.assertEquals(DogBadBehaviourYesTextMessage, recordset.getField("DogBadBehaviourYesTextMessage"));
				softAssert.assertAll();
				TextToWrite = "Pet 1 Bad Behaviour = Yes";
				utilities.Filewriter(TextToWrite);
			}
			else
			{
				assumptionsPage.setDogBadBehaviourNo();
				TextToWrite = "Pet 1 Bad Behaviour = No";
				utilities.Filewriter(TextToWrite);
			}
		}
		assumptionsPage.clickCancel();
		dbConnectionCommonCode.closeConnection();
	}
}