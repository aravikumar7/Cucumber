/**
 * 
 */
package com.argos.pet.quotebuy.regression.common.code.tests;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Parameters;
import org.testng.asserts.SoftAssert;

import com.argos.pet.quotebuy.regression.common.code.dbconnection.DBConnectionRegressionCommonCode;
import com.argos.pet.quotebuy.regression.common.code.pages.YourPetDetailsPage;
import com.argos.pet.quotebuy.regression.common.code.utilities.TestBase;
import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;
import com.codoid.products.fillo.Recordset;


/**
 * @author d23747
 *
 */
public class MultiPetMoreAboutYourPetTest extends TestBase {
	DBConnectionRegressionCommonCode dbConnectionCommonCode;
	Utilities utilities;
	YourPetDetailsPage yourPetDetailsPage;
	SoftAssert softAssert;
	MultiPetYourPetDetailsTest multiPetYourPetDetailsTest;
	MultiPetAssumptionsTest multiPetAssumptionsTest;
	String[] dobArray;
	String className;
	String[] multiPetUniqueTestDataArray;
	static String multiPetAnyInjuryIllness;
	int numberOfMultiPetsInt;
	public String TextToWrite;
	public String ClassName;

	@Parameters ("ClassName")
	public String initiateMultiPetMoreAboutYourPetTest(String ClassName) throws Exception
	{
		utilities = new Utilities();
		className = utilities.getClassName(ClassName);
		numberOfMultiPetsInt = MultiPetTest.numberOfMultiPets;
		multiPetUniqueTestDataArray = MultiPetYourPetDetailsTest.multiPetUniqueTestDataArray;
		String  strQuery = "Select * from MultiPet where TestClassName = '" + className + "'";
		dbConnectionCommonCode = new DBConnectionRegressionCommonCode();
		Recordset recordset = dbConnectionCommonCode.recordset(strQuery);
		recordset.next();
		recordset.moveFirst();
		softAssert = new SoftAssert();
		yourPetDetailsPage = new YourPetDetailsPage(driver);
		utilities.waitForLoad(driver);
		//driver.get().findElement(By.xpath("//*[@id='pet" + numberOfMultiPetsInt + ".pet_cost']")).clear();
		//driver.get().findElement(By.id("pet1.pet_cost")).click();
		//driver.get().findElement(By.id("pet1.pet_cost")).sendKeys(Keys.SPACE);
		if (!recordset.getField("MultiPetCost_" + (numberOfMultiPetsInt - 1) + "").equalsIgnoreCase("I didn't pay anything"))
		{
			driver.get().findElement(By.xpath("//*[@id='pet" + numberOfMultiPetsInt + ".pet_cost']")).sendKeys(Keys.BACK_SPACE);
			driver.get().findElement(By.xpath("//*[@id='pet" + numberOfMultiPetsInt + ".pet_cost']")).sendKeys(recordset.getField("MultiPetCost_" + numberOfMultiPetsInt + ""));
			TextToWrite = "Pet " + (numberOfMultiPetsInt) + " Cost: " + recordset.getField("MultiPetCost_" + numberOfMultiPetsInt);
			utilities.Filewriter(TextToWrite);
		}
		else
		{
			//driver.get().findElement(By.xpath("//*[@id='zeroPetCost_" + numberOfMultiPetsInt + "']")).click();
		}
		driver.get().switchTo().activeElement().sendKeys(Keys.TAB);
		Thread.sleep(700);
		if (recordset.getField("MultiPetNeutered_" + (numberOfMultiPetsInt - 1) + "").equalsIgnoreCase("Yes"))
		{
			((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();",driver.get().findElement(By.xpath("//label[contains(@for,'neutered_yes_pet"+numberOfMultiPetsInt+"')]")));
			TextToWrite = "Pet " + (numberOfMultiPetsInt) + " Neutered = Yes";
			utilities.Filewriter(TextToWrite);
		}
		else
		{
			Thread.sleep(700);
			((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();",driver.get().findElement(By.xpath("//label[contains(@for,'neutered_no_pet"+numberOfMultiPetsInt+"')]")));
				TextToWrite = "Pet " + (numberOfMultiPetsInt) + " Neutered = No";
			utilities.Filewriter(TextToWrite);
		}
		multiPetAnyInjuryIllness = recordset.getField("MultiPetAnyInjuryIllness_" + (numberOfMultiPetsInt -1 ) + "");
		if (multiPetAnyInjuryIllness.equalsIgnoreCase("Yes"))
		{
			((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//label[contains(@for,'health_yes_pet"+ numberOfMultiPetsInt + "')]")));
			Thread.sleep(1000);
			driver.get().findElement(By.xpath("//label[contains(@for,'health_yes_pet"+ numberOfMultiPetsInt + "')]")).click();
			TextToWrite = "Pet " + (numberOfMultiPetsInt) + " Injury Illness = Yes";
			utilities.Filewriter(TextToWrite);
		}
		else
		{
			((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", driver.get().findElement(By.xpath("//label[contains(@for,'health_no_pet"+ numberOfMultiPetsInt + "')]")));
			((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", driver.get().findElement(By.xpath("//label[contains(@for,'health_no_pet"+ numberOfMultiPetsInt + "')]")));
			if (recordset.getField("MultiPetType_" + (numberOfMultiPetsInt - 1) + "").equalsIgnoreCase("Do Not Test"))
			{
				String MultiPetPetAnyInjuryIllnessNoTextMessage = driver.get().findElement(By.xpath("//*[@id='petQuestionsOuterContainer_" + numberOfMultiPetsInt + "']/div[3]/div")).getText();
				String noTextMessageFromExcel = recordset.getField("MultiPetAnyInjuryIllnessNoTextMessage_" + (numberOfMultiPetsInt - 1) + "");
				String noTextMessageFromExcel2 = recordset.getField("MultiPetAnyInjuryIllnessNoTextMessage_" + (numberOfMultiPetsInt - 1) + "A");
				String noTextMessageFromExcel3 = recordset.getField("MultiPetAnyInjuryIllnessNoTextMessage_" + (numberOfMultiPetsInt - 1) + "B");
				String noTextMessageFromExcel4 = recordset.getField("MultiPetAnyInjuryIllnessNoTextMessage_" + (numberOfMultiPetsInt - 1) + "C");
				String finalMultiPetPetAnyInjuryIllnessNoTextMessage = noTextMessageFromExcel + multiPetUniqueTestDataArray[0] + noTextMessageFromExcel2 + multiPetUniqueTestDataArray[0] + noTextMessageFromExcel3 + multiPetUniqueTestDataArray[0] + noTextMessageFromExcel4;
				softAssert.assertEquals(MultiPetPetAnyInjuryIllnessNoTextMessage, finalMultiPetPetAnyInjuryIllnessNoTextMessage);
				softAssert.assertAll();
				TextToWrite = "Pet " + (numberOfMultiPetsInt) + " Injury Illness = No";
				utilities.Filewriter(TextToWrite);
			}
		}
		multiPetAnyInjuryIllness = recordset.getField("MultiPetAnyInjuryIllnessRadioButtonBasedOnRisk_" + (numberOfMultiPetsInt -1 ) + "");
		multiPetAssumptionsTest = new MultiPetAssumptionsTest();
		multiPetAssumptionsTest.initiateMultiPetAssumptionsTest(className);
		Thread.sleep(700);
	/*	WebElement closeToaster=driver.get().findElement(By.xpath("//button[@claass='Toastify__close-button Toastify__close-button--success']"));
		((JavascriptExecutor) driver.get()).executeScript("arguments[0].scrollIntoView(true);", closeToaster);
		((JavascriptExecutor) driver.get()).executeScript("arguments[0].click();", closeToaster);
	*/
		dbConnectionCommonCode.closeConnection();
		return multiPetAnyInjuryIllness;
	}
}