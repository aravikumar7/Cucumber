/**
 * 
 */
package com.argos.pet.quotebuy.regression.common.code.pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.argos.pet.quotebuy.regression.common.code.utilities.Utilities;

/**
 * @author d23747
 *
 */
public class PreExistingConditionsPage {

	ThreadLocal<WebDriver> ldriver;
	Utilities utilities;

	public PreExistingConditionsPage(ThreadLocal<WebDriver> driver)
	{
		ldriver = driver;
		PageFactory.initElements(driver.get(), this);
	}

	@FindBy (how = How.XPATH, using = "//*[@id='pet_injury_illness_details']") WebElement preExistingInjuryDetails;
	@FindBy (how = How.XPATH, using = "//*[@id='postcodeSearch']") WebElement vetPostCodeTextField;
	@FindBy (how = How.XPATH, using = "//button[text()='Find vet']") WebElement vetPostCodeSerchButton;
	@FindBy (how = How.XPATH, using = "//input[@id='provide_vet_later']") WebElement provideVetDetailsLaterTickBox;
	//@FindBy (how = How.XPATH, using = "//button/div[text()='Save and close']") WebElement saveCloseButton;
	@FindBy (how = How.XPATH, using = "//button[text()='Save and close']") WebElement saveCloseButton;
	
	
	public void setPreExistingInjuryDetails(String PreExistingInjuryDetails)
	{
		preExistingInjuryDetails.clear();
		preExistingInjuryDetails.sendKeys(PreExistingInjuryDetails);
	}
	
	public void setVetPostCodeTextField(String VetPostCode)
	{
		vetPostCodeTextField.clear();
		JavascriptExecutor js = (JavascriptExecutor) ldriver.get();
		js.executeScript("(arguments[0])[arguments[1]] = arguments[2];", 
				vetPostCodeTextField, "value","");	
		vetPostCodeTextField.sendKeys(VetPostCode);
	}
	
	public void clickVetPostCodeSerchButton()
	{
		utilities = new Utilities();
		utilities.actionWaitClick(ldriver.get(), vetPostCodeSerchButton);
		vetPostCodeSerchButton.click();
	}
	
	public void clickProvideVetDetailsLaterTickBox()
	{
		//provideVetDetailsLaterTickBox.click();
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].scrollIntoView(true);", provideVetDetailsLaterTickBox);
		((JavascriptExecutor) ldriver.get()).executeScript("arguments[0].click();", provideVetDetailsLaterTickBox);
	}
	
	public void clickSaveCloseButton()
	{
		saveCloseButton.click();
	}
}
