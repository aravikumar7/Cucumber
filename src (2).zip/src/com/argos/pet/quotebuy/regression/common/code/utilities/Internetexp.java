package com.argos.pet.quotebuy.regression.common.code.utilities;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class Internetexp {

	public static void main(String[] args) throws IOException {
		String pol="Time Limited 1K";
		String [] pol1=pol.split(" ");
		System.out.println(pol1.length);
		System.out.println(pol1[0]+" "+pol1[1]+" �"+pol1[2].replace("K", ",000"));
	/*	String Username="dev";
		String Password="pPdev22!!";
		String PortalTestEnvironmentURL="uat35.cardifpinnacle.com/register#login";
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--disable-notifications");
		options.setExperimentalOption("useAutomationExtension", false);
	//	options.addArguments("--incognito");
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\d49492\\Project\\Everypaw\\18062020\\EveryPawPetQuoteBuyRegression\\Drivers\\chromedriver.exe");
		WebDriver driver = new ChromeDriver(options);
		driver.manage().window().maximize();
		driver.get("https://" + Username + ":" + Password + "@" + PortalTestEnvironmentURL);
		*/
	//String dt="20.02.1985";
		//System.out.println(dt.replace(".", "/"));
/*		String command="H:\\Cardif\\Everypaw\\Everypaw_Regression\\Drivers\\login.ps1";
		//String[] cmmm = {"Powershell.exe","-executionpolicy","-Scope","CurrentUser","-ExecutionPolicy","Unrestricted","-File",command};
		String[] cmmm = {"C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\Powershell.exe","-executionpolicy","bypass","-File",command};
		//Runtime.getRuntime().exec("Start-Process PowerShell -verb runas -ArgumentList '-noexit','-File','H:\\\\Cardif\\\\Everypaw\\\\Everypaw_Regression\\\\Drivers\\\\login.ps1'");
		ProcessBuilder processBuilder = new ProcessBuilder(cmmm);
	    Process process = processBuilder.start();
	    try {
			process.waitFor();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	   String result = String.valueOf(process.exitValue());
	   System.out.println("Result is : "+result);
		/*    String command1 = "C:\\test\\test.ps1";
		    Runtime runtime = Runtime.getRuntime();
		    try {
		        Process proc = runtime.exec(path + " " + command);
		        proc.waitFor();
		    } catch (Exception e) {
		        System.out.println("Error");
		    }
		*/
		/*String command = "powershell.exe  "+loadPath;
		  Process powerShellProcess = Runtime.getRuntime().exec("Start-Process PowerShell -verb runas -ArgumentList '-noexit','-File','path-to-script'");
		  powerShellProcess.getOutputStream().close();
		  String line;
		  System.out.println("Standard Output:");
		  BufferedReader stdout = new BufferedReader(new InputStreamReader(
		    powerShellProcess.getInputStream()));
		  while ((line = stdout.readLine()) != null) {
		   System.out.println(line);
		  }
		  stdout.close();
		  System.out.println("Standard Error:");
		  BufferedReader stderr = new BufferedReader(new InputStreamReader(
		    powerShellProcess.getErrorStream()));
		  while ((line = stderr.readLine()) != null) {
		   System.out.println(line);
		  }
		  stderr.close();
		  System.out.println("Done");
*/
	   }

}
