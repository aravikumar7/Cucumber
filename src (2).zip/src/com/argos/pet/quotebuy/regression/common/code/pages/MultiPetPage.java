/**
 * 
 */
package com.argos.pet.quotebuy.regression.common.code.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * @author d23747
 *
 */
public class MultiPetPage {

	WebDriver ldriver;

	public MultiPetPage (WebDriver rdriver)
	{
		ldriver = rdriver;
		PageFactory.initElements(rdriver, this);
	}

	@FindBy (how = How.XPATH, using = "//*[@id='petName_2']") WebElement multiPetName;
	@FindBy (how = How.XPATH, using = "//*[@id='radio_dog_2']") WebElement multiRadioButtonDog;
	@FindBy (how = How.XPATH, using = "//*[@id='radio_cat_2']") WebElement multiRadioButtonCat;
	@FindBy (how = How.XPATH, using = "//*[@id='radio_breed_2']") WebElement multiRadioButtonDogBreed;
	@FindBy (how = How.XPATH, using = "//*[@id='crossbreedDogType_2']") WebElement multiRadioButtonDogCrossBreed;
	@FindBy (how = How.XPATH, using = "//*[@id='radio_mongrel_2']") WebElement multiRadioButtonDogMongrel;
	@FindBy (how = How.XPATH, using = "//*[@id='radio_D607_2']") WebElement multiRadioButtonDogMongrelSmall;
	@FindBy (how = How.XPATH, using = "//*[@id='radio_D608_2']") WebElement multiRadioButtonDogMongrelMedium;
	@FindBy (how = How.XPATH, using = "//*[@id='radio_D609_2']") WebElement multiRadioButtonDogMongrelLarge;
	@FindBy (how = How.XPATH, using = "//*[@id='whatBreedQuestion_2']/div[1]/div[1]/div") WebElement multiWhatBreedQuestion;
	@FindBy (how = How.XPATH, using = "//*[@id='daySelectDob_2']") WebElement multiDOBDay;
	@FindBy (how = How.XPATH, using = "//*[@id='monthSelectDob_2']") WebElement multiDOBMonth;
	@FindBy (how = How.XPATH, using = "//*[@id='yearSelectDob_2']") WebElement multiDOBYear;
	@FindBy (how = How.XPATH, using = "//*[@id='pet_m_2']") WebElement multiRadioButtonSexMale;
	@FindBy (how = How.XPATH, using = "//*[@id='pet_f_2']") WebElement multiRadioButtonSexFemale;
	@FindBy (how = How.XPATH, using = "//*[@id='petDetailsSubmit_2']") WebElement multiButtonSave;
	@FindBy (how = How.XPATH, using = "//*[@id='petCost_2']") WebElement multiPetCost;
	@FindBy (how = How.XPATH, using = "//*[@id='pet_neutered_Yes_2']") WebElement multiRadioButtonPetNeuteredYes;
	@FindBy (how = How.XPATH, using = "//*[@id='pet_neutered_No_2']") WebElement multiRadioButtonPetNeuteredNo;
	@FindBy (how = How.XPATH, using = "//*[@id='pet_any_injury_illness_Yes_2']") WebElement multiRadioButtonPetAnyInjuryIllnessYes;
	@FindBy (how = How.XPATH, using = "//*[@id='pet_any_injury_illness_No_2']") WebElement multiRadioButtonPetAnyInjuryIllnessNo;
	@FindBy (how = How.XPATH, using = "//*[@id='formPetMoreDetailForm_2']/div/button[1]/div") WebElement multiChangeAssumptionLinkTop;
	@FindBy (how = How.XPATH, using = "//*[@id='pet_microchipped_Yes_2']") WebElement multiRadioButtonPetMicrochippedYes;
	@FindBy (how = How.XPATH, using = "//*[@id='pet_microchipped_No_2']") WebElement multiRadioButtonPetMicrochippedNo;
	@FindBy (how = How.XPATH, using = "//*[@id='is_working_dog_Yes_2']") WebElement multiRadioButtonWorkingDogYes;
	@FindBy (how = How.XPATH, using = "//*[@id='is_working_dog_No_2']") WebElement multiRadioButtonWorkingDogNo;
	@FindBy (how = How.XPATH, using = "//*[@id='rescue_home_Yes_2']") WebElement multiRadioButtonRescueHomeYes;
	@FindBy (how = How.XPATH, using = "//*[@id='rescue_home_No_2']") WebElement multiRadioButtonRescueHomeNo;
	@FindBy (how = How.XPATH, using = "//*[@id='pet_reside_same_address_Yes_2']") WebElement multiRadioButtonSameAddressYes;
	@FindBy (how = How.XPATH, using = "//*[@id='pet_reside_same_address_No_2']") WebElement multiRadioButtonSameAddressNo;
	@FindBy (how = How.XPATH, using = "//*[@id='idd_Yes_2']") WebElement multiRadioButtonVeterinaryNeedsYes;
	@FindBy (how = How.XPATH, using = "//*[@id='idd_No_2']") WebElement multiRadioButtonVeterinaryNeedsNo;
	@FindBy (how = How.XPATH, using = "//*[@id='licensed_premises_Yes_2']") WebElement multiRadioButtonAlcoholYes;
	@FindBy (how = How.XPATH, using = "//*[@id='licensed_premises_No_2']") WebElement multiRadioButtonAlcoholNo;
	@FindBy (how = How.XPATH, using = "//*[@id='dog_behaviour_Yes_2']") WebElement multiRadioButtonDogBadBehaviourYes;
	@FindBy (how = How.XPATH, using = "//*[@id='dog_behaviour_No_2']") WebElement multiRadioButtonDogBadBehaviourNo;
	@FindBy (how = How.XPATH, using = "//*[@id='formPetMoreDetailForm_2']/div/button[2]/div") WebElement multiChangeAssumptionLinkBottom;
	@FindBy (how = How.XPATH, using = "//*[@id='morePetSubmitButton_2']") WebElement multiButtonPetSave;
	
	public void setMultiPetName(String MultiPetName)
	{
		multiPetName.sendKeys(MultiPetName);
		ldriver.findElement(By.xpath("//*[@id='petName_2']")).sendKeys(MultiPetName);
	}
}
